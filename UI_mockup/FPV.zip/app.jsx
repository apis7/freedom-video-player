/* ---------- Root app ---------- */

const initial = {
  hasFile: true,
  playing: true,
  pos: 1248,
  volume: 100,
  muted: false,
  fullscreen: false,
  profileOn: true,
  repeat: "off",
  shuffle: false,
  stopAfter: false,
  panel: null,                   // null | "queue" | "switcher"
  skipThatVisible: false,
  skipThatRecording: false,
  cheatsheet: false,
  endToast: false,
  fsPrompt: false,
  currentName: "The.Pinnacle.2024.1080p.BluRay.x265.mkv",
  profiles: window.FVPData.PROFILES_FOR_FILE,
};

const reducer = (s, a) => {
  switch (a.type) {
    case "OPEN_FILE":          return { ...s, hasFile: true, playing: true };
    case "PLAY_TOGGLE":        return { ...s, playing: a.val != null ? a.val : !s.playing };
    case "MUTE_TOGGLE":        return { ...s, muted: !s.muted };
    case "REPEAT_CYCLE":       return { ...s, repeat: s.repeat === "off" ? "all" : s.repeat === "all" ? "one" : "off" };
    case "SHUFFLE_TOGGLE":     return { ...s, shuffle: !s.shuffle };
    case "STOP_AFTER_TOGGLE":  return { ...s, stopAfter: !s.stopAfter };
    case "FS_TOGGLE":          return { ...s, fullscreen: !s.fullscreen };
    case "FS_PROMPT":          return { ...s, fsPrompt: a.val };
    case "SEEK":               return { ...s, pos: Math.max(0, Math.min(window.FVPData.VIDEO_DURATION, a.pos)) };
    case "PANEL":              return { ...s, panel: a.panel };
    case "AB_TOGGLE":          return { ...s, profileOn: !s.profileOn };
    case "CHEATSHEET":         return { ...s, cheatsheet: a.val };
    case "END_TOAST":          return { ...s, endToast: a.val };
    case "SKIPTHAT_SHOW":      return { ...s, skipThatVisible: a.val };
    case "SKIPTHAT_REC":       return { ...s, skipThatRecording: a.val };
    case "PROFILE_TOGGLE":     return { ...s, profiles: s.profiles.map(p => p.id === a.id ? { ...p, active: !p.active } : p) };
    case "PROFILE_PRIMARY":    return { ...s, profiles: s.profiles.map(p => ({ ...p, primary: p.id === a.id })) };
    case "VOL":                return { ...s, volume: a.val, muted: false };
    default: return s;
  }
};

const TWEAK_DEFAULS = /*EDITMODE-BEGIN*/{
  "mode": "player",
  "libraryEnabled": true,
  "showTOS": false,
  "showResume": false,
  "showFingerprint": false,
  "showUnknownCat": false,
  "showProfileUpdate": false,
  "showCheatsheet": false,
  "showSwitcher": false,
  "showQueue": false,
  "showSkipThat": false,
  "showSkipThatRec": false,
  "showEndToast": false,
  "showFsPrompt": false,
  "abOff": false,
  "fullscreen": false,
  "noFile": false,
  "showAllChrome": true
}/*EDITMODE-END*/;

const App = () => {
  const [state, dispatch] = React.useReducer(reducer, initial);
  const [t, setTweak] = window.useTweaks(TWEAK_DEFAULS);
  const [mode, setMode] = useState(t.mode);
  const [libraryEnabled, setLibraryEnabled] = useState(t.libraryEnabled);
  const [tosOpen, setTosOpen] = useState(t.showTOS);
  const [resumeOpen, setResumeOpen] = useState(t.showResume);
  const [fingerprintOpen, setFingerprintOpen] = useState(t.showFingerprint);
  const [unknownCatOpen, setUnknownCatOpen] = useState(t.showUnknownCat);
  const [profileUpdateOpen, setProfileUpdateOpen] = useState(t.showProfileUpdate);

  // Sync tweaks <-> internal state for player demo overlays
  useEffect(() => { dispatch({ type: "CHEATSHEET", val: t.showCheatsheet }); }, [t.showCheatsheet]);
  useEffect(() => { dispatch({ type: "PANEL", panel: t.showSwitcher ? "switcher" : t.showQueue ? "queue" : null }); }, [t.showSwitcher, t.showQueue]);
  useEffect(() => { dispatch({ type: "SKIPTHAT_SHOW", val: t.showSkipThat }); dispatch({ type: "SKIPTHAT_REC", val: t.showSkipThatRec }); }, [t.showSkipThat, t.showSkipThatRec]);
  useEffect(() => { dispatch({ type: "END_TOAST", val: t.showEndToast }); }, [t.showEndToast]);
  useEffect(() => { dispatch({ type: "FS_PROMPT", val: t.showFsPrompt }); }, [t.showFsPrompt]);
  useEffect(() => { if ((state.profileOn) !== !t.abOff) dispatch({ type: "AB_TOGGLE" }); }, [t.abOff]);
  useEffect(() => { if (state.fullscreen !== t.fullscreen) dispatch({ type: "FS_TOGGLE" }); }, [t.fullscreen]);
  useEffect(() => { if (state.hasFile === t.noFile) dispatch({ type: "OPEN_FILE" }); }, [t.noFile]);
  useEffect(() => { setMode(t.mode); }, [t.mode]);
  useEffect(() => { setLibraryEnabled(t.libraryEnabled); }, [t.libraryEnabled]);
  useEffect(() => { setTosOpen(t.showTOS); }, [t.showTOS]);
  useEffect(() => { setResumeOpen(t.showResume); }, [t.showResume]);
  useEffect(() => { setFingerprintOpen(t.showFingerprint); }, [t.showFingerprint]);
  useEffect(() => { setUnknownCatOpen(t.showUnknownCat); }, [t.showUnknownCat]);
  useEffect(() => { setProfileUpdateOpen(t.showProfileUpdate); }, [t.showProfileUpdate]);

  const onMode = (m) => { setMode(m); setTweak("mode", m); };

  const filename = mode === "player" && state.hasFile && !t.noFile ? state.currentName :
                   mode === "creator" ? "Editing: " + state.currentName :
                   mode === "library" ? "Library" :
                   mode === "settings" ? "Settings" : "";

  const playerForState = { ...state, hasFile: !t.noFile };

  const showChrome = mode !== "player" || !state.fullscreen;

  return (
    <div className="app">
      {showChrome && <window.TitleBar mode={mode} onMode={onMode} filename={filename} libraryEnabled={libraryEnabled}/>}
      {showChrome && mode === "player" && <window.MenuBar/>}
      {showChrome && mode === "creator" && <window.MenuBar/>}

      <div className="body">
        {mode === "player"   && <window.Player state={playerForState} dispatch={dispatch}/>}
        {mode === "creator"  && <window.Creator state={state} dispatch={dispatch}/>}
        {mode === "library"  && libraryEnabled && <window.Library state={state} dispatch={dispatch}/>}
        {mode === "settings" && <window.Settings libraryEnabled={libraryEnabled} setLibraryEnabled={(v) => { setLibraryEnabled(v); setTweak("libraryEnabled", v); }} dispatch={dispatch}/>}
      </div>

      {/* Status bar */}
      {mode === "player" && !state.fullscreen && (
        <div className="statusbar">
          <span className="statusbar__group"><span className="statusbar__dot"/> Ready</span>
          <span>·</span>
          <span>HEVC · 1080p · HDR10 · DTS-HD MA</span>
          <span>·</span>
          <span>{window.FVPData.PROFILES_FOR_FILE.filter(p => p.active).length} profiles active · cuts <span className="text-blue">14m 22s</span></span>
          <div className="statusbar__spacer"/>
          <span>{state.profileOn ? "A/B: ON" : "A/B: OFF"}</span>
          <span>·</span>
          <span>Vol {state.muted ? "mute" : `${state.volume}%`}</span>
          <span>·</span>
          <span className="cursor-pointer" onClick={() => dispatch({ type: "CHEATSHEET", val: true })}>? cheatsheet</span>
        </div>
      )}

      {/* Cross-cutting dialogs */}
      {tosOpen           && <window.TOSDialog          onAgree={() => setTweak("showTOS", false)}/>}
      {resumeOpen        && <window.ResumeDialog       onClose={() => setTweak("showResume", false)}/>}
      {fingerprintOpen   && <window.FingerprintDialog  onClose={() => setTweak("showFingerprint", false)}/>}
      {unknownCatOpen    && <window.UnknownCategoryDialog onClose={() => setTweak("showUnknownCat", false)}/>}
      {profileUpdateOpen && <window.ProfileUpdateDialog onClose={() => setTweak("showProfileUpdate", false)}/>}

      <window.TweaksPanel title="Tweaks">
        <window.TweakSection label="Mode">
          <window.TweakSelect label="Active mode" value={t.mode} onChange={(v) => setTweak("mode", v)}
            options={[
              { value: "player",   label: "Player" },
              { value: "creator",  label: "Profile Creator" },
              { value: "library",  label: "Library" },
              { value: "settings", label: "Settings" },
            ]}/>
          <window.TweakToggle label="Library Mode enabled" value={t.libraryEnabled} onChange={(v) => setTweak("libraryEnabled", v)}/>
        </window.TweakSection>

        <window.TweakSection label="Player states">
          <window.TweakToggle label="No file loaded (empty state)" value={t.noFile} onChange={(v) => setTweak("noFile", v)}/>
          <window.TweakToggle label="Fullscreen" value={t.fullscreen} onChange={(v) => setTweak("fullscreen", v)}/>
          <window.TweakToggle label="A/B Profile OFF" value={t.abOff} onChange={(v) => setTweak("abOff", v)}/>
        </window.TweakSection>

        <window.TweakSection label="Overlays / panels">
          <window.TweakToggle label="Profile switcher panel" value={t.showSwitcher} onChange={(v) => setTweak("showSwitcher", v)}/>
          <window.TweakToggle label="Now Playing queue" value={t.showQueue} onChange={(v) => setTweak("showQueue", v)}/>
          <window.TweakToggle label="Hotkey cheatsheet" value={t.showCheatsheet} onChange={(v) => setTweak("showCheatsheet", v)}/>
          <window.TweakToggle label="Skip-That tray" value={t.showSkipThat} onChange={(v) => setTweak("showSkipThat", v)}/>
          <window.TweakToggle label="Skip-That recording" value={t.showSkipThatRec} onChange={(v) => setTweak("showSkipThatRec", v)}/>
          <window.TweakToggle label="End-of-playback summary" value={t.showEndToast} onChange={(v) => setTweak("showEndToast", v)}/>
          <window.TweakToggle label="Fullscreen prompt" value={t.showFsPrompt} onChange={(v) => setTweak("showFsPrompt", v)}/>
        </window.TweakSection>

        <window.TweakSection label="Dialogs">
          <window.TweakToggle label="First-run TOS" value={t.showTOS} onChange={(v) => setTweak("showTOS", v)}/>
          <window.TweakToggle label="Resume prompt" value={t.showResume} onChange={(v) => setTweak("showResume", v)}/>
          <window.TweakToggle label="Fingerprint mismatch" value={t.showFingerprint} onChange={(v) => setTweak("showFingerprint", v)}/>
          <window.TweakToggle label="Unknown category" value={t.showUnknownCat} onChange={(v) => setTweak("showUnknownCat", v)}/>
          <window.TweakToggle label="Profile update available" value={t.showProfileUpdate} onChange={(v) => setTweak("showProfileUpdate", v)}/>
        </window.TweakSection>
      </window.TweaksPanel>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById("app")).render(<App/>);
