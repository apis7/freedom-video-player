/* ---------- Shared utils + small components ---------- */

const { useState, useEffect, useRef, useMemo, useCallback } = React;

const fmtTime = (s, withMs = false) => {
  if (s == null) return "--:--";
  const total = Math.max(0, Math.floor(s));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const sec = total % 60;
  const ms = withMs ? "." + String(Math.floor((s - total) * 1000)).padStart(3, "0") : "";
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}${ms}`;
  return `${m}:${String(sec).padStart(2, "0")}${ms}`;
};

const fmtRuntime = (mins) => `${Math.floor(mins / 60)}h ${mins % 60}m`;

// Tooltip wrapper
const Tip = ({ children, label, side, hotkey }) => {
  const text = hotkey ? `${label}  (${hotkey})` : label;
  return React.cloneElement(children, {
    className: (children.props.className || "") + " tt",
    "data-tt": text,
    "data-tt-side": side,
  });
};

// Icon button
const IconBtn = ({ icon, onClick, active, on, off, tooltip, hotkey, danger, size, className = "", style }) => {
  const Comp = window.I[icon];
  return (
    <Tip label={tooltip} hotkey={hotkey}>
      <button
        className={`icb ${active ? "is-active" : ""} ${on ? "is-on" : ""} ${off ? "is-off" : ""} ${danger ? "is-danger" : ""} ${size ? "size-" + size : ""} ${className}`}
        onClick={onClick}
        style={style}
      >
        <Comp />
      </button>
    </Tip>
  );
};

const Btn = ({ children, primary, danger, ghost, icon, onClick, disabled, kbd, ...rest }) => {
  const Comp = icon ? window.I[icon] : null;
  return (
    <button
      className={`btn ${primary ? "is-primary" : ""} ${danger ? "is-danger" : ""} ${ghost ? "is-ghost" : ""}`}
      onClick={onClick}
      disabled={disabled}
      {...rest}
    >
      {Comp && <Comp />}
      {children}
      {kbd && <span className="kbd">{kbd}</span>}
    </button>
  );
};

const Kbd = ({ children }) => <span className="kbd">{children}</span>;

const CatChip = ({ catId, onRemove }) => {
  const cat = window.FVPData.CAT_BY_ID[catId];
  if (!cat) return null;
  return (
    <span className={`chip chip--${cat.key}`}>
      <span className="dot" />
      {cat.label}
      {onRemove && (
        <span className="x" onClick={(e) => { e.stopPropagation(); onRemove(); }}>
          <window.I.Close size={10} strokeWidth={2}/>
        </span>
      )}
    </span>
  );
};

const Toggle = ({ on, onChange, label }) => (
  <span className={`toggle ${on ? "is-on" : ""}`} onClick={() => onChange && onChange(!on)}>
    {label && <span>{label}</span>}
    <span className="toggle__track"/>
  </span>
);

const Seg = ({ value, onChange, options }) => (
  <span className="seg">
    {options.map(o => (
      <span key={o.value}
            className={`seg__opt ${value === o.value ? "is-active" : ""}`}
            onClick={() => onChange(o.value)}>
        {o.label}
      </span>
    ))}
  </span>
);

const ProfileStateBadge = ({ state, n }) => {
  if (state === "none") return null;
  if (state === "has")     return <span className="psbadge psbadge--has"><window.I.Check size={11} strokeWidth={3}/>profile</span>;
  if (state === "stacked") return <span className="psbadge psbadge--stacked"><window.I.Layers2 size={11} strokeWidth={2}/>stack · {n||2}</span>;
  if (state === "draft")   return <span className="psbadge psbadge--draft"><window.I.Edit size={11} strokeWidth={2}/>draft</span>;
  if (state === "hub")     return <span className="psbadge psbadge--hub"><window.I.Sparkles size={11} strokeWidth={2}/>new on hub</span>;
  return null;
};

// Generated poster — Mondrian-ish patriotic colored placeholder using the title's hue
const Poster = ({ title, year, hue, ratio = "2/3", small = false }) => {
  const seed = (title || "").length;
  // deterministic-ish pattern from title
  const variant = seed % 5;
  const styles = {
    background: `linear-gradient(160deg, hsl(${hue}, 38%, 28%) 0%, hsl(${(hue+30)%360}, 30%, 14%) 100%)`,
    aspectRatio: ratio,
  };
  // overlay shapes
  return (
    <div className="lib-card__poster" style={styles}>
      <svg viewBox="0 0 100 150" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: .85 }}>
        {variant === 0 && (
          <>
            <rect x="0" y="0" width="100" height="36" fill={`hsl(${hue}, 60%, 52%)`} opacity=".22"/>
            <circle cx="68" cy="64" r="32" fill={`hsl(${(hue+50)%360}, 70%, 55%)`} opacity=".18"/>
          </>
        )}
        {variant === 1 && (
          <>
            <polygon points="0,150 100,150 100,80" fill={`hsl(${hue}, 70%, 60%)`} opacity=".22"/>
            <polygon points="0,0 100,0 0,100" fill={`hsl(${(hue+200)%360}, 50%, 50%)`} opacity=".14"/>
          </>
        )}
        {variant === 2 && (
          <>
            <rect x="60" y="0" width="40" height="150" fill={`hsl(${hue}, 70%, 55%)`} opacity=".18"/>
            <rect x="0" y="100" width="100" height="50" fill={`hsl(${(hue+80)%360}, 60%, 50%)`} opacity=".15"/>
          </>
        )}
        {variant === 3 && (
          <>
            <circle cx="20" cy="30" r="50" fill={`hsl(${hue}, 70%, 55%)`} opacity=".2"/>
            <circle cx="80" cy="120" r="40" fill={`hsl(${(hue+200)%360}, 60%, 50%)`} opacity=".18"/>
          </>
        )}
        {variant === 4 && (
          <>
            <rect x="0" y="40" width="100" height="6" fill={`hsl(${hue}, 80%, 60%)`} opacity=".55"/>
            <rect x="0" y="78" width="100" height="3" fill={`hsl(${(hue+30)%360}, 60%, 55%)`} opacity=".45"/>
            <rect x="0" y="0" width="100" height="150" fill="url(#g)" opacity=".15"/>
          </>
        )}
      </svg>
      {!small && (
        <div style={{ position: "relative", zIndex: 1, width: "100%" }}>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 9, opacity: .7, letterSpacing: ".1em" }}>{year}</div>
          <div style={{ fontWeight: 700, fontSize: 16, letterSpacing: "-.01em", lineHeight: 1.1, marginTop: 2, textShadow: "0 1px 3px rgba(0,0,0,.5)" }}>
            {title}
          </div>
        </div>
      )}
    </div>
  );
};

// Mini sparkline
const Sparkline = ({ data, color = "var(--blue)" }) => {
  const w = 80, h = 18;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / range) * (h - 2) - 1}`).join(" ");
  return (
    <svg className="spark" viewBox={`0 0 ${w} ${h}`}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
};

// Volume slider (no input, just visual)
const VolSlider = ({ value }) => (
  <div className="vol-slider">
    <div className="vol-slider__fill" style={{ width: `${value}%` }}/>
    <div className="vol-slider__knob" style={{ left: `${value}%` }}/>
  </div>
);

window.UI = {
  fmtTime, fmtRuntime, Tip, IconBtn, Btn, Kbd, CatChip, Toggle, Seg,
  ProfileStateBadge, Poster, Sparkline, VolSlider,
};
