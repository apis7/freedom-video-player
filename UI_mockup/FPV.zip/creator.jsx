/* ---------- Profile Creator Mode ---------- */

const Creator = ({ state, dispatch }) => {
  const { fmtTime, IconBtn, Btn, Kbd, CatChip, Toggle, Seg } = window.UI;
  const { CATEGORIES, CAT_BY_ID, ACTIONS, ACTION_BY_ID, VIDEO_DURATION, SNIPS, SNIP_GROUPS, PROFILES_FOR_FILE } = window.FVPData;

  const [selectedId, setSelectedId] = useState("s4");
  const [snips, setSnips] = useState(SNIPS);
  const [zoom, setZoom] = useState(1.4);    // 1.0 = fit; > 1.0 = zoomed in
  const [pos, setPos] = useState(1248);
  const [showWave, setShowWave] = useState(true);
  const [showStack, setShowStack] = useState(true);
  const [collapsedGroups, setCollapsedGroups] = useState({});
  const [showSuggestModal, setShowSuggestModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);

  const selected = snips.find(s => s.id === selectedId);
  const uncategorized = snips.filter(s => !s.cats || s.cats.length === 0).length;

  // Viewport: a window of duration into the full timeline
  const viewportSecs = VIDEO_DURATION / zoom;
  const viewportCenter = Math.max(viewportSecs / 2, Math.min(VIDEO_DURATION - viewportSecs / 2, pos));
  const viewStart = viewportCenter - viewportSecs / 2;
  const viewEnd = viewStart + viewportSecs;
  const inView = (s) => s.end >= viewStart && s.start <= viewEnd;

  const pctOf = (t) => ((t - viewStart) / viewportSecs) * 100;
  const widthOf = (s) => ((s.end - s.start) / viewportSecs) * 100;

  const onTimelineClick = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - r.left;
    setPos(viewStart + (x / r.width) * viewportSecs);
  };

  // Generate ruler ticks
  const tickSecs = viewportSecs > 1800 ? 600 : viewportSecs > 600 ? 120 : viewportSecs > 240 ? 60 : 30;
  const ticks = [];
  for (let t = Math.ceil(viewStart / tickSecs) * tickSecs; t <= viewEnd; t += tickSecs) {
    ticks.push(t);
  }
  const minorTickSecs = tickSecs / 6;
  const minorTicks = [];
  for (let t = Math.ceil(viewStart / minorTickSecs) * minorTickSecs; t <= viewEnd; t += minorTickSecs) {
    if (t % tickSecs !== 0) minorTicks.push(t);
  }

  // Snips by group
  const grouped = useMemo(() => {
    const out = {};
    SNIP_GROUPS.forEach(g => out[g.id] = []);
    out["_ungrouped"] = [];
    snips.forEach(s => {
      const g = s.group || "_ungrouped";
      if (!out[g]) out[g] = [];
      out[g].push(s);
    });
    return out;
  }, [snips]);

  const groupHeaderLabel = (gid) => {
    const g = SNIP_GROUPS.find(x => x.id === gid);
    return g ? g.label : "Ungrouped";
  };

  return (
    <div className="creator">
      {/* Top toolbar */}
      <div className="creator__toolbar">
        <IconBtn icon="Undo" tooltip="Undo" hotkey="Ctrl+Z"/>
        <IconBtn icon="Redo" tooltip="Redo" hotkey="Ctrl+Shift+Z"/>
        <div className="divider-v"/>
        <Btn icon="Save" primary kbd="Ctrl+S">Save</Btn>
        <Btn ghost>Save As…</Btn>
        <Btn icon="Wand" ghost onClick={() => setShowSuggestModal(true)}>Auto-suggest from subtitles</Btn>
        <div className="flex-1"/>
        <Btn icon="AB" ghost>A/B preview <Kbd>T</Kbd></Btn>
        <div className="divider-v"/>
        <Btn icon="Upload" disabled>Upload to Hub</Btn>
        <Btn icon="Download" onClick={() => setShowExportModal(true)} disabled={uncategorized > 0}>Export .free</Btn>
      </div>

      {/* Left rail — snip list */}
      <aside className="creator__rail-left">
        <div className="snip-list__head">
          <div className="row" style={{ justifyContent: "space-between" }}>
            <div className="fz-14 fw-600">{snips.length} snips</div>
            <div className="row gap-6">
              {uncategorized > 0 && (
                <span className="chip chip--cat-needs-review">
                  <span className="dot"/>{uncategorized} need review
                </span>
              )}
            </div>
          </div>
          <div className="row" style={{ position: "relative" }}>
            <window.I.Search size={13} style={{ position: "absolute", left: 8, top: "50%", transform: "translateY(-50%)", color: "var(--text-3)" }}/>
            <input className="input input--sm" placeholder="Search snips…" style={{ paddingLeft: 26 }}/>
          </div>
        </div>
        <div className="snip-list">
          {[...SNIP_GROUPS.map(g => g.id), "_ungrouped"].map(gid => {
            const items = grouped[gid] || [];
            if (items.length === 0 && gid === "_ungrouped") return null;
            const collapsed = collapsedGroups[gid];
            return (
              <div className="snip-group" key={gid}>
                <div className="snip-group__head" onClick={() => setCollapsedGroups(c => ({ ...c, [gid]: !c[gid] }))}>
                  {collapsed ? <window.I.ChevronRight size={12}/> : <window.I.ChevronDown size={12}/>}
                  {groupHeaderLabel(gid)}
                  <span style={{ marginLeft: "auto", color: "var(--text-4)", fontFamily: "var(--font-mono)" }}>{items.length}</span>
                </div>
                {!collapsed && items.map(s => {
                  const ActIco = window.I[ACTION_BY_ID[s.action].icon];
                  return (
                    <div key={s.id}
                         className={`snip-row ${s.id === selectedId ? "is-selected" : ""}`}
                         onClick={() => { setSelectedId(s.id); setPos((s.start + s.end) / 2); }}>
                      <span className="snip-row__time mono">{fmtTime(s.start)}</span>
                      <span className="snip-row__dur mono">{Math.round(s.end - s.start)}s</span>
                      <span className="snip-row__cat">
                        {s.needsReview && <span className="chip chip--cat-needs-review" style={{ padding: "2px 6px", fontSize: 10 }}><span className="dot"/>review</span>}
                        {s.cats.slice(0, 2).map(c => {
                          const cat = CAT_BY_ID[c];
                          return cat && (
                            <span key={c} className={`chip chip--${cat.key}`} style={{ padding: "1px 6px", fontSize: 10 }}>
                              <span className="dot"/>{cat.label.replace(/^Agenda: /,"").slice(0, 10)}
                            </span>
                          );
                        })}
                        {s.cats.length > 2 && <span className="faint fz-11">+{s.cats.length - 2}</span>}
                      </span>
                      <span className="snip-row__action"><ActIco size={13}/></span>
                    </div>
                  );
                })}
              </div>
            );
          })}
          <div style={{ padding: 10 }}>
            <Btn ghost icon="Plus" style={{ width: "100%", justifyContent: "center" }}>New group</Btn>
          </div>
        </div>
      </aside>

      {/* Center — video + timeline */}
      <main className="creator__center">
        {/* Video preview */}
        <div className="creator__video" style={{ flex: "0 0 38%", minHeight: 200 }}>
          <svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
            <defs>
              <radialGradient id="vig2" cx="0.5" cy="0.4" r="0.9">
                <stop offset="0%" stopColor="#3d2a45" stopOpacity="0.95"/>
                <stop offset="100%" stopColor="#0b0610" stopOpacity="1"/>
              </radialGradient>
            </defs>
            <rect width="1600" height="900" fill="url(#vig2)"/>
            <rect x="100" y="200" width="700" height="500" fill="#1c1322" opacity="0.7"/>
            <circle cx="450" cy="380" r="70" fill="#2a1d33"/>
            <rect x="800" y="100" width="700" height="700" fill="#08050d" opacity="0.6"/>
          </svg>
          <div style={{ position: "absolute", top: 8, right: 8, padding: "3px 8px",
            background: "rgba(14,17,22,.6)", color: "white", borderRadius: 4,
            fontFamily: "var(--font-mono)", fontSize: 10.5 }}>
            PREVIEW · {fmtTime(pos, true)}
          </div>
          {selected && pos >= selected.start && pos <= selected.end && (
            <div style={{
              position: "absolute", top: 8, left: 8, padding: "3px 8px",
              background: CAT_BY_ID[selected.cats[0]]?.color || "var(--blue)",
              color: "white", borderRadius: 4,
              fontFamily: "var(--font-mono)", fontSize: 10.5, fontWeight: 600,
            }}>
              {ACTION_BY_ID[selected.action].label.toUpperCase()}
            </div>
          )}
        </div>

        {/* Video transport */}
        <div className="creator__transport">
          <IconBtn icon="StepBack" tooltip="Frame-step back" hotkey=","/>
          <IconBtn icon="Play" tooltip="Play" hotkey="Space"/>
          <IconBtn icon="StepFwd" tooltip="Frame-step fwd" hotkey="."/>
          <div className="divider-v"/>
          <IconBtn icon="TimeIn" tooltip="Mark in-point" hotkey="I"/>
          <IconBtn icon="TimeOut" tooltip="Mark out-point" hotkey="O"/>
          <div className="divider-v"/>
          <span className="transport__time tnum mono"><span className="cur">{fmtTime(pos, true)}</span> <span className="dim">/ {fmtTime(VIDEO_DURATION)}</span></span>
          <span className="faint fz-11 mono" style={{ marginLeft: 12 }}>fr {Math.floor(pos * 23.976)}</span>
          <div className="flex-1"/>
          <Seg value="1" onChange={() => {}} options={[
            { value: "0.5", label: "½×" },
            { value: "1", label: "1×" },
            { value: "2", label: "2×" },
          ]}/>
          <div className="divider-v"/>
          <IconBtn icon="Wave" tooltip="Toggle waveform" on={showWave} onClick={() => setShowWave(!showWave)}/>
          <IconBtn icon="Layers" tooltip="Toggle stacked profile context" on={showStack} onClick={() => setShowStack(!showStack)}/>
          <div className="divider-v"/>
          <IconBtn icon="Minus" tooltip="Zoom out" onClick={() => setZoom(z => Math.max(1, z / 1.4))}/>
          <span className="faint fz-11 mono">{zoom.toFixed(1)}×</span>
          <IconBtn icon="Plus" tooltip="Zoom in" onClick={() => setZoom(z => Math.min(40, z * 1.4))}/>
          <IconBtn icon="Maximize" tooltip="Fit timeline to window" onClick={() => setZoom(1)}/>
        </div>

        {/* Timeline */}
        <div className="creator__timeline">
          {/* Ruler */}
          <div className="timeline__row timeline__ruler" onClick={onTimelineClick}>
            <div className="timeline__row-label">Time</div>
            <div className="timeline__row-body" style={{ position: "relative", height: 24 }}>
              {minorTicks.map(t => (
                <div key={"m"+t} className="timeline__ruler-tick" style={{ left: `${pctOf(t)}%` }}/>
              ))}
              {ticks.map(t => (
                <React.Fragment key={t}>
                  <div className="timeline__ruler-tick major" style={{ left: `${pctOf(t)}%` }}/>
                  <div className="timeline__ruler-label" style={{ left: `${pctOf(t)}%` }}>{fmtTime(t)}</div>
                </React.Fragment>
              ))}
              {/* chapter ticks */}
              {[0.12, 0.27, 0.41, 0.55, 0.68, 0.78, 0.92].map((c, i) => {
                const t = c * VIDEO_DURATION;
                if (t < viewStart || t > viewEnd) return null;
                return <div key={"ch"+i} style={{ position: "absolute", top: 0, left: `${pctOf(t)}%`, fontSize: 9, color: "var(--text-3)", transform: "translateX(-50%)" }}>▼</div>;
              })}
              <div className="timeline__playhead" style={{ left: `${pctOf(pos)}%` }}/>
            </div>
          </div>

          {/* Waveform */}
          {showWave && (
            <div className="timeline__row timeline__wave">
              <div className="timeline__row-label">Audio</div>
              <div className="timeline__row-body" style={{ position: "relative", height: 56 }} onClick={onTimelineClick}>
                <svg width="100%" height="56" preserveAspectRatio="none" viewBox="0 0 1000 56">
                  {Array.from({length: 200}, (_, i) => {
                    // pseudo-random but seeded
                    const seed = (i * 9301 + 49297 + viewStart) % 233280;
                    const r = (seed / 233280);
                    const h = 6 + Math.abs(Math.sin(i * 0.3 + viewStart * 0.01)) * 22 + r * 16;
                    return <rect key={i} x={i * 5 + 1} y={28 - h/2} width="3" height={h} fill="var(--text-3)" opacity="0.7"/>;
                  })}
                </svg>
                <div className="timeline__playhead" style={{ left: `${pctOf(pos)}%` }}/>
              </div>
            </div>
          )}

          {/* Scene changes */}
          <div className="timeline__row timeline__scene">
            <div className="timeline__row-label">Scenes</div>
            <div className="timeline__row-body" style={{ position: "relative", height: 18 }}>
              {Array.from({length: Math.floor(viewportSecs / 30)}, (_, i) => {
                const t = viewStart + (i + 0.3 + Math.sin(i*7.13)*0.4) * (viewportSecs / Math.floor(viewportSecs / 30));
                return <div key={i} className="timeline__scene-tick" style={{ left: `${pctOf(t)}%` }}/>;
              })}
              <div className="timeline__playhead" style={{ left: `${pctOf(pos)}%` }}/>
            </div>
          </div>

          {/* Snip layer */}
          <div className="timeline__row timeline__snip-layer" style={{ height: 80 }}>
            <div className="timeline__row-label">Snips</div>
            <div className="timeline__row-body" style={{ position: "relative", height: 80 }} onClick={onTimelineClick}>
              {snips.filter(inView).map(s => {
                const cat = s.cats[0] ? CAT_BY_ID[s.cats[0]] : null;
                const left = pctOf(s.start);
                const width = Math.max(widthOf(s), 0.5);
                const isSel = s.id === selectedId;
                const bg = cat ? cat.color : "var(--cat-needs-review)";
                return (
                  <div key={s.id}
                       className={`snip-block ${isSel ? "is-selected" : ""} ${s.needsReview ? "is-needs-review" : ""}`}
                       style={{ left: `${left}%`, width: `${width}%`, background: bg }}
                       onClick={(e) => { e.stopPropagation(); setSelectedId(s.id); }}>
                    <div className="snip-block__edge left"/>
                    <div className="snip-block__head">
                      <span className="mono">{fmtTime(s.start)}</span>
                      <span>{ACTION_BY_ID[s.action].label[0]}</span>
                    </div>
                    {width > 4 && (
                      <div className="snip-block__label">
                        {s.cats.map(c => CAT_BY_ID[c]?.label).filter(Boolean).join(", ") || "Needs review"}
                      </div>
                    )}
                    <div className="snip-block__edge right"/>
                  </div>
                );
              })}
              <div className="timeline__playhead" style={{ left: `${pctOf(pos)}%` }}/>
            </div>
          </div>

          {/* Stacked profile context */}
          {showStack && (
            <div className="timeline__row timeline__stack">
              <div className="timeline__row-label">Stack: No Filler</div>
              <div className="timeline__row-body" style={{ position: "relative", height: 22 }}>
                {/* show some grey blocks */}
                {[{start: 480, end: 660}, {start: 2050, end: 2120}, {start: 3700, end: 3890}, {start: 5240, end: 5380}].map((s, i) => {
                  if (s.end < viewStart || s.start > viewEnd) return null;
                  return (
                    <div key={i} className="timeline__stack-block" style={{
                      left: `${pctOf(s.start)}%`, width: `${pctOf(s.end) - pctOf(s.start)}%`,
                      color: "var(--cat-boring)", background: "color-mix(in oklab, var(--cat-boring) 10%, white)",
                    }}/>
                  );
                })}
                <div className="timeline__playhead" style={{ left: `${pctOf(pos)}%` }}/>
              </div>
            </div>
          )}

          {/* Subtitle */}
          <div className="timeline__row timeline__subtitle">
            <div className="timeline__row-label">Subtitle</div>
            <div className="timeline__row-body" style={{ position: "relative", height: 22 }}>
              {[
                { start: viewStart + 8, end: viewStart + 14, text: "I told you not to come." },
                { start: viewStart + 22, end: viewStart + 28, text: "What the hell were you thinking?" },
                { start: viewStart + 40, end: viewStart + 46, text: "Just leave me alone." },
                { start: viewStart + 60, end: viewStart + 64, text: "[door slams]" },
              ].map((sub, i) => (
                <div key={i} className="timeline__sub-block"
                     style={{ left: `${pctOf(sub.start)}%`, width: `${pctOf(sub.end) - pctOf(sub.start)}%` }}>
                  {sub.text}
                </div>
              ))}
              <div className="timeline__playhead" style={{ left: `${pctOf(pos)}%` }}/>
            </div>
          </div>

          <div style={{ flex: 1, background: "var(--surface-2)" }}/>
        </div>
      </main>

      {/* Right rail — snip detail */}
      <aside className="creator__rail-right">
        {selected ? <SnipDetail snip={selected} setSnips={setSnips} snips={snips}/> : <EmptyDetail/>}
      </aside>

      {/* Status bar (we'll position with grid) */}
      <div style={{ gridColumn: "1 / -1", display: "flex", alignItems: "center",
        padding: "0 12px", borderTop: "1px solid var(--border)", background: "var(--surface-2)",
        height: 26, fontSize: 11.5, color: "var(--text-2)", fontFamily: "var(--font-mono)" }}>
        <span className="chip chip--cat-needs-review" style={{ padding: "1px 8px", fontSize: 10.5 }}>
          <window.I.Drop size={10}/> Draft mode
        </span>
        <div className="flex-1"/>
        <span><span className="statusbar__dot"/> Autosaved 8s ago</span>
        <span style={{ margin: "0 12px" }}>·</span>
        <span>Scene-change: 247 markers</span>
        <span style={{ margin: "0 12px" }}>·</span>
        <span>{snips.length} snips · cut {fmtTime(snips.reduce((a, s) => a + (s.end - s.start), 0))}</span>
      </div>

      {showSuggestModal && <SubtitleSuggestModal onClose={() => setShowSuggestModal(false)}/>}
      {showExportModal && <ExportModal snips={snips} onClose={() => setShowExportModal(false)}/>}
    </div>
  );
};

const EmptyDetail = () => (
  <div style={{ padding: 24, color: "var(--text-3)", fontSize: 12.5, lineHeight: 1.6 }}>
    <window.I.Cut size={20} className="dim"/>
    <div style={{ marginTop: 12, fontWeight: 600, color: "var(--text-2)" }}>No snip selected</div>
    <div style={{ marginTop: 8 }}>
      Click a snip in the timeline or list to edit it. Or:
    </div>
    <ul style={{ marginTop: 8, paddingLeft: 16 }}>
      <li>Drag on the snip layer to create one</li>
      <li>Press <span className="kbd">I</span> / <span className="kbd">O</span> at the playhead</li>
      <li>Right-click the snip layer for more</li>
    </ul>
  </div>
);

const SnipDetail = ({ snip, setSnips, snips }) => {
  const { fmtTime, IconBtn, Btn, Kbd, CatChip, Toggle } = window.UI;
  const { CATEGORIES, CAT_BY_ID, ACTIONS } = window.FVPData;

  const updateSnip = (patch) => setSnips(arr => arr.map(s => s.id === snip.id ? { ...s, ...patch } : s));
  const removeCat = (cid) => updateSnip({ cats: snip.cats.filter(c => c !== cid) });
  const dur = snip.end - snip.start;
  const [showPicker, setShowPicker] = useState(false);

  return (
    <div className="snip-detail">
      <div className="row" style={{ justifyContent: "space-between" }}>
        <div className="snip-detail__title">
          {snip.needsReview ? <span className="chip chip--cat-needs-review"><span className="dot"/>needs review</span> : `Snip ${snip.id.replace("s", "#")}`}
        </div>
        <div className="row gap-4">
          <IconBtn icon="Play" tooltip="Preview snip" hotkey="Enter"/>
          <IconBtn icon="Trash" tooltip="Delete snip" hotkey="Delete" danger/>
        </div>
      </div>

      <div className="row gap-12">
        <div className="snip-detail__field" style={{ flex: 1 }}>
          <div className="snip-detail__field-label">Start</div>
          <input className="input input--sm mono" value={fmtTime(snip.start, true)} readOnly/>
        </div>
        <div className="snip-detail__field" style={{ flex: 1 }}>
          <div className="snip-detail__field-label">End</div>
          <input className="input input--sm mono" value={fmtTime(snip.end, true)} readOnly/>
        </div>
      </div>
      <div className="snip-detail__field">
        <div className="snip-detail__field-label">Duration</div>
        <div className="row gap-8">
          <div className="mono fz-14 fw-600">{fmtTime(dur, true)}</div>
          <span className="faint fz-11">≈ {Math.round(dur * 23.976)} frames</span>
        </div>
      </div>

      <div className="snip-detail__field">
        <div className="snip-detail__field-label">Categories</div>
        <div className="row gap-4" style={{ flexWrap: "wrap" }}>
          {snip.cats.map(c => <CatChip key={c} catId={c} onRemove={() => removeCat(c)}/>)}
          <button className="chip chip--outline cursor-pointer" onClick={() => setShowPicker(s => !s)}>
            <window.I.Plus size={10} strokeWidth={2.5}/> Add
          </button>
        </div>
        {showPicker && (
          <div className="card" style={{ marginTop: 8, maxHeight: 180, overflow: "auto" }}>
            {CATEGORIES.filter(c => !snip.cats.includes(c.id)).map(c => (
              <div key={c.id}
                   className="row gap-8"
                   style={{ padding: "5px 10px", cursor: "pointer" }}
                   onClick={() => { updateSnip({ cats: [...snip.cats, c.id], needsReview: false }); setShowPicker(false); }}
                   onMouseEnter={(e) => e.currentTarget.style.background = "var(--hover)"}
                   onMouseLeave={(e) => e.currentTarget.style.background = ""}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: c.color }}/>
                <span className="fz-12">{c.label}</span>
                <span className="faint fz-11" style={{ marginLeft: "auto" }}>{c.defaultAction}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="snip-detail__field">
        <div className="snip-detail__field-label">Action (override)</div>
        <div className="col gap-4">
          {ACTIONS.map(a => {
            const Ico = window.I[a.icon];
            return (
              <label key={a.id}
                     className="row gap-8 cursor-pointer"
                     style={{ padding: "6px 8px", border: "1px solid var(--border)", borderRadius: 6,
                       background: snip.action === a.id ? "var(--blue-soft)" : "var(--surface)",
                       borderColor: snip.action === a.id ? "var(--blue)" : "var(--border)" }}>
                <input type="radio" name="action" checked={snip.action === a.id} onChange={() => updateSnip({ action: a.id })} style={{ accentColor: "var(--blue)" }}/>
                <Ico size={14} style={{ color: snip.action === a.id ? "var(--blue)" : "var(--text-2)" }}/>
                <div className="col" style={{ flex: 1 }}>
                  <span className="fz-12 fw-500">{a.label}</span>
                  <span className="faint fz-11">{a.hint}</span>
                </div>
              </label>
            );
          })}
        </div>
        {snip.action === "replace" && (
          <div className="card" style={{ padding: 10, marginTop: 8, background: "var(--surface-2)" }}>
            <div className="snip-detail__field-label">Audio source direction</div>
            <Seg value="before" onChange={() => {}} options={[
              { value: "before", label: "← Before" },
              { value: "after",  label: "After →" },
            ]}/>
            <div className="row gap-8 fz-11" style={{ marginTop: 8, color: "var(--text-2)" }}>
              <window.I.Info size={12}/> Need {fmtTime(snip.end - snip.start)} of audio. 18.4s available before the snip — looks OK.
            </div>
          </div>
        )}
      </div>

      <div className="snip-detail__field">
        <div className="snip-detail__field-label">Notes</div>
        <textarea className="input" rows="2" placeholder="(optional)" defaultValue={snip.note}/>
      </div>
    </div>
  );
};

const Seg = (props) => window.UI.Seg(props);

const SubtitleSuggestModal = ({ onClose }) => {
  const { Btn, IconBtn, Kbd, fmtTime } = window.UI;
  const [padBefore, setPadBefore] = useState(200);
  const [padAfter, setPadAfter] = useState(300);

  const hits = [
    { t: 184.2, word: "damn", line: "I told her, what the damn deal was." },
    { t: 412.1, word: "f***", line: "What the f*** were you thinking?" },
    { t: 718.4, word: "hell", line: "Just get the hell out of here." },
    { t: 1336.2, word: "sh**", line: "Sh** like that never works." },
    { t: 1985.0, word: "damn", line: "Damn it, I knew this would happen." },
    { t: 3424.7, word: "ass", line: "He's been an ass all night." },
    { t: 3704.5, word: "hell", line: "Hell, I told you so." },
    { t: 4524.3, word: "f***", line: "F***ing finally." },
    { t: 6084.9, word: "damn", line: "Damn good ending." },
  ];

  const [checked, setChecked] = useState(() => new Set(hits.map((_, i) => i)));

  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" style={{ minWidth: 640, maxWidth: 760 }} onClick={(e) => e.stopPropagation()}>
        <div className="modal__head">
          <div className="row" style={{ justifyContent: "space-between" }}>
            <div>
              <div className="modal__title">Auto-suggest snips from subtitles</div>
              <div className="modal__sub">9 matches in <span className="mono">.srt</span> against your wordlist. Pre-categorized as "language."</div>
            </div>
            <IconBtn icon="Close" tooltip="Close" onClick={onClose}/>
          </div>
        </div>
        <div className="modal__body" style={{ padding: 0 }}>
          <div className="row gap-12" style={{ padding: "12px 20px", background: "var(--surface-2)", borderBottom: "1px solid var(--divider)" }}>
            <div className="col gap-4" style={{ flex: 1 }}>
              <div className="snip-detail__field-label">Padding before</div>
              <input className="input input--sm mono" value={`${padBefore} ms`} readOnly/>
            </div>
            <div className="col gap-4" style={{ flex: 1 }}>
              <div className="snip-detail__field-label">Padding after</div>
              <input className="input input--sm mono" value={`${padAfter} ms`} readOnly/>
            </div>
            <div className="col gap-4" style={{ flex: 1 }}>
              <div className="snip-detail__field-label">Default category</div>
              <span className="chip chip--cat-language"><span className="dot"/>Language</span>
            </div>
          </div>
          <div style={{ maxHeight: 320, overflow: "auto" }}>
            <table className="hotkey-table">
              <thead>
                <tr><th style={{ width: 28 }}></th><th>Time</th><th>Word</th><th>Excerpt</th><th>Span</th></tr>
              </thead>
              <tbody>
                {hits.map((h, i) => (
                  <tr key={i}>
                    <td><input type="checkbox" checked={checked.has(i)} onChange={() => {
                      setChecked(c => { const n = new Set(c); n.has(i) ? n.delete(i) : n.add(i); return n; });
                    }} style={{ accentColor: "var(--blue)" }}/></td>
                    <td className="mono fz-12">{fmtTime(h.t)}</td>
                    <td><span className="chip chip--cat-language" style={{ padding: "1px 6px", fontSize: 10.5 }}>{h.word}</span></td>
                    <td className="fz-12 dim" style={{ maxWidth: 320, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{h.line}</td>
                    <td className="mono fz-11 faint">+{padBefore/1000}s / +{padAfter/1000}s</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="modal__foot">
          <span className="faint fz-11">Wordlist: <a href="#">Bundled v2.1 + your 23 custom words</a></span>
          <div className="flex-1"/>
          <Btn ghost onClick={onClose}>Cancel</Btn>
          <Btn primary>Accept {checked.size} as snips</Btn>
        </div>
      </div>
    </div>
  );
};

const ExportModal = ({ snips, onClose }) => {
  const { Btn, IconBtn, Toggle, fmtTime } = window.UI;
  const totalCut = snips.reduce((a, s) => a + (s.end - s.start), 0);
  const catCounts = {};
  snips.forEach(s => s.cats.forEach(c => { catCounts[c] = (catCounts[c] || 0) + 1; }));
  const [uploadAfter, setUploadAfter] = useState(false);
  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal__head">
          <div className="modal__title">Export profile to <span className="mono">.free</span></div>
          <div className="modal__sub">Schema v3 · written next to the video file</div>
        </div>
        <div className="modal__body">
          <div className="card" style={{ padding: 14, background: "var(--surface-2)" }}>
            <div className="row gap-24">
              <div className="col gap-4">
                <div className="snip-detail__field-label">Snips</div>
                <div className="fz-20 fw-600 mono">{snips.length}</div>
              </div>
              <div className="col gap-4">
                <div className="snip-detail__field-label">Will cut</div>
                <div className="fz-20 fw-600 mono">{fmtTime(totalCut)}</div>
              </div>
              <div className="col gap-4" style={{ flex: 1 }}>
                <div className="snip-detail__field-label">Categories</div>
                <div className="row gap-4" style={{ flexWrap: "wrap" }}>
                  {Object.entries(catCounts).map(([c, n]) => {
                    const cat = window.FVPData.CAT_BY_ID[c];
                    return cat && (
                      <span key={c} className={`chip chip--${cat.key}`}>
                        <span className="dot"/>{cat.label} · {n}
                      </span>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
          <div className="snip-detail__field" style={{ marginTop: 16 }}>
            <div className="snip-detail__field-label">Filename</div>
            <input className="input mono" defaultValue="The.Pinnacle.2024.1080p.BluRay.x265.free"/>
          </div>
          <div className="row" style={{ marginTop: 12 }}>
            <Toggle on={uploadAfter} onChange={setUploadAfter}/>
            <span className="fz-12 dim" style={{ marginLeft: 10 }}>Upload to FVP Hub after save (uploader key loaded as <strong>@straightedge</strong>)</span>
          </div>
        </div>
        <div className="modal__foot">
          <Btn ghost onClick={onClose}>Cancel</Btn>
          <Btn primary icon="Save">Save .free</Btn>
        </div>
      </div>
    </div>
  );
};

window.Creator = Creator;
