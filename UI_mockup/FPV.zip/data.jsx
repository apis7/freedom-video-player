/* ---------- Sample data ---------- */

const CATEGORIES = [
  { id: "language",  label: "Language",       color: "var(--cat-language)",   key: "cat-language",   defaultAction: "skip",   bundled: true },
  { id: "sex",       label: "Sex",            color: "var(--cat-sex)",        key: "cat-sex",        defaultAction: "skip",   bundled: true },
  { id: "nudity",    label: "Nudity",         color: "var(--cat-sex)",        key: "cat-sex",        defaultAction: "skip",   bundled: true },
  { id: "violence",  label: "Violence",       color: "var(--cat-violence)",   key: "cat-violence",   defaultAction: "silence",bundled: true },
  { id: "gore",      label: "Gore",           color: "var(--cat-violence)",   key: "cat-violence",   defaultAction: "skip",   bundled: true },
  { id: "boring",    label: "Boring",         color: "var(--cat-boring)",     key: "cat-boring",     defaultAction: "skip",   bundled: true },
  { id: "substance", label: "Substance use",  color: "var(--cat-substance)",  key: "cat-substance",  defaultAction: "silence",bundled: true },
  { id: "agenda-fem",label: "Agenda: feminism",   color: "var(--cat-agenda)", key: "cat-agenda",     defaultAction: "skip",   bundled: true },
  { id: "agenda-lgbt",label:"Agenda: LGBTQ+",     color: "var(--cat-agenda)", key: "cat-agenda",     defaultAction: "skip",   bundled: true },
  { id: "agenda-soc",label: "Agenda: socialism",  color: "var(--cat-agenda)", key: "cat-agenda",     defaultAction: "skip",   bundled: true },
  { id: "agenda-ath",label: "Agenda: atheism",    color: "var(--cat-agenda)", key: "cat-agenda",     defaultAction: "silence",bundled: true },
  { id: "horror",    label: "Horror/jump-scare", color: "var(--cat-violence)",key: "cat-violence",   defaultAction: "freeze", bundled: false },
];

const CAT_BY_ID = Object.fromEntries(CATEGORIES.map(c => [c.id, c]));

const ACTIONS = [
  { id: "skip",    label: "Skip",          icon: "SkipForward",  hint: "Seamlessly jump over the segment" },
  { id: "silence", label: "Silence",       icon: "Mute",         hint: "Plays segment with audio muted" },
  { id: "replace", label: "Audio-replace", icon: "Sync",         hint: "Video plays; audio cloned from adjacent" },
  { id: "freeze",  label: "Freeze-frame",  icon: "Snowflake",    hint: "Freezes first frame, audio continues" },
];

const ACTION_BY_ID = Object.fromEntries(ACTIONS.map(a => [a.id, a]));

// A demo film with snips ~ 1h 47m
const VIDEO_DURATION = 6420; // seconds

const SNIP_GROUPS = [
  { id: "g-opening", label: "Opening" },
  { id: "g-hotel",   label: "Hotel scene" },
  { id: "g-finale",  label: "Finale battle" },
  { id: "g-language",label: "Misc. language" },
];

const SNIPS = [
  { id: "s1", start: 180,  end: 192,  cats: ["language"], action: "skip", group: "g-opening", note: "" },
  { id: "s2", start: 410,  end: 472,  cats: ["language", "substance"], action: "skip", group: "g-opening", note: "Bar argument" },
  { id: "s3", start: 715,  end: 727,  cats: ["language"], action: "silence", group: "g-language", note: "" },
  { id: "s4", start: 1184, end: 1318, cats: ["sex", "nudity"], action: "skip", group: "g-hotel", note: "Full hotel scene" },
  { id: "s5", start: 1334, end: 1346, cats: ["language"], action: "skip", group: "g-hotel", note: "" },
  { id: "s6", start: 1980, end: 1990, cats: ["language"], action: "silence", group: "g-language" },
  { id: "s7", start: 2110, end: 2185, cats: ["boring"], action: "skip", group: null, note: "Subplot detour" },
  { id: "s8", start: 2640, end: 2654, cats: ["gore"], action: "freeze", group: null, note: "Tooth scene" },
  { id: "s9", start: 2980, end: 3050, cats: ["agenda-soc"], action: "skip", group: null, note: "Speech" },
  { id: "s10",start: 3420, end: 3431, cats: ["language"], action: "skip", group: "g-language" },
  { id: "s11",start: 3700, end: 3712, cats: ["language"], action: "silence", group: "g-language" },
  { id: "s12",start: 4220, end: 4292, cats: ["violence", "gore"], action: "skip", group: "g-finale", note: "Decapitation" },
  { id: "s13",start: 4310, end: 4380, cats: ["violence"], action: "silence", group: "g-finale" },
  { id: "s14",start: 4520, end: 4544, cats: ["language", "violence"], action: "skip", group: "g-finale" },
  { id: "s15",start: 5180, end: 5188, cats: [], action: "skip", group: null, needsReview: true },
  { id: "s16",start: 5500, end: 5512, cats: [], action: "skip", group: null, needsReview: true },
  { id: "s17",start: 5810, end: 5868, cats: ["sex"], action: "skip", group: null, note: "Implied" },
  { id: "s18",start: 6080, end: 6094, cats: ["language"], action: "skip", group: "g-language" },
];

const PROFILES_FOR_FILE = [
  {
    id: "p1", name: "Family Friendly", version: "v3", uploader: "@straightedge", local: false,
    snipCount: 47, totalCut: "12m 18s", downloads: 4280, upvotes: 612,
    cats: ["language", "sex", "nudity", "violence", "gore"], primary: true, active: true,
  },
  {
    id: "p2", name: "No Filler", version: "v2", uploader: "@brevity", local: false,
    snipCount: 8, totalCut: "9m 42s", downloads: 1108, upvotes: 188,
    cats: ["boring"], primary: false, active: true,
  },
  {
    id: "p3", name: "Date Night", version: "v1", uploader: "your local", local: true,
    snipCount: 22, totalCut: "6m 04s", downloads: 0, upvotes: 0,
    cats: ["gore", "violence"], primary: false, active: false,
  },
];

const RECENT_FILES = [
  { name: "The.Pinnacle.2024.1080p.BluRay.x265.mkv",     last: "Today, 8:14 PM",  runtime: "1:47:00", profile: "stacked", n: 2 },
  { name: "Driftwood (2022) — Director's Cut.mp4",       last: "Yesterday",       runtime: "2:14:00", profile: "has" },
  { name: "S07E03 — The Long Goodbye.mkv",               last: "Mon, 9:32 PM",    runtime: "0:58:00", profile: "draft" },
  { name: "Halcyon.Years.S01.Complete\\E01.mkv",         last: "Mon, 7:01 PM",    runtime: "0:46:00", profile: "none" },
  { name: "Family.Vacation.Trailer.webm",                last: "Sat, 2:11 PM",    runtime: "0:02:18", profile: "hub" },
  { name: "Concert.Cut.1994.avi",                         last: "Sep 18",          runtime: "1:28:00", profile: "has" },
  { name: "Documentary — Coastal Light.mkv",              last: "Sep 14",          runtime: "0:52:00", profile: "none" },
  { name: "Old.Western.mpg",                              last: "Sep 12",          runtime: "1:36:00", profile: "has" },
];

const QUEUE = [
  { name: "The.Pinnacle.2024.1080p.BluRay.x265.mkv",     runtime: "1:47:00", profile: "stacked", current: true },
  { name: "The.Pinnacle.Extras.Commentary.mkv",          runtime: "1:47:12", profile: "none" },
  { name: "The.Pinnacle.Behind.the.Scenes.mp4",          runtime: "0:42:18", profile: "draft" },
];

const HOTKEYS = {
  player: [
    ["Space", "Play / Pause"],
    ["F", "Fullscreen toggle"],
    ["M", "Mute toggle"],
    ["↑ / ↓", "Volume + / −"],
    ["← / →", "Seek −5s / +5s"],
    ["Ctrl + ← / →", "Seek −10s / +10s"],
    ["Shift + ← / →", "Seek −1m / +1m"],
    [", / .", "Frame-step ← / →"],
    ["N / B", "Next / Previous file"],
    ["R", "Cycle Repeat"],
    ["X", "Shuffle"],
    ["T", "A/B profile toggle"],
    ["?", "This cheatsheet"],
    ["Esc", "Exit fullscreen / dialog"],
    ["Ctrl+O", "Open file(s)"],
    ["Ctrl+Shift+O", "Open folder"],
  ],
  skipthat: [
    ["[", "Start snip 10s ago"],
    ["\\", "Start snip now"],
    ["]", "Stop current snip"],
    ["Q", "Quick 10s snip"],
  ],
  creator: [
    ["I / O", "In / Out at current frame"],
    ["Ctrl + ← / →", "Nudge edge 1s"],
    ["Ctrl+Shift + ← / →", "Nudge edge 5s"],
    ["Enter", "Preview selected snip"],
    ["Delete", "Delete selected snip"],
    ["Tab", "Next snip"],
    ["Ctrl+G", "Group selected"],
    ["Ctrl+E", "Edit categories/action"],
    ["Ctrl+Z / Shift+Ctrl+Z", "Undo / Redo"],
    ["Ctrl+S", "Save profile"],
  ],
};

/* Library titles */
const LIB_TITLES = [
  // (poster generated; we'll color it w/ a placeholder gradient based on hue)
  { id: "t1",  title: "The Pinnacle",        year: 2024, runtime: 107, rating: "PG-13", genre: "Thriller", profile: "stacked", n: 2, hue: 220, watched: 0.34, hasCw: true },
  { id: "t2",  title: "Driftwood",           year: 2022, runtime: 134, rating: "R",     genre: "Drama",    profile: "has",      hue: 30,  watched: 1.0, hasCw: true },
  { id: "t3",  title: "Halcyon Years",       year: 2023, runtime: 46,  rating: "TV-MA", genre: "Series",   profile: "draft",    hue: 160, watched: 0.62, isSeries: true },
  { id: "t4",  title: "Coastal Light",       year: 2021, runtime: 52,  rating: "PG",    genre: "Doc",      profile: "none",     hue: 200, watched: 0 },
  { id: "t5",  title: "Old Western",         year: 1972, runtime: 96,  rating: "PG",    genre: "Western",  profile: "has",      hue: 18,  watched: 1.0 },
  { id: "t6",  title: "Family Vacation",     year: 2024, runtime: 92,  rating: "PG",    genre: "Comedy",   profile: "hub",      hue: 50,  watched: 0 },
  { id: "t7",  title: "Concert Cut '94",     year: 1994, runtime: 88,  rating: "NR",    genre: "Music",    profile: "has",      hue: 290, watched: 0 },
  { id: "t8",  title: "Steel & Iron",        year: 2020, runtime: 121, rating: "R",     genre: "Action",   profile: "stacked", n: 3, hue: 0,   watched: 0 },
  { id: "t9",  title: "Quiet Country Road",  year: 2019, runtime: 99,  rating: "PG-13", genre: "Drama",    profile: "has",      hue: 100, watched: 0 },
  { id: "t10", title: "Astrolabe",           year: 2025, runtime: 144, rating: "PG-13", genre: "SciFi",    profile: "hub",      hue: 240, watched: 0 },
  { id: "t11", title: "Lonely Engine",       year: 2018, runtime: 78,  rating: "NR",    genre: "Indie",    profile: "none",     hue: 340, watched: 0 },
  { id: "t12", title: "Highrise Stories",    year: 2023, runtime: 110, rating: "R",     genre: "Drama",    profile: "has",      hue: 180, watched: 0 },
  { id: "t13", title: "Snow Patrol",         year: 2017, runtime: 105, rating: "PG-13", genre: "Adventure",profile: "stacked", n: 2, hue: 195, watched: 0 },
  { id: "t14", title: "The Pinnacle 2",      year: 2026, runtime: 118, rating: "PG-13", genre: "Thriller", profile: "none",     hue: 230, watched: 0 },
  { id: "t15", title: "Garage Days",         year: 2015, runtime: 89,  rating: "PG",    genre: "Comedy",   profile: "has",      hue: 70,  watched: 0 },
  { id: "t16", title: "Bone & Bramble",      year: 2024, runtime: 132, rating: "R",     genre: "Horror",   profile: "draft",    hue: 8,   watched: 0 },
];

const VIEWERS = [
  { id: "v1", name: "Mom",   color: "#1f3fbf", strict: "Family" },
  { id: "v2", name: "Dad",   color: "#b91c2a", strict: "Standard" },
  { id: "v3", name: "Kids",  color: "#0c7c43", strict: "Kids" },
];

const MOODS = [
  { id: "fam",  label: "Family movie night", desc: "Family-tier profile available", count: 24 },
  { id: "date", label: "Date night safe",    desc: "Cuts sex/violence above threshold", count: 17 },
  { id: "act",  label: "Action — no gore",   desc: "Action films with gore cut", count: 9 },
  { id: "kids", label: "Kid-friendly",       desc: "Kids viewer profile applies", count: 14 },
  { id: "q",    label: "Quick (≤90 min)",    desc: "Runtime under 90 minutes", count: 38 },
];

const STAT_CATS = [
  { id: "language", label: "Language",  amount: "47h 12m",  hours: 47.2, color: "var(--cat-language)" },
  { id: "sex",      label: "Sex",       amount: "18h 06m",  hours: 18.1, color: "var(--cat-sex)" },
  { id: "boring",   label: "Boring",    amount: "12h 41m",  hours: 12.7, color: "var(--cat-boring)" },
  { id: "violence", label: "Violence",  amount: "9h 22m",   hours: 9.4,  color: "var(--cat-violence)" },
  { id: "agenda",   label: "Agenda",    amount: "3h 14m",   hours: 3.3,  color: "var(--cat-agenda)" },
  { id: "substance",label: "Substance", amount: "1h 41m",   hours: 1.7,  color: "var(--cat-substance)" },
];

const LEADERBOARD = [
  { title: "Halcyon Years (S01)", cut: "7h 12m", spark: [3,5,4,8,6,9,7,8,6,4,7] },
  { title: "The Pinnacle",         cut: "1h 26m", spark: [2,3,2,4,5,4,6,5,5,3] },
  { title: "Driftwood",            cut: "1h 04m", spark: [1,2,2,3,3,4,5,4,3,2] },
  { title: "Steel & Iron",         cut: "0h 58m", spark: [1,1,2,3,2,3,4,3,2,1] },
  { title: "Highrise Stories",     cut: "0h 47m", spark: [1,2,1,2,2,3,3,2,2,1] },
];

const HEALTH_ISSUES = [
  { title: "Driftwood (2022) — Director's Cut.mp4", issue: "Fingerprint drift", desc: "File was re-encoded after profile created", action: "Refresh fingerprint", severity: "warn" },
  { title: "Old.Western.mpg",                       issue: "Missing file",       desc: "Original folder is unreachable: D:\\Movies\\Westerns", action: "Relink…",            severity: "error" },
  { title: "Halcyon S01E07.mkv",                    issue: "Deprecated category",desc: "Profile uses 'agenda:moral-relativism', no longer in canonical list", action: "Update profile", severity: "warn" },
  { title: "Concert.Cut.1994.avi",                  issue: "Duplicate detected", desc: "Same fingerprint found in another folder", action: "Review…",                     severity: "info" },
];

window.FVPData = {
  CATEGORIES, CAT_BY_ID, ACTIONS, ACTION_BY_ID,
  VIDEO_DURATION, SNIP_GROUPS, SNIPS,
  PROFILES_FOR_FILE, RECENT_FILES, QUEUE, HOTKEYS,
  LIB_TITLES, VIEWERS, MOODS,
  STAT_CATS, LEADERBOARD, HEALTH_ISSUES,
};
