/* Icons — Lucide-ish outline, 1.5px strokes, 16px viewBox */
const Icon = ({ d, paths, fill, size = 16, strokeWidth = 1.5, className, children, ...rest }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill={fill || "none"}
    stroke="currentColor"
    strokeWidth={strokeWidth}
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...rest}
  >
    {d && <path d={d} />}
    {paths && paths.map((p, i) => <path key={i} d={p} />)}
    {children}
  </svg>
);

const I = {
  Play: (p) => <Icon {...p} fill="currentColor" stroke="none"><path d="M7 5.5a1 1 0 0 1 1.55-.83l10 6.5a1 1 0 0 1 0 1.66l-10 6.5A1 1 0 0 1 7 18.5v-13Z"/></Icon>,
  Pause: (p) => <Icon {...p} fill="currentColor" stroke="none"><rect x="7" y="5" width="3.5" height="14" rx="1"/><rect x="13.5" y="5" width="3.5" height="14" rx="1"/></Icon>,
  Stop: (p) => <Icon {...p} fill="currentColor" stroke="none"><rect x="6" y="6" width="12" height="12" rx="1.5"/></Icon>,
  SkipBack: (p) => <Icon {...p} fill="currentColor" stroke="none"><path d="M5 5a1 1 0 0 1 2 0v6.13l8.45-5.96A1 1 0 0 1 17 6v12a1 1 0 0 1-1.55.83L7 12.87V19a1 1 0 0 1-2 0V5Z"/></Icon>,
  SkipForward: (p) => <Icon {...p} fill="currentColor" stroke="none"><path d="M19 5a1 1 0 0 0-2 0v6.13L8.55 5.17A1 1 0 0 0 7 6v12a1 1 0 0 0 1.55.83L17 12.87V19a1 1 0 0 0 2 0V5Z"/></Icon>,
  StepBack: (p) => <Icon {...p}><path d="M14 5v14M14 12 5 5v14Z" fill="currentColor"/></Icon>,
  StepFwd: (p) => <Icon {...p}><path d="M10 5v14M10 12l9-7v14Z" fill="currentColor"/></Icon>,
  Shuffle: (p) => <Icon {...p}><path d="M16 4h4v4M20 4l-6 6M4 4l16 16M20 16v4h-4M14 14l6 6M4 20l5-5"/></Icon>,
  Repeat: (p) => <Icon {...p}><path d="M17 2l4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 22l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3"/></Icon>,
  RepeatOne: (p) => <Icon {...p}><path d="M17 2l4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 22l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3M11 15v-4l-1 .5"/></Icon>,
  Volume: (p) => <Icon {...p}><path d="M11 5 6 9H3v6h3l5 4V5ZM15.5 8.5a5 5 0 0 1 0 7M18 6a8 8 0 0 1 0 12"/></Icon>,
  VolumeMute: (p) => <Icon {...p}><path d="M11 5 6 9H3v6h3l5 4V5ZM16 9l5 6M21 9l-5 6"/></Icon>,
  VolumeLow: (p) => <Icon {...p}><path d="M11 5 6 9H3v6h3l5 4V5ZM15.5 8.5a5 5 0 0 1 0 7"/></Icon>,
  Maximize: (p) => <Icon {...p}><path d="M4 9V5a1 1 0 0 1 1-1h4M20 9V5a1 1 0 0 0-1-1h-4M4 15v4a1 1 0 0 0 1 1h4M20 15v4a1 1 0 0 1-1 1h-4"/></Icon>,
  Minimize: (p) => <Icon {...p}><path d="M9 5v4H5M15 5v4h4M9 19v-4H5M15 19v-4h4"/></Icon>,
  StopAfter: (p) => <Icon {...p}><rect x="3" y="3" width="8" height="8" rx="1"/><path d="M21 6v6a3 3 0 0 1-3 3h-3l2-2m0 4-2-2"/></Icon>,
  Settings: (p) => <Icon {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1 1.55V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.11-1.55 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.55-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.55-1.11 1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34h.01a1.7 1.7 0 0 0 1-1.55V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.55h.01a1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87v.01a1.7 1.7 0 0 0 1.55 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.55 1Z"/></Icon>,
  Close: (p) => <Icon {...p}><path d="M18 6 6 18M6 6l12 12"/></Icon>,
  Check: (p) => <Icon {...p}><path d="M20 6 9 17l-5-5"/></Icon>,
  Plus: (p) => <Icon {...p}><path d="M12 5v14M5 12h14"/></Icon>,
  Minus: (p) => <Icon {...p}><path d="M5 12h14"/></Icon>,
  ChevronDown: (p) => <Icon {...p}><path d="m6 9 6 6 6-6"/></Icon>,
  ChevronRight: (p) => <Icon {...p}><path d="m9 6 6 6-6 6"/></Icon>,
  ChevronLeft: (p) => <Icon {...p}><path d="m15 6-6 6 6 6"/></Icon>,
  ChevronUp: (p) => <Icon {...p}><path d="m18 15-6-6-6 6"/></Icon>,
  Search: (p) => <Icon {...p}><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></Icon>,
  Folder: (p) => <Icon {...p}><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/></Icon>,
  File: (p) => <Icon {...p}><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9l-6-6ZM14 3v6h6"/></Icon>,
  Film: (p) => <Icon {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 7h4M17 7h4M3 12h18M3 17h4M17 17h4"/></Icon>,
  Scissors: (p) => <Icon {...p}><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="m20 4-9 9-2.5-2.5M20 20l-9-9M14 12l3 3"/></Icon>,
  Layers: (p) => <Icon {...p}><path d="m12 3 9 5-9 5-9-5 9-5ZM3 13l9 5 9-5M3 18l9 5 9-5"/></Icon>,
  Library: (p) => <Icon {...p}><path d="M3 4v16M8 4v16M14 4l5 16M14 8l4 12"/></Icon>,
  Edit: (p) => <Icon {...p}><path d="M11 4H4v16h16v-7M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5Z"/></Icon>,
  Trash: (p) => <Icon {...p}><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6"/></Icon>,
  Save: (p) => <Icon {...p}><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2ZM17 21v-8H7v8M7 3v5h8"/></Icon>,
  Upload: (p) => <Icon {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></Icon>,
  Download: (p) => <Icon {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></Icon>,
  Undo: (p) => <Icon {...p}><path d="M3 7v6h6M3 13a9 9 0 0 1 15-3"/></Icon>,
  Redo: (p) => <Icon {...p}><path d="M21 7v6h-6M21 13a9 9 0 0 0-15-3"/></Icon>,
  AB: (p) => <Icon {...p}><path d="M3 7h2a2 2 0 0 1 2 2v2H3M3 11h4v4H3M14 7h6M14 15h6M17 7v8"/></Icon>,
  Toggle: (p) => <Icon {...p}><rect x="2" y="7" width="20" height="10" rx="5"/><circle cx="17" cy="12" r="3" fill="currentColor"/></Icon>,
  Star: (p) => <Icon {...p}><path d="m12 3 2.6 6 6.4.5-4.9 4.2 1.5 6.3L12 16.8 6.4 20l1.5-6.3L3 9.5l6.4-.5L12 3Z"/></Icon>,
  StarFilled: (p) => <Icon {...p} fill="currentColor"><path d="m12 3 2.6 6 6.4.5-4.9 4.2 1.5 6.3L12 16.8 6.4 20l1.5-6.3L3 9.5l6.4-.5L12 3Z"/></Icon>,
  Help: (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 1.5-2.5 2.5-2.5 3.5M12 17h.01"/></Icon>,
  Info: (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v5h1"/></Icon>,
  Warn: (p) => <Icon {...p}><path d="M10.3 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0ZM12 9v4M12 17h.01"/></Icon>,
  Filter: (p) => <Icon {...p}><path d="M3 5h18l-7 9v6l-4-2v-4L3 5Z"/></Icon>,
  Grid: (p) => <Icon {...p}><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></Icon>,
  List: (p) => <Icon {...p}><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></Icon>,
  Eye: (p) => <Icon {...p}><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8Z"/><circle cx="12" cy="12" r="3"/></Icon>,
  EyeOff: (p) => <Icon {...p}><path d="M1 1l22 22M9.9 5.3A11.5 11.5 0 0 1 12 5c7 0 11 7 11 7a18.5 18.5 0 0 1-3.1 4.2M6.6 6.6A18.5 18.5 0 0 0 1 12s4 7 11 7a11.5 11.5 0 0 0 5-1.1M14.1 14.1A3 3 0 0 1 9.9 9.9"/></Icon>,
  PiP: (p) => <Icon {...p}><rect x="3" y="5" width="18" height="14" rx="2"/><rect x="12" y="11" width="7" height="6" rx="1" fill="currentColor"/></Icon>,
  Subtitle: (p) => <Icon {...p}><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 11h4M13 11h4M7 15h2M11 15h6"/></Icon>,
  Audio: (p) => <Icon {...p}><path d="M3 12v-2a3 3 0 0 1 3-3h2v8H6a3 3 0 0 1-3-3ZM16 7h2a3 3 0 0 1 3 3v2a3 3 0 0 1-3 3h-2V7ZM8 7v10M16 7v10M12 4v16"/></Icon>,
  Layers2: (p) => <Icon {...p}><path d="M3 8 12 3l9 5-9 5L3 8ZM3 14l9 5 9-5"/></Icon>,
  Clock: (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></Icon>,
  Cut: (p) => <Icon {...p}><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4 8.5 18.5M20 20 8.5 5.5"/></Icon>,
  Mic: (p) => <Icon {...p}><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></Icon>,
  Wave: (p) => <Icon {...p}><path d="M2 12h2M6 8v8M10 4v16M14 8v8M18 10v4M22 12h0"/></Icon>,
  Snowflake: (p) => <Icon {...p}><path d="M12 2v20M5 5l14 14M5 19 19 5M2 12h20"/></Icon>,
  X: (p) => <Icon {...p}><path d="M18 6 6 18M6 6l12 12"/></Icon>,
  Drop: (p) => <Icon {...p}><path d="M12 22a7 7 0 0 0 7-7c0-4.5-7-13-7-13S5 10.5 5 15a7 7 0 0 0 7 7Z"/></Icon>,
  Diamond: (p) => <Icon {...p}><path d="M12 2 2 12l10 10 10-10L12 2Z"/></Icon>,
  PlayCircle: (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M10 8.5 16 12l-6 3.5v-7Z" fill="currentColor"/></Icon>,
  ListPlus: (p) => <Icon {...p}><path d="M11 12H3M16 6H3M11 18H3M15 15h6M18 12v6"/></Icon>,
  Bookmark: (p) => <Icon {...p}><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16Z"/></Icon>,
  Refresh: (p) => <Icon {...p}><path d="M21 12a9 9 0 0 1-15.36 6.36L3 16M3 12a9 9 0 0 1 15.36-6.36L21 8M21 4v4h-4M3 20v-4h4"/></Icon>,
  Sync: (p) => <Icon {...p}><path d="M21 12a9 9 0 0 0-9-9 9 9 0 0 0-6.4 2.6L3 8M3 3v5h5M3 12a9 9 0 0 0 9 9 9 9 0 0 0 6.4-2.6L21 16M21 21v-5h-5"/></Icon>,
  Mute: (p) => <Icon {...p}><path d="M11 5 6 9H3v6h3l5 4V5Z" fill="currentColor"/><path d="m16 9 5 6M21 9l-5 6"/></Icon>,
  Cog: (p) => <Icon {...p}><circle cx="12" cy="12" r="3"/><path d="m19.4 15-.8 1.4M5.4 9.4l-.8-1.4M9.4 4.6 8.6 6M14.6 4.6l.8 1.4M19.4 9l.8-1.4M14.6 19.4 15.4 18M9.4 19.4 8.6 18M4.6 15l-.8 1.4"/></Icon>,
  Heart: (p) => <Icon {...p}><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21.2l7.8-7.8 1-1a5.5 5.5 0 0 0 0-7.8Z"/></Icon>,
  Tag: (p) => <Icon {...p}><path d="m20.6 13.4-8 8-9-9V3h9.4l8 8a2 2 0 0 1 0 2.4ZM7 7h.01"/></Icon>,
  Globe: (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></Icon>,
  Sparkles: (p) => <Icon {...p}><path d="m12 3 1.7 4.3L18 9l-4.3 1.7L12 15l-1.7-4.3L6 9l4.3-1.7L12 3ZM5 18l.7 1.3L7 20l-1.3.7L5 22l-.7-1.3L3 20l1.3-.7L5 18ZM19 14l.5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5L19 14Z"/></Icon>,
  Group: (p) => <Icon {...p}><rect x="3" y="5" width="8" height="6" rx="1"/><rect x="13" y="13" width="8" height="6" rx="1"/><path d="M11 8h2v8M13 8h.01M11 16h.01"/></Icon>,
  TimeIn: (p) => <Icon {...p}><path d="M3 5v14M6 7l5 5-5 5M21 12H11"/></Icon>,
  TimeOut: (p) => <Icon {...p}><path d="M21 5v14M18 7l-5 5 5 5M3 12h10"/></Icon>,
  Notch: (p) => <Icon {...p}><path d="M4 5h6l4 7-4 7H4M14 5h6v14h-6"/></Icon>,
  Wand: (p) => <Icon {...p}><path d="M15 4V2M15 8V6M9 4l-1 1M21 4l-1 1M19 10h-2M3 21l9-9M16 8l1.5 1.5"/></Icon>,
  Power: (p) => <Icon {...p}><path d="M18.4 6.6a9 9 0 1 1-12.8 0M12 2v10"/></Icon>,
  Hash: (p) => <Icon {...p}><path d="M4 9h16M4 15h16M10 3 8 21M16 3l-2 18"/></Icon>,
  Speed: (p) => <Icon {...p}><path d="M19.4 14a8 8 0 1 0-14.8 0M12 14l4-5"/></Icon>,
  Camera: (p) => <Icon {...p}><rect x="3" y="6" width="13" height="12" rx="2"/><path d="m23 7-7 5 7 5V7Z"/></Icon>,
};

/* FVP brand glyph — patriotic, simple */
const Brand = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <rect x="2" y="3" width="20" height="18" rx="3.5" fill="#0e1116"/>
    <path d="M9 8v8l7-4-7-4Z" fill="#ffffff"/>
    <path d="M2 10h20" stroke="#b91c2a" strokeWidth="2"/>
    <path d="M2 14h20" stroke="#1f3fbf" strokeWidth="2"/>
    <rect x="2" y="3" width="20" height="18" rx="3.5" fill="none" stroke="#0e1116" strokeWidth="0.5"/>
  </svg>
);
window.I = I;
window.Brand = Brand;
window.Icon = Icon;
