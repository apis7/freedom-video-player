/* ---------- Library Mode ---------- */

const Library = ({ state, dispatch }) => {
  const { fmtTime, fmtRuntime, IconBtn, Btn, Kbd, ProfileStateBadge, Poster, Sparkline } = window.UI;
  const { LIB_TITLES, VIEWERS, MOODS, STAT_CATS, LEADERBOARD, HEALTH_ISSUES } = window.FVPData;

  const [view, setView] = useState("grid");     // grid | list
  const [tab, setTab] = useState("library");    // library | stats | health
  const [filter, setFilter] = useState("all");
  const [selectedTitle, setSelectedTitle] = useState(null);
  const [viewer, setViewer] = useState(VIEWERS[1]);

  const filtered = useMemo(() => {
    if (filter === "all") return LIB_TITLES;
    if (filter === "has-profile") return LIB_TITLES.filter(t => t.profile !== "none");
    if (filter === "stacked") return LIB_TITLES.filter(t => t.profile === "stacked");
    if (filter === "no-profile") return LIB_TITLES.filter(t => t.profile === "none");
    if (filter === "hub-available") return LIB_TITLES.filter(t => t.profile === "hub");
    if (filter === "draft") return LIB_TITLES.filter(t => t.profile === "draft");
    if (filter === "unwatched") return LIB_TITLES.filter(t => t.watched < 0.95);
    if (filter === "watched") return LIB_TITLES.filter(t => t.watched >= 0.95);
    if (filter === "continue") return LIB_TITLES.filter(t => t.watched > 0 && t.watched < 0.95);
    return LIB_TITLES;
  }, [filter]);

  if (selectedTitle) {
    return <TitleDetail title={selectedTitle} onBack={() => setSelectedTitle(null)}/>;
  }

  if (tab === "stats")  return <Stats onBack={() => setTab("library")}/>;
  if (tab === "health") return <Health onBack={() => setTab("library")}/>;

  return (
    <div className="library">
      {/* Left rail */}
      <aside className="lib-rail scroll">
        <div className="lib-rail__sect">
          <div className="row" style={{ position: "relative", padding: "4px 0" }}>
            <window.I.Search size={13} style={{ position: "absolute", left: 8, top: "50%", transform: "translateY(-50%)", color: "var(--text-3)" }}/>
            <input className="input input--sm" placeholder="Search library…" style={{ paddingLeft: 26 }}/>
          </div>
        </div>
        <RailGroup title="View">
          <RailRow active={tab === "library"}     icon="Library"  label="All titles" count={LIB_TITLES.length} onClick={() => { setTab("library"); setFilter("all"); }}/>
          <RailRow active={tab === "stats"}       icon="Sparkles" label="Stats"      onClick={() => setTab("stats")}/>
          <RailRow active={tab === "health"}      icon="Warn"     label="Health" count={HEALTH_ISSUES.length} onClick={() => setTab("health")}/>
        </RailGroup>

        <RailGroup title="Quick filters">
          <RailRow active={filter === "continue"}  icon="Clock"  label="Continue watching" onClick={() => setFilter("continue")}/>
          <RailRow active={filter === "watched"}   icon="Check"  label="Watched"    onClick={() => setFilter("watched")}/>
          <RailRow active={filter === "unwatched"} icon="Eye"    label="Unwatched"  onClick={() => setFilter("unwatched")}/>
          <RailRow active={filter === "watchlist"} icon="Bookmark" label="Watchlist" onClick={() => setFilter("watchlist")} count={3}/>
        </RailGroup>

        <RailGroup title="Profile state">
          <RailRow active={filter === "has-profile"}    icon="Check"   label="Has profile" onClick={() => setFilter("has-profile")} count={9}/>
          <RailRow active={filter === "stacked"}        icon="Layers2" label="Stacked"     onClick={() => setFilter("stacked")} count={3}/>
          <RailRow active={filter === "draft"}          icon="Edit"    label="Draft in progress" onClick={() => setFilter("draft")} count={2}/>
          <RailRow active={filter === "no-profile"}     icon="X"       label="No profile"  onClick={() => setFilter("no-profile")} count={3}/>
          <RailRow active={filter === "hub-available"}  icon="Sparkles" label="New on Hub" onClick={() => setFilter("hub-available")} count={2}/>
        </RailGroup>

        <RailGroup title="Mood / occasion">
          {MOODS.map(m => (
            <RailRow key={m.id} icon="Heart" label={m.label} count={m.count}/>
          ))}
        </RailGroup>

        <RailGroup title="By genre">
          {["Thriller", "Drama", "Comedy", "Horror", "Action", "SciFi", "Doc", "Series", "Music", "Western", "Adventure", "Indie"].map(g => (
            <RailRow key={g} icon={null} label={g}/>
          ))}
        </RailGroup>

        <div className="lib-rail__sect">
          <Btn ghost icon="Plus" style={{ width: "100%", justifyContent: "center" }}>New shelf</Btn>
        </div>
      </aside>

      {/* Main */}
      <main className="lib-main">
        <div className="lib-top">
          <div className="lib-top__title">
            {filter === "all" ? "All titles" :
             filter === "continue" ? "Continue watching" :
             filter === "has-profile" ? "Has profile" :
             filter === "stacked" ? "Stacked" :
             filter === "no-profile" ? "No profile" :
             filter === "hub-available" ? "New on Hub" :
             filter === "unwatched" ? "Unwatched" :
             filter === "watched" ? "Watched" :
             filter === "watchlist" ? "Watchlist" :
             filter === "draft" ? "Drafts in progress" : "Library"}
          </div>
          <span className="faint fz-12 mono">{filtered.length} titles</span>
          <div className="flex-1"/>
          {/* Indexing chip */}
          <span className="chip chip--outline" style={{ background: "var(--blue-soft)", color: "var(--blue)", borderColor: "transparent" }}>
            <window.I.Refresh size={11} className="text-blue"/>
            Indexing 3 of 412
          </span>
          <div className="divider-v"/>
          {/* Sort */}
          <span className="seg">
            <span className="seg__opt is-active">Recent</span>
            <span className="seg__opt">Title</span>
            <span className="seg__opt">Year</span>
          </span>
          {/* View modes */}
          <IconBtn icon="Grid" tooltip="Grid" on={view === "grid"} onClick={() => setView("grid")}/>
          <IconBtn icon="List" tooltip="List" on={view === "list"} onClick={() => setView("list")}/>
          {/* Random pick */}
          <IconBtn icon="Diamond" tooltip="Random pick from current filter"/>
          {/* Viewer */}
          <div className="divider-v"/>
          <div className="row gap-6 tt" data-tt={`${viewer.name} · ${viewer.strict} profile defaults`}
               style={{ background: "var(--surface-2)", border: "1px solid var(--border)", borderRadius: 999, padding: "3px 4px 3px 10px", fontSize: 12, cursor: "pointer" }}>
            <span style={{ width: 8, height: 8, borderRadius: 50, background: viewer.color }}/>
            <span className="fw-500">{viewer.name}</span>
            <window.I.ChevronDown size={12}/>
          </div>
        </div>

        <div className="lib-grid-wrap scroll">
          {/* Continue watching shelf */}
          {filter === "all" && (
            <div className="lib-shelf">
              <div className="lib-shelf__title">
                <window.I.Clock size={14} className="dim"/>
                <h3>Continue watching</h3>
                <span className="faint fz-11">3 titles</span>
              </div>
              <div className="lib-cw">
                {LIB_TITLES.filter(t => t.watched > 0 && t.watched < 0.95).slice(0, 6).map(t => (
                  <CWCard key={t.id} title={t} onClick={() => setSelectedTitle(t)}/>
                ))}
              </div>
            </div>
          )}

          {/* New on Hub shelf */}
          {filter === "all" && (
            <div className="lib-shelf">
              <div className="lib-shelf__title">
                <window.I.Sparkles size={14} className="text-red"/>
                <h3>New profiles on FVP Hub for files you own</h3>
              </div>
              <div className="lib-grid">
                {LIB_TITLES.filter(t => t.profile === "hub").slice(0, 6).map(t => (
                  <LibCard key={t.id} title={t} onClick={() => setSelectedTitle(t)}/>
                ))}
              </div>
            </div>
          )}

          {/* Main grid */}
          <div className="lib-shelf">
            {filter === "all" && (
              <div className="lib-shelf__title">
                <window.I.Film size={14} className="dim"/>
                <h3>All titles</h3>
                <span className="faint fz-11">{filtered.length}</span>
              </div>
            )}
            {view === "grid" ? (
              <div className="lib-grid">
                {filtered.map(t => <LibCard key={t.id} title={t} onClick={() => setSelectedTitle(t)}/>)}
              </div>
            ) : (
              <LibList titles={filtered} onClick={setSelectedTitle}/>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

const RailGroup = ({ title, children }) => (
  <div className="lib-rail__sect">
    <h5>{title}</h5>
    {children}
  </div>
);

const RailRow = ({ icon, label, active, count, onClick }) => {
  const Comp = icon ? window.I[icon] : null;
  return (
    <div className={`lib-rail__row ${active ? "is-active" : ""}`} onClick={onClick}>
      {Comp ? <Comp size={13}/> : <span style={{ width: 13 }}/>}
      <span>{label}</span>
      {count != null && <span className="lib-rail__count">{count}</span>}
    </div>
  );
};

const LibCard = ({ title, onClick }) => {
  const { Poster, ProfileStateBadge, IconBtn } = window.UI;
  return (
    <div className="lib-card" onClick={onClick}>
      <Poster {...title}/>
      <div className="lib-card__badge"><ProfileStateBadge state={title.profile} n={title.n}/></div>
      <div className="lib-card__hover-actions">
        <IconBtn icon="Play" size="lg" style={{ background: "rgba(255,255,255,.95)", color: "var(--text)" }} tooltip={`Play with ${title.profile === "stacked" ? "stacked profiles" : "profile"}`}/>
      </div>
      <div className="lib-card__title">{title.title}</div>
      <div className="lib-card__meta">{title.year} · {fmtRuntime(title.runtime)} · {title.rating}</div>
    </div>
  );
};

const CWCard = ({ title, onClick }) => {
  const { Poster, ProfileStateBadge } = window.UI;
  return (
    <div className="lib-cw-card lib-card" onClick={onClick}>
      <div className="lib-cw-card__poster">
        <Poster {...title} ratio="16/9" small/>
        <div className="lib-card__badge"><ProfileStateBadge state={title.profile} n={title.n}/></div>
        <div className="lib-cw-card__bar">
          <div className="lib-cw-card__bar-fill" style={{ width: `${title.watched * 100}%` }}/>
        </div>
      </div>
      <div className="lib-card__title">{title.title}</div>
      <div className="lib-card__meta mono">Resume {fmtTime(title.runtime * 60 * title.watched)}</div>
    </div>
  );
};

const fmtRuntime = (mins) => `${Math.floor(mins / 60)}h ${mins % 60}m`;
const fmtTime = (s) => window.UI.fmtTime(s);

const LibList = ({ titles, onClick }) => (
  <table style={{ width: "100%", borderCollapse: "collapse" }}>
    <thead>
      <tr style={{ textAlign: "left", fontSize: 10.5, color: "var(--text-3)", textTransform: "uppercase", letterSpacing: ".08em" }}>
        <th style={{ padding: "8px 12px" }}></th>
        <th style={{ padding: "8px 12px" }}>Title</th>
        <th style={{ padding: "8px 12px" }}>Year</th>
        <th style={{ padding: "8px 12px" }}>Runtime</th>
        <th style={{ padding: "8px 12px" }}>Rating</th>
        <th style={{ padding: "8px 12px" }}>Genre</th>
        <th style={{ padding: "8px 12px" }}>Profile</th>
      </tr>
    </thead>
    <tbody>
      {titles.map(t => (
        <tr key={t.id} className="cursor-pointer" onClick={() => onClick(t)}
            style={{ borderBottom: "1px solid var(--divider)" }}
            onMouseEnter={(e) => e.currentTarget.style.background = "var(--hover)"}
            onMouseLeave={(e) => e.currentTarget.style.background = ""}>
          <td style={{ padding: "6px 12px", width: 36 }}>
            <div style={{ width: 24, height: 36, borderRadius: 3, background: `linear-gradient(160deg, hsl(${t.hue}, 38%, 28%), hsl(${(t.hue+30)%360}, 30%, 14%))` }}/>
          </td>
          <td style={{ padding: "6px 12px", fontWeight: 500 }}>{t.title}</td>
          <td style={{ padding: "6px 12px" }} className="mono dim">{t.year}</td>
          <td style={{ padding: "6px 12px" }} className="mono dim">{fmtRuntime(t.runtime)}</td>
          <td style={{ padding: "6px 12px" }} className="dim">{t.rating}</td>
          <td style={{ padding: "6px 12px" }} className="dim">{t.genre}</td>
          <td style={{ padding: "6px 12px" }}><window.UI.ProfileStateBadge state={t.profile} n={t.n}/></td>
        </tr>
      ))}
    </tbody>
  </table>
);

/* Title detail */
const TitleDetail = ({ title, onBack }) => {
  const { Btn, IconBtn, Poster, ProfileStateBadge, CatChip, Sparkline } = window.UI;
  return (
    <div className="library" style={{ gridTemplateColumns: "1fr" }}>
      <main className="lib-main">
        <div className="lib-top">
          <IconBtn icon="ChevronLeft" tooltip="Back" onClick={onBack}/>
          <div className="lib-top__title">{title.title}</div>
          <span className="faint fz-12 mono">{title.year} · {fmtRuntime(title.runtime)} · {title.rating}</span>
          <div className="flex-1"/>
          <IconBtn icon="Refresh" tooltip="Refresh fingerprint"/>
          <IconBtn icon="Folder" tooltip="Show in folder"/>
          <IconBtn icon="Bookmark" tooltip="Add to watchlist"/>
        </div>
        <div className="lib-grid-wrap scroll">
          <div className="row gap-24" style={{ alignItems: "flex-start" }}>
            <div style={{ width: 240, flex: "0 0 240px" }}>
              <Poster {...title}/>
              <ProfileStateBadge state={title.profile} n={title.n}/>
            </div>
            <div className="col" style={{ flex: 1, minWidth: 0 }}>
              <div className="fz-28 fw-700" style={{ letterSpacing: "-.02em", lineHeight: 1.1 }}>{title.title}</div>
              <div className="row gap-8" style={{ marginTop: 6, color: "var(--text-2)" }}>
                <span className="mono">{title.year}</span>
                <span>·</span>
                <span>{fmtRuntime(title.runtime)}</span>
                <span>·</span>
                <span className="chip chip--outline" style={{ padding: "1px 6px" }}>{title.rating}</span>
                <span className="chip chip--outline" style={{ padding: "1px 6px" }}>{title.genre}</span>
              </div>
              <div className="row gap-8" style={{ marginTop: 16 }}>
                <Btn primary icon="Play">Play with stack</Btn>
                <Btn icon="Layers2">Play with…</Btn>
                <Btn icon="Edit">Edit profile</Btn>
                <Btn ghost icon="Bookmark">Watchlist</Btn>
              </div>
              <p style={{ marginTop: 18, color: "var(--text-2)", fontSize: 13, lineHeight: 1.55, maxWidth: 640 }}>
                A taut thriller about a former operative pulled back into a job he thought he'd left behind.
                When the lines between duty and conscience blur, every decision risks the life of his family.
              </p>
              <div className="row gap-24" style={{ marginTop: 18, fontSize: 12, color: "var(--text-2)" }}>
                <div><span className="faint">Director · </span>Anya Voren</div>
                <div><span className="faint">Cast · </span>M. Reed, K. Halloway, S. Ono, J. Park</div>
                <div><span className="faint">Language · </span>EN, ES, FR sub</div>
              </div>
            </div>
          </div>

          {/* Profiles section */}
          <div className="card" style={{ padding: 20, marginTop: 24 }}>
            <div className="row" style={{ justifyContent: "space-between", marginBottom: 14 }}>
              <div className="fz-14 fw-600">Profiles · {window.FVPData.PROFILES_FOR_FILE.length} linked</div>
              <Btn ghost icon="Globe">Browse Hub for more</Btn>
            </div>
            <div className="col gap-6">
              {window.FVPData.PROFILES_FOR_FILE.map(p => (
                <div key={p.id} className="row gap-12" style={{ padding: "10px 12px", border: "1px solid var(--divider)", borderRadius: 8,
                  background: p.active ? "var(--blue-tint)" : "var(--surface)" }}>
                  <IconBtn icon={p.primary ? "StarFilled" : "Star"} tooltip="Primary"/>
                  <div className="col" style={{ flex: 1, minWidth: 0 }}>
                    <div className="row gap-6">
                      <span className="fw-600 fz-13">{p.name}</span>
                      <span className="mono faint fz-11">{p.version}</span>
                      <span className="faint fz-11">{p.local ? "your local" : `by ${p.uploader}`}</span>
                    </div>
                    <div className="row gap-4" style={{ marginTop: 4, flexWrap: "wrap" }}>
                      {p.cats.map(c => <CatChip key={c} catId={c}/>)}
                    </div>
                  </div>
                  <div className="col" style={{ textAlign: "right", color: "var(--text-2)", fontSize: 11.5 }}>
                    <span className="mono">{p.snipCount} snips · {p.totalCut}</span>
                    {!p.local && <span className="mono faint">{p.downloads.toLocaleString()} dl · {p.upvotes} ↑</span>}
                  </div>
                  <window.UI.Toggle on={p.active}/>
                </div>
              ))}
            </div>
          </div>

          {/* Content warnings */}
          {title.hasCw && (
            <div className="card" style={{ padding: 20, marginTop: 16 }}>
              <div className="row" style={{ justifyContent: "space-between", marginBottom: 10 }}>
                <div className="fz-14 fw-600">Content warnings</div>
                <span className="faint fz-11">via DoesTheDogDie · Common Sense Media</span>
              </div>
              <div className="row gap-4" style={{ flexWrap: "wrap" }}>
                {[
                  { cat: "violence", lbl: "Gun violence (3)" },
                  { cat: "gore", lbl: "Gore (1)" },
                  { cat: "language", lbl: "Strong language (8)" },
                  { cat: "sex", lbl: "Implied sex (1)" },
                  { cat: "substance", lbl: "Drug use (2)" },
                ].map((w, i) => (
                  <span key={i} className={`chip chip--${window.FVPData.CAT_BY_ID[w.cat]?.key || "cat-other"}`}>
                    <span className="dot"/>{w.lbl}
                  </span>
                ))}
              </div>
              <div className="row" style={{ marginTop: 14 }}>
                <Btn icon="Wand" ghost>Suggest snips from these warnings</Btn>
              </div>
            </div>
          )}

          {/* Stats per title */}
          <div className="row gap-16" style={{ marginTop: 16 }}>
            <div className="card" style={{ padding: 18, flex: 1 }}>
              <div className="fz-14 fw-600" style={{ marginBottom: 12 }}>Your viewing</div>
              <div className="row gap-24">
                <div className="col"><div className="faint fz-11 h-section">Times watched</div><div className="fz-20 mono">3</div></div>
                <div className="col"><div className="faint fz-11 h-section">Last watched</div><div className="fz-14">Today, 8:14 PM</div></div>
                <div className="col"><div className="faint fz-11 h-section">Junk cut total</div><div className="fz-20 mono text-blue">1h 26m</div></div>
              </div>
              <div className="row gap-6" style={{ marginTop: 14, flexWrap: "wrap" }}>
                <CatChip catId="language"/> <CatChip catId="sex"/> <CatChip catId="violence"/> <CatChip catId="boring"/>
              </div>
            </div>
            <div className="card" style={{ padding: 18, flex: 1 }}>
              <div className="fz-14 fw-600" style={{ marginBottom: 12 }}>Media info</div>
              <table style={{ fontSize: 11.5, color: "var(--text-2)", lineHeight: 1.8, width: "100%" }}>
                <tbody>
                  <tr><td className="faint">Container</td><td className="mono">Matroska (MKV)</td></tr>
                  <tr><td className="faint">Codec</td><td className="mono">HEVC · 1080p · 24 fps</td></tr>
                  <tr><td className="faint">HDR</td><td className="mono">HDR10</td></tr>
                  <tr><td className="faint">Audio</td><td className="mono">DTS-HD MA · 5.1 · EN</td></tr>
                  <tr><td className="faint">Subs</td><td className="mono">EN, ES, FR</td></tr>
                  <tr><td className="faint">Path</td><td className="mono" style={{ overflow: "hidden", textOverflow: "ellipsis" }}>D:\Movies\The.Pinnacle.2024.mkv</td></tr>
                </tbody>
              </table>
            </div>
          </div>

          <div style={{ height: 40 }}/>
        </div>
      </main>
    </div>
  );
};

/* Stats dashboard */
const Stats = ({ onBack }) => {
  const { Btn, IconBtn, Sparkline } = window.UI;
  const { STAT_CATS, LEADERBOARD } = window.FVPData;
  const maxHours = Math.max(...STAT_CATS.map(c => c.hours));
  return (
    <div className="library" style={{ gridTemplateColumns: "1fr" }}>
      <main className="lib-main">
        <div className="lib-top">
          <IconBtn icon="ChevronLeft" tooltip="Back" onClick={onBack}/>
          <div className="lib-top__title">Stats — cut the junk</div>
          <div className="flex-1"/>
          <Btn ghost icon="Download">Export CSV</Btn>
          <Btn danger ghost icon="Trash">Wipe all stats…</Btn>
        </div>
        <div className="scroll" style={{ flex: 1 }}>
          <div className="stats">
            <div className="stat-hero">
              <div className="col">
                <div className="stat-hero__label">Junk cut, all time</div>
                <div className="stat-hero__big mono tnum">94h 28m</div>
                <div className="row gap-12" style={{ fontSize: 12, opacity: .85, marginTop: 6 }}>
                  <span>across <strong>312</strong> viewings</span>
                  <span>·</span>
                  <span><strong>47</strong> profiles authored</span>
                  <span>·</span>
                  <span><strong>12</strong> uploaded</span>
                </div>
                <div className="stat-hero__cats">
                  {STAT_CATS.map(c => <span key={c.id} className="stat-hero__cat">{c.amount} {c.label.toLowerCase()}</span>)}
                </div>
              </div>
              <div style={{ borderLeft: "1px solid rgba(255,255,255,.18)", paddingLeft: 28 }}>
                <div className="stat-hero__label">This month</div>
                <div className="fz-28 mono fw-700">8h 14m</div>
                <div className="row gap-12" style={{ marginTop: 12, fontSize: 11.5, opacity: .8 }}>
                  <div className="col"><span>Snips</span><strong className="fz-16 mono">324</strong></div>
                  <div className="col"><span>Profiles</span><strong className="fz-16 mono">3</strong></div>
                  <div className="col"><span>Uploads</span><strong className="fz-16 mono">1</strong></div>
                </div>
              </div>
            </div>

            <div className="stat-grid">
              <div className="stat-card">
                <h3>Per-category cuts</h3>
                {STAT_CATS.map(c => (
                  <div key={c.id} className="bar-row">
                    <span className="bar-row__label">
                      <span style={{ display: "inline-block", width: 9, height: 9, borderRadius: 3, background: c.color, marginRight: 6, verticalAlign: "middle" }}/>
                      {c.label}
                    </span>
                    <div className="bar-row__bar"><div className="bar-row__bar-fill" style={{ width: `${(c.hours / maxHours) * 100}%`, background: c.color }}/></div>
                    <span className="bar-row__val">{c.amount}</span>
                  </div>
                ))}
              </div>
              <div className="stat-card">
                <h3>Most-cut titles</h3>
                <div className="col gap-4">
                  {LEADERBOARD.map((t, i) => (
                    <div key={i} className="row gap-12" style={{ padding: "6px 0", borderBottom: i < LEADERBOARD.length - 1 ? "1px solid var(--divider)" : "" }}>
                      <span className="mono faint fz-11" style={{ width: 16 }}>{i + 1}</span>
                      <span className="fz-12" style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.title}</span>
                      <Sparkline data={t.spark}/>
                      <span className="mono fz-12 text-blue" style={{ width: 56, textAlign: "right" }}>{t.cut}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="stat-card">
              <h3>Your uploads on Hub</h3>
              <table className="hotkey-table">
                <thead>
                  <tr><th>Profile</th><th>Title</th><th>Version</th><th style={{ textAlign: "right" }}>Downloads</th><th style={{ textAlign: "right" }}>Upvotes</th><th style={{ textAlign: "right" }}>Flags</th></tr>
                </thead>
                <tbody>
                  {[
                    ["Family Friendly", "The Pinnacle", "v3", 4280, 612, 4],
                    ["No Filler", "The Pinnacle", "v2", 1108, 188, 0],
                    ["Family Friendly", "Steel & Iron", "v1", 882, 121, 1],
                    ["Date Night", "Driftwood", "v2", 514, 67, 0],
                  ].map((row, i) => (
                    <tr key={i}>
                      <td className="fw-500">{row[0]}</td>
                      <td className="dim">{row[1]}</td>
                      <td className="mono dim">{row[2]}</td>
                      <td className="mono" style={{ textAlign: "right" }}>{row[3].toLocaleString()}</td>
                      <td className="mono text-blue" style={{ textAlign: "right" }}>{row[4]}</td>
                      <td className="mono" style={{ textAlign: "right", color: row[5] > 0 ? "var(--red)" : "var(--text-3)" }}>{row[5]}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="stat-card">
              <h3>Recent viewings</h3>
              {[
                ["Today 8:14 PM", "The Pinnacle", "Family + No Filler", "Dad", "14m 22s cut"],
                ["Mon 9:32 PM",   "Halcyon E03",  "Family",             "Kids", "8m 04s cut"],
                ["Sun 8:11 PM",   "Driftwood",    "Date Night",         "Mom",  "6m 47s cut"],
                ["Sat 2:11 PM",   "Family Vacation Trailer", "—",       "Kids", "0s cut"],
              ].map((r, i) => (
                <div key={i} className="row gap-12" style={{ padding: "6px 0", borderBottom: "1px solid var(--divider)", fontSize: 12 }}>
                  <span className="mono faint" style={{ width: 110 }}>{r[0]}</span>
                  <span style={{ flex: 1 }}>{r[1]}</span>
                  <span className="dim" style={{ width: 200 }}>{r[2]}</span>
                  <span className="dim" style={{ width: 80 }}>{r[3]}</span>
                  <span className="mono text-blue" style={{ width: 100, textAlign: "right" }}>{r[4]}</span>
                </div>
              ))}
            </div>

            <div className="card" style={{ padding: 18, background: "var(--blue-tint)", borderColor: "var(--blue-soft)" }}>
              <div className="row gap-10">
                <window.I.Info className="text-blue"/>
                <div className="col" style={{ flex: 1, fontSize: 12.5 }}>
                  <strong>All stats live on this device only.</strong> FVP never sends viewing data anywhere.
                </div>
                <Btn danger ghost>Wipe all stats…</Btn>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

/* Health view */
const Health = ({ onBack }) => {
  const { Btn, IconBtn } = window.UI;
  const { HEALTH_ISSUES } = window.FVPData;
  const sevIcon = { error: "Warn", warn: "Warn", info: "Info" };
  const sevColor = { error: "var(--red)", warn: "var(--amber)", info: "var(--blue)" };
  return (
    <div className="library" style={{ gridTemplateColumns: "1fr" }}>
      <main className="lib-main">
        <div className="lib-top">
          <IconBtn icon="ChevronLeft" tooltip="Back" onClick={onBack}/>
          <div className="lib-top__title">Library health</div>
          <span className="faint fz-12">{HEALTH_ISSUES.length} issues</span>
          <div className="flex-1"/>
          <Btn ghost icon="Refresh">Rescan</Btn>
          <Btn icon="Check">Bulk-fix where possible</Btn>
        </div>
        <div className="scroll" style={{ flex: 1, padding: "16px 24px" }}>
          {HEALTH_ISSUES.map((iss, i) => {
            const Comp = window.I[sevIcon[iss.severity]];
            return (
              <div key={i} className="card" style={{ padding: 14, marginBottom: 10, display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 14, alignItems: "center" }}>
                <Comp size={20} style={{ color: sevColor[iss.severity] }}/>
                <div className="col">
                  <div className="row gap-8">
                    <span className="fw-600">{iss.title}</span>
                    <span className="chip" style={{ background: sevColor[iss.severity], color: "white", padding: "1px 7px", fontSize: 10.5 }}>{iss.issue}</span>
                  </div>
                  <div className="dim fz-12" style={{ marginTop: 4 }}>{iss.desc}</div>
                </div>
                <div className="row gap-6">
                  <Btn ghost>Ignore</Btn>
                  <Btn primary>{iss.action}</Btn>
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
};

window.Library = Library;
