/* ---------- Player Mode ---------- */

const { fmtTime, IconBtn, Btn, Kbd, CatChip, Toggle, Seg, ProfileStateBadge, VolSlider } = window.UI;
const { CATEGORIES, CAT_BY_ID, ACTIONS, ACTION_BY_ID, VIDEO_DURATION, SNIPS, PROFILES_FOR_FILE, RECENT_FILES, QUEUE, HOTKEYS } = window.FVPData;

/* Top menu bar */
const MENU_BAR = [
  ["File",          ["Open Files…", "Ctrl+O"], ["Open Folder…", "Ctrl+Shift+O"], ["Open DVD-ripped Folder…", "Ctrl+Alt+O"], ["Open Recent ▸"], ["Save Playlist as .m3u…"], ["—"], ["Settings"], ["Exit"]],
  ["Video Playback",["Title ▸"], ["Chapter ▸"], ["Speed ▸"], ["Jump to custom time…"]],
  ["Video",         ["Video track ▸"], ["Fullscreen", "F"], ["Deinterlace"], ["Deinterlace mode ▸"]],
  ["Audio",         ["Audio Track ▸"], ["Audio Device ▸"], ["Stereo mode ▸"]],
  ["Subtitle",      ["Add Subtitle File…"], ["Select Subtitle Track ▸"]],
  ["View",          ["Now Playing List", "Ctrl+J"], ["Playlist view mode ▸"], ["Always on Top"]],
  ["Tools",         ["A/V & Subtitles Sync"], ["Media Information"], ["Codec Information"], ["—"], ["Settings"], ["Help"], ["Check for Updates"], ["About / TOS"]],
  ["Help",          ["Hotkey Cheatsheet", "?"], ["How it works"], ["About"]],
];

const MenuBar = ({ mode, onMode }) => (
  <div className="menubar">
    {MENU_BAR.map(([label]) => (
      <div className="menubar__item" key={label}>{label}</div>
    ))}
  </div>
);

/* Title bar */
const TitleBar = ({ mode, onMode, filename, libraryEnabled }) => {
  const modes = [
    { id: "player",   label: "Player",   icon: "PlayCircle" },
    { id: "creator",  label: "Profile Creator", icon: "Cut" },
    ...(libraryEnabled ? [{ id: "library", label: "Library", icon: "Library" }] : []),
    { id: "settings", label: "Settings", icon: "Cog" },
  ];
  return (
    <div className="titlebar">
      <div className="titlebar__brand">
        <window.Brand size={18}/>
        <span className="titlebar__brand-mark">FREEDOM<span className="dot">·</span></span>
      </div>
      <div className="titlebar__modes">
        {modes.map(m => {
          const Comp = window.I[m.icon];
          return (
            <div key={m.id}
                 className={`titlebar__mode ${mode === m.id ? "is-active" : ""}`}
                 onClick={() => onMode(m.id)}>
              <Comp size={13}/> {m.label}
            </div>
          );
        })}
      </div>
      <div className="titlebar__filename">{filename}</div>
      <div className="titlebar__win-ctl">
        <button className="titlebar__win-btn"><window.I.Minus size={14}/></button>
        <button className="titlebar__win-btn"><window.I.Maximize size={12}/></button>
        <button className="titlebar__win-btn is-close"><window.I.Close size={14}/></button>
      </div>
    </div>
  );
};

/* Empty player state — drop + recent files */
const EmptyPlayer = ({ onOpen }) => (
  <div className="empty">
    <div className="empty__drop" onClick={onOpen}>
      <window.I.Drop size={36} strokeWidth={1.2}/>
      <div className="empty__drop-title">Drop a video file here</div>
      <div className="empty__drop-sub">…or press <Kbd>Ctrl</Kbd> <Kbd>O</Kbd> to open</div>
      <div className="row gap-8" style={{ justifyContent: "center", marginTop: 18 }}>
        <Btn icon="File" onClick={onOpen}>Open files…</Btn>
        <Btn icon="Folder" ghost>Open folder…</Btn>
      </div>
    </div>
    <div className="empty__recent">
      <div className="row" style={{ alignItems: "baseline", justifyContent: "space-between" }}>
        <div className="h-section">Recent files</div>
        <button className="btn is-ghost" style={{ fontSize: 11.5 }}>Clear</button>
      </div>
      <div className="card" style={{ marginTop: 6 }}>
        {RECENT_FILES.slice(0, 8).map((f, i) => (
          <div className="recent-row" key={i} onClick={onOpen}>
            <window.I.Film className="dim"/>
            <div className="col" style={{ minWidth: 0, flex: 1 }}>
              <div className="recent-row__name" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{f.name}</div>
              <div className="recent-row__meta">{f.last} · {f.runtime}</div>
            </div>
            <div className="recent-row__profile">
              {f.profile !== "none" && <ProfileStateBadge state={f.profile} n={f.n}/>}
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

/* Seekbar with snip markers + chapters */
const Seekbar = ({ pos, duration, snips, profileOn, onSeek }) => {
  const pct = (pos / duration) * 100;
  return (
    <div className="transport__seek-wrap">
      <div className="seekbar" onClick={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        onSeek && onSeek(((e.clientX - r.left) / r.width) * duration);
      }}>
        <div className="seekbar__track"/>
        {/* chapter ticks */}
        {[0.12, 0.27, 0.41, 0.55, 0.68, 0.78, 0.92].map((c, i) => (
          <div key={i} className="seekbar__chapter" style={{ left: `${c * 100}%` }}/>
        ))}
        {/* snip markers */}
        {profileOn && snips.map(s => {
          const cat = s.cats[0] ? CAT_BY_ID[s.cats[0]] : null;
          const left = (s.start / duration) * 100;
          const width = ((s.end - s.start) / duration) * 100;
          return (
            <div key={s.id}
                 className="seekbar__snip tt"
                 data-tt={`${cat ? cat.label : "Uncategorized"} · ${ACTION_BY_ID[s.action].label} · ${fmtTime(s.end - s.start)}`}
                 style={{ left: `${left}%`, width: `${Math.max(width, 0.25)}%`, background: cat ? cat.color : "var(--text-3)" }}/>
          );
        })}
        <div className="seekbar__fill" style={{ width: `${pct}%` }}/>
        <div className="seekbar__playhead" style={{ left: `${pct}%` }}/>
      </div>
    </div>
  );
};

/* Transport bar */
const Transport = ({ playing, onPlay, vol, muted, onMute, repeat, onRepeat, shuffle, onShuffle, hasQueue, stopAfter, onStopAfter, fs, onFs, pos, duration, snips, profileOn, onSeek, onNowPlaying }) => {
  return (
    <div className="transport">
      <Seekbar pos={pos} duration={duration} snips={snips} profileOn={profileOn} onSeek={onSeek}/>
      <div className="transport__row">
        <IconBtn icon={playing ? "Pause" : "Play"} tooltip={playing ? "Pause" : "Play"} hotkey="Space" onClick={onPlay}/>
        <IconBtn icon="Stop" tooltip="Stop" hotkey="Ctrl+." onClick={() => onPlay(false)}/>
        <IconBtn icon="SkipBack" tooltip="Previous file" hotkey="B"/>
        <IconBtn icon="SkipForward" tooltip="Next file" hotkey="N"/>
        {hasQueue && (
          <IconBtn icon="StopAfter" tooltip='Stops play after the currently-playing file completes playback' on={stopAfter} onClick={onStopAfter}/>
        )}
        <div className="divider-v"/>
        <div className="transport__time tnum">
          <span className="cur">{fmtTime(pos)}</span> <span className="dim">/ {fmtTime(duration)}</span>
        </div>
        <div className="flex-1"/>
        <IconBtn icon="Shuffle" tooltip="Shuffle" hotkey="X" on={shuffle} onClick={onShuffle}/>
        <IconBtn icon={repeat === "one" ? "RepeatOne" : "Repeat"} tooltip={`Repeat: ${repeat}`} hotkey="R" on={repeat !== "off"} onClick={onRepeat}/>
        <div className="divider-v"/>
        <IconBtn icon={muted ? "VolumeMute" : vol > 70 ? "Volume" : "VolumeLow"} tooltip={muted ? "Unmute" : "Mute"} hotkey="M" off={muted} onClick={onMute}/>
        <div className="transport__vol"><VolSlider value={muted ? 0 : vol}/></div>
        <div className="divider-v"/>
        <IconBtn icon="ListPlus" tooltip="Now Playing list" hotkey="Ctrl+J" onClick={onNowPlaying}/>
        <IconBtn icon="Maximize" tooltip="Fullscreen" hotkey="F" onClick={onFs} on={fs}/>
      </div>
    </div>
  );
};

/* Active profile chip overlay */
const ProfileChipOverlay = ({ profiles, profileOn, onClick, onToggleAB }) => {
  const active = profiles.filter(p => p.active);
  if (active.length === 0) return null;
  if (!profileOn) {
    return (
      <div className="profile-chip is-off" onClick={onToggleAB} title="Profile is OFF (A/B toggle is active). Press T to re-enable.">
        <span className="profile-chip__dot"/>
        Profile OFF
        <span className="profile-chip__count">T to flip</span>
      </div>
    );
  }
  return (
    <div className="profile-chip" onClick={onClick}>
      <span className="profile-chip__dot"/>
      {active.length === 1
        ? <>Profile <strong style={{ fontWeight: 600 }}>{active[0].name}</strong> <span className="profile-chip__count">{active[0].version}</span></>
        : <>Profile <strong>{active.map(p => p.name).join(" + ")}</strong> <span className="profile-chip__count">{active.length} active</span></>
      }
    </div>
  );
};

/* Skip-That tray */
const SkipThatTray = ({ visible, recording, draftSnips }) => {
  if (!visible) return null;
  return (
    <div className="skipthat">
      <div className="skipthat__status">
        {recording && <span className="skipthat__rec"/>}
        <span style={{ fontFamily: "var(--font-mono)", fontSize: 11.5 }}>
          {recording ? "Recording snip · started 1:23:45" : `Draft · ${draftSnips} snips logged`}
        </span>
      </div>
      <div className="skipthat__hints">
        <div className="skipthat__hint"><Kbd>[</Kbd> Start 10s ago</div>
        <div className="skipthat__hint"><Kbd>\</Kbd> Start now</div>
        <div className="skipthat__hint"><Kbd>]</Kbd> Stop snip</div>
        <div className="skipthat__hint"><Kbd>Q</Kbd> Quick 10s</div>
      </div>
      <Btn icon="Edit" ghost style={{ color: "white" }}>View draft</Btn>
    </div>
  );
};

/* Profile switcher side panel */
const ProfileSwitcher = ({ profiles, onClose, onToggle, onPrimary }) => (
  <div className="psw" onClick={(e) => e.stopPropagation()}>
    <div className="row" style={{ padding: "10px 14px", borderBottom: "1px solid var(--border)", justifyContent: "space-between" }}>
      <div className="fz-14 fw-600">Profiles for this video</div>
      <IconBtn icon="Close" onClick={onClose} tooltip="Close"/>
    </div>
    <div className="scroll" style={{ flex: 1 }}>
      {profiles.map(p => (
        <div className={`psw__profile ${p.active ? "is-active" : ""}`} key={p.id}>
          <div className="psw__head-row">
            <button className="icb" style={{ color: p.primary ? "var(--amber)" : "var(--text-4)" }}
              title={p.primary ? "Primary profile" : "Set as primary"}
              onClick={() => onPrimary(p.id)}>
              {p.primary ? <window.I.StarFilled/> : <window.I.Star/>}
            </button>
            <div className="psw__name">{p.name}</div>
            <span className="psw__version">{p.version}</span>
            <div className="flex-1"/>
            <Toggle on={p.active} onChange={() => onToggle(p.id)}/>
          </div>
          <div className="psw__meta">
            {p.local ? <em>your local</em> : <>by <strong>{p.uploader}</strong></>} ·  {p.snipCount} snips · cuts {p.totalCut}
            {!p.local && <> · {p.downloads.toLocaleString()} dl · {p.upvotes} ↑</>}
          </div>
          <div className="psw__cats">
            {p.cats.map(c => <CatChip key={c} catId={c}/>)}
          </div>
        </div>
      ))}
    </div>
    <div className="row gap-8" style={{ padding: 12, borderTop: "1px solid var(--border)", background: "var(--surface-2)" }}>
      <Btn icon="File" ghost>Load .free…</Btn>
      <div className="flex-1"/>
      <Btn icon="Globe">Browse Hub</Btn>
    </div>
    <div className="row" style={{ padding: "10px 14px", borderTop: "1px solid var(--divider)", background: "var(--surface-2)" }}>
      <details style={{ width: "100%" }}>
        <summary className="row gap-6" style={{ cursor: "pointer", fontSize: 12, color: "var(--text-2)" }}>
          <window.I.Layers2 size={12}/> Stack details (restrictiveness hierarchy)
        </summary>
        <div style={{ fontSize: 11.5, color: "var(--text-3)", marginTop: 8, lineHeight: 1.6 }}>
          When snips overlap, the more-restrictive action wins:<br/>
          <span className="mono">Skip ▸ Freeze ▸ Silence ▸ Replace</span>
        </div>
      </details>
    </div>
  </div>
);

/* Now Playing panel */
const NowPlaying = ({ onClose }) => (
  <div className="now-playing">
    <div className="row" style={{ padding: "10px 14px", borderBottom: "1px solid var(--border)", justifyContent: "space-between" }}>
      <div className="fz-14 fw-600">Now Playing · {QUEUE.length}</div>
      <IconBtn icon="Close" onClick={onClose} tooltip="Close"/>
    </div>
    <div className="row" style={{ padding: "6px 12px", borderBottom: "1px solid var(--divider)" }}>
      <Seg value="simple" onChange={() => {}}
           options={[{value: "simple", label: "Simple"}, {value: "detail", label: "Detail"}, {value: "name", label: "Filename"}]}/>
    </div>
    <div className="scroll" style={{ flex: 1 }}>
      {QUEUE.map((q, i) => (
        <div key={i} className={`np-row ${q.current ? "is-current" : ""}`}>
          <span className="np-row__handle"><window.I.Hash size={12}/></span>
          <span className="np-row__name">{q.name}</span>
          {q.profile !== "none" && <ProfileStateBadge state={q.profile}/>}
          <span className="np-row__runtime">{q.runtime}</span>
        </div>
      ))}
    </div>
    <div className="row gap-6" style={{ padding: 8, borderTop: "1px solid var(--border)", background: "var(--surface-2)" }}>
      <Btn icon="Save" ghost>Save .m3u</Btn>
      <Btn icon="Trash" ghost>Clear</Btn>
      <div className="flex-1"/>
      <IconBtn icon="Shuffle" tooltip="Shuffle"/>
      <IconBtn icon="Repeat" tooltip="Repeat"/>
    </div>
  </div>
);

/* Hotkey cheatsheet overlay */
const Cheatsheet = ({ onClose }) => (
  <div className="cheatsheet" onClick={onClose}>
    <div className="cheatsheet__panel" onClick={(e) => e.stopPropagation()}>
      <div className="cheatsheet__head">
        <window.I.Help/>
        <div className="fz-16 fw-600">Hotkey cheatsheet</div>
        <div className="flex-1"/>
        <Btn icon="Settings" ghost onClick={onClose}>Customize…</Btn>
        <IconBtn icon="Close" onClick={onClose} tooltip="Close (Esc)"/>
      </div>
      <div className="cheatsheet__cols">
        {[
          ["Player Mode", HOTKEYS.player],
          ["Skip-That",   HOTKEYS.skipthat],
          ["Profile Creator", HOTKEYS.creator],
        ].map(([title, rows]) => (
          <div className="cheatsheet__col scroll" key={title}>
            <h4>{title}</h4>
            {rows.map(([k, l]) => (
              <div className="cheatsheet__row" key={k}>
                <span>{l}</span>
                <span className="kbd mono">{k}</span>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  </div>
);

/* End-of-playback summary toast */
const EndToast = ({ onClose }) => (
  <div className="toast">
    <div className="toast__head">
      <window.I.Sparkles className="text-blue"/>
      Cut <span className="text-blue mono">14m 22s</span> across 23 snips
    </div>
    <div className="toast__sub">
      <div className="row gap-4" style={{ flexWrap: "wrap", marginTop: 4 }}>
        <span className="chip chip--cat-language"><span className="dot"/>8 language</span>
        <span className="chip chip--cat-sex"><span className="dot"/>3 sex</span>
        <span className="chip chip--cat-boring"><span className="dot"/>12 boring</span>
      </div>
    </div>
    <div className="row" style={{ justifyContent: "flex-end", marginTop: 8 }}>
      <Btn ghost onClick={onClose}>Dismiss</Btn>
    </div>
  </div>
);

/* Fullscreen prompt */
const FsPrompt = ({ onYes, onNo }) => (
  <div className="toast" style={{ bottom: 80, left: "50%", right: "auto", transform: "translateX(-50%)" }}>
    <div className="toast__head"><window.I.Maximize/>Enter fullscreen mode?</div>
    <div className="toast__sub">Defaulting to fullscreen in <span className="mono">23s</span>…</div>
    <div className="row gap-6" style={{ marginTop: 10, justifyContent: "flex-end" }}>
      <Btn ghost onClick={onNo}>Don't ask again</Btn>
      <Btn onClick={onNo}>No <Kbd>Esc</Kbd></Btn>
      <Btn primary onClick={onYes}>Yes <Kbd>Enter</Kbd></Btn>
    </div>
  </div>
);

/* Main Player Mode */
const Player = ({ state, dispatch }) => {
  const { hasFile, playing, pos, volume, muted, fullscreen, profileOn, repeat, shuffle, stopAfter,
          panel, skipThatVisible, skipThatRecording, cheatsheet, endToast, fsPrompt, profiles, currentName } = state;

  const activeSnips = useMemo(() => SNIPS, []);
  const currentSnip = activeSnips.find(s => pos >= s.start && pos <= s.end);

  return (
    <div className="player">
      {!hasFile ? (
        <EmptyPlayer onOpen={() => dispatch({ type: "OPEN_FILE" })}/>
      ) : (
        <div className="player__canvas">
          <div className="player__videoframe">
            {/* Fake film grain / pseudo content */}
            <svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
              <defs>
                <radialGradient id="vig" cx="0.5" cy="0.4" r="0.9">
                  <stop offset="0%" stopColor="#34405a" stopOpacity="0.9"/>
                  <stop offset="100%" stopColor="#050810" stopOpacity="1"/>
                </radialGradient>
              </defs>
              <rect width="1600" height="900" fill="url(#vig)"/>
              {/* Silhouette of two figures looking at a window */}
              <rect x="500" y="180" width="600" height="520" fill="#0a1224" opacity="0.55"/>
              <rect x="540" y="220" width="520" height="280" fill="#1a2a4d" opacity="0.5"/>
              <rect x="540" y="500" width="520" height="200" fill="#0a1224" opacity="0.85"/>
              <circle cx="700" cy="640" r="80" fill="#06080f"/>
              <circle cx="900" cy="640" r="100" fill="#06080f"/>
              <rect x="0" y="700" width="1600" height="200" fill="#000" opacity="0.5"/>
            </svg>
            {/* Pseudo subtitle */}
            <div style={{ position: "absolute", bottom: 40, left: "50%", transform: "translateX(-50%)",
              fontSize: 18, color: "white", textShadow: "0 1px 2px rgba(0,0,0,.8)", fontFamily: "Geist, sans-serif", padding: "0 24px" }}>
              I always knew it would come to this.
            </div>
          </div>

          <ProfileChipOverlay
            profiles={profiles}
            profileOn={profileOn}
            onClick={() => dispatch({ type: "PANEL", panel: panel === "switcher" ? null : "switcher" })}
            onToggleAB={() => dispatch({ type: "AB_TOGGLE" })}
          />

          <SkipThatTray visible={skipThatVisible} recording={skipThatRecording} draftSnips={7}/>

          {currentSnip && profileOn && (
            <div style={{
              position: "absolute", top: 12, left: 12,
              background: "rgba(14,17,22,.7)", color: "white", padding: "4px 10px",
              borderRadius: 6, fontSize: 11, fontFamily: "var(--font-mono)",
              backdropFilter: "blur(4px)", border: "1px solid rgba(255,255,255,.08)",
            }}>
              {ACTION_BY_ID[currentSnip.action].label.toUpperCase()} · {currentSnip.cats.map(c => CAT_BY_ID[c]?.label).join(", ")}
            </div>
          )}

          {fsPrompt && <FsPrompt onYes={() => dispatch({ type: "FS_PROMPT", val: false })} onNo={() => dispatch({ type: "FS_PROMPT", val: false })}/>}
          {endToast && <EndToast onClose={() => dispatch({ type: "END_TOAST", val: false })}/>}
        </div>
      )}

      {hasFile && (
        <Transport
          playing={playing}
          vol={volume}
          muted={muted}
          repeat={repeat}
          shuffle={shuffle}
          stopAfter={stopAfter}
          fs={fullscreen}
          hasQueue={QUEUE.length > 1}
          pos={pos}
          duration={VIDEO_DURATION}
          snips={activeSnips}
          profileOn={profileOn}
          onPlay={() => dispatch({ type: "PLAY_TOGGLE" })}
          onMute={() => dispatch({ type: "MUTE_TOGGLE" })}
          onRepeat={() => dispatch({ type: "REPEAT_CYCLE" })}
          onShuffle={() => dispatch({ type: "SHUFFLE_TOGGLE" })}
          onStopAfter={() => dispatch({ type: "STOP_AFTER_TOGGLE" })}
          onFs={() => dispatch({ type: "FS_TOGGLE" })}
          onSeek={(p) => dispatch({ type: "SEEK", pos: p })}
          onNowPlaying={() => dispatch({ type: "PANEL", panel: panel === "queue" ? null : "queue" })}
        />
      )}

      {panel === "switcher" && (
        <ProfileSwitcher
          profiles={profiles}
          onClose={() => dispatch({ type: "PANEL", panel: null })}
          onToggle={(id) => dispatch({ type: "PROFILE_TOGGLE", id })}
          onPrimary={(id) => dispatch({ type: "PROFILE_PRIMARY", id })}
        />
      )}
      {panel === "queue" && <NowPlaying onClose={() => dispatch({ type: "PANEL", panel: null })}/>}
      {cheatsheet && <Cheatsheet onClose={() => dispatch({ type: "CHEATSHEET", val: false })}/>}
    </div>
  );
};

window.Player = Player;
window.MenuBar = MenuBar;
window.TitleBar = TitleBar;
