/* ---------- Settings + cross-cutting dialogs ---------- */

const Settings = ({ libraryEnabled, setLibraryEnabled, dispatch }) => {
  const [section, setSection] = useState("playback");
  const sections = [
    { id: "playback",   icon: "Play",       label: "Playback" },
    { id: "hotkeys",    icon: "Hash",       label: "Hotkeys" },
    { id: "categories", icon: "Tag",        label: "Categories" },
    { id: "subtitles",  icon: "Subtitle",   label: "Subtitles & Wordlist" },
    { id: "profiles",   icon: "File",       label: "Profiles & Files" },
    { id: "sharing",    icon: "Upload",     label: "Sharing & Uploader Key" },
    { id: "library",    icon: "Library",    label: "Library", disabled: !libraryEnabled, hint: libraryEnabled ? null : "Enable Library Mode in Playback to access" },
    { id: "storage",    icon: "Save",       label: "Storage & Cache" },
    { id: "updates",    icon: "Refresh",    label: "Updates" },
    { id: "about",      icon: "Info",       label: "About / TOS / Privacy" },
  ];

  return (
    <div className="settings">
      <aside className="settings-rail">
        {sections.map(s => {
          const Comp = window.I[s.icon];
          return (
            <div key={s.id}
                 className={`settings-rail__item ${section === s.id ? "is-active" : ""} ${s.disabled ? "is-disabled" : ""}`}
                 title={s.hint || ""}
                 onClick={() => !s.disabled && setSection(s.id)}>
              <Comp size={14}/>
              {s.label}
            </div>
          );
        })}
      </aside>
      <div className="settings-content scroll">
        {section === "playback"   && <PlaybackSection libraryEnabled={libraryEnabled} setLibraryEnabled={setLibraryEnabled}/>}
        {section === "hotkeys"    && <HotkeysSection/>}
        {section === "categories" && <CategoriesSection/>}
        {section === "subtitles"  && <SubtitlesSection/>}
        {section === "profiles"   && <ProfilesSection/>}
        {section === "sharing"    && <SharingSection/>}
        {section === "library"    && <LibrarySection/>}
        {section === "storage"    && <StorageSection/>}
        {section === "updates"    && <UpdatesSection/>}
        {section === "about"      && <AboutSection/>}
      </div>
    </div>
  );
};

const Row = ({ label, hint, children }) => (
  <div className="settings-row">
    <div>
      <div className="settings-row__label">{label}</div>
      {hint && <div className="settings-row__hint">{hint}</div>}
    </div>
    <div className="settings-row__ctrl">{children}</div>
  </div>
);

const Slider = ({ value, min = 0, max = 100, unit = "" }) => (
  <div className="row gap-8" style={{ width: "100%" }}>
    <div style={{ flex: 1, height: 6, background: "var(--surface-3)", borderRadius: 3, position: "relative" }}>
      <div style={{ position: "absolute", left: 0, top: 0, height: "100%", borderRadius: 3, background: "var(--blue)", width: `${((value - min) / (max - min)) * 100}%` }}/>
      <div style={{ position: "absolute", left: `${((value - min) / (max - min)) * 100}%`, top: -4, width: 14, height: 14, borderRadius: 50, background: "white", border: "1.5px solid var(--blue)", transform: "translateX(-50%)" }}/>
    </div>
    <span className="mono fz-12 dim" style={{ width: 64, textAlign: "right" }}>{value}{unit}</span>
  </div>
);

const PlaybackSection = ({ libraryEnabled, setLibraryEnabled }) => {
  const { Toggle, Seg } = window.UI;
  const [vol, setVol] = useState(100);
  const [resume, setResume] = useState(true);
  const [fsPrompt, setFsPrompt] = useState(true);
  const [endBehavior, setEndBehavior] = useState("stop");
  const [frameStep, setFrameStep] = useState("1");

  return (
    <>
      <h2>Playback</h2>
      <p className="sub">How the player behaves while you watch.</p>
      <Row label="Default volume" hint="0–125%. 100% is unity. Above 100% is software gain.">
        <Slider value={vol} max={125} unit="%"/>
      </Row>
      <Row label="Enter-fullscreen prompt" hint="Asks after 60s of windowed playback. Esc dismisses.">
        <Toggle on={fsPrompt} onChange={setFsPrompt}/>
      </Row>
      <Row label="End-of-queue behavior" hint="What to do when the last file in the queue ends.">
        <Seg value={endBehavior} onChange={setEndBehavior} options={[
          { value: "stop", label: "Stop" },
          { value: "all",  label: "Repeat all" },
          { value: "one",  label: "Repeat one" },
        ]}/>
      </Row>
      <Row label="Remember playback position per file" hint="Shows a Resume prompt on re-open, keyed per (file × profile stack).">
        <Toggle on={resume} onChange={setResume}/>
      </Row>
      <Row label="Frame-step granularity" hint=", and . hotkeys move this many frames.">
        <Seg value={frameStep} onChange={setFrameStep} options={[
          { value: "1", label: "1 frame" },
          { value: "5", label: "5 frames" },
          { value: "10", label: "10 frames" },
        ]}/>
      </Row>
      <Row label="Enable Library Mode" hint="Optional library/stats module. Off by default. Doesn't affect Player Mode performance.">
        <Toggle on={libraryEnabled} onChange={setLibraryEnabled}/>
      </Row>
      <Row label="HDR passthrough" hint="Pass HDR signal through to display when supported by the file and the monitor.">
        <Toggle on={true}/>
      </Row>
    </>
  );
};

const HotkeysSection = () => {
  const { HOTKEYS } = window.FVPData;
  const [q, setQ] = useState("");
  const groups = [
    ["Player Mode", HOTKEYS.player],
    ["Skip-That", HOTKEYS.skipthat],
    ["Profile Creator", HOTKEYS.creator],
  ];
  return (
    <>
      <h2>Hotkeys</h2>
      <p className="sub">Every action is rebindable. Conflicts prompt to swap.</p>
      <div className="row gap-8" style={{ marginBottom: 12 }}>
        <div style={{ position: "relative", flex: 1, maxWidth: 360 }}>
          <window.I.Search size={13} style={{ position: "absolute", left: 8, top: "50%", transform: "translateY(-50%)", color: "var(--text-3)" }}/>
          <input className="input input--sm" placeholder="Search actions or keys…" value={q} onChange={(e) => setQ(e.target.value)} style={{ paddingLeft: 26 }}/>
        </div>
        <div className="flex-1"/>
        <window.UI.Btn ghost icon="Refresh">Reset all to defaults</window.UI.Btn>
      </div>
      {groups.map(([title, rows]) => (
        <div key={title} style={{ marginBottom: 24 }}>
          <h3 className="h-section" style={{ margin: "12px 0 8px" }}>{title}</h3>
          <table className="hotkey-table">
            <thead><tr><th>Action</th><th>Binding</th><th style={{ width: 80 }}></th><th style={{ width: 60 }}></th></tr></thead>
            <tbody>
              {rows.filter(([k, l]) => !q || k.toLowerCase().includes(q.toLowerCase()) || l.toLowerCase().includes(q.toLowerCase())).map(([k, l], i) => (
                <tr key={i}>
                  <td>{l}</td>
                  <td><span className="kbd mono">{k}</span></td>
                  <td><a href="#" className="fz-11">Change…</a></td>
                  <td><a href="#" className="fz-11 faint">Reset</a></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
    </>
  );
};

const CategoriesSection = () => {
  const { Btn } = window.UI;
  const cats = window.FVPData.CATEGORIES;
  return (
    <>
      <h2>Categories</h2>
      <p className="sub">Default handling per category. Each snip can override its own.</p>

      <div className="card" style={{ padding: 14, background: "var(--blue-tint)", marginBottom: 18 }}>
        <div className="row gap-12">
          <window.I.Sync size={18} className="text-blue"/>
          <div className="col" style={{ flex: 1 }}>
            <div className="fw-600 fz-13">Sync with FVP server</div>
            <div className="dim fz-12">Last sync 2 days ago. Local list matches canonical v4.2.</div>
          </div>
          <Btn ghost>Overwrite local</Btn>
          <Btn primary>Merge with official</Btn>
        </div>
      </div>

      <div className="card">
        <div className="cat-row" style={{ fontSize: 10.5, color: "var(--text-3)", textTransform: "uppercase", letterSpacing: ".08em", background: "var(--surface-2)" }}>
          <span></span><span>Name</span><span>Default action</span><span>Type</span><span></span>
        </div>
        {cats.map(c => (
          <div key={c.id} className="cat-row">
            <span className="cat-row__swatch" style={{ background: c.color }}/>
            <span className="fz-13">{c.label}</span>
            <select className="select input--sm" defaultValue={c.defaultAction}>
              {window.FVPData.ACTIONS.map(a => <option key={a.id} value={a.id}>{a.label}</option>)}
            </select>
            <span className="chip chip--outline" style={{ padding: "1px 7px", fontSize: 10.5 }}>{c.bundled ? "bundled" : "user"}</span>
            <window.UI.IconBtn icon={c.bundled ? "Edit" : "Trash"} tooltip={c.bundled ? "Edit" : "Delete"} danger={!c.bundled}/>
          </div>
        ))}
      </div>
      <div className="row" style={{ marginTop: 14 }}>
        <Btn primary icon="Plus">Add custom category…</Btn>
        <div className="flex-1"/>
        <span className="faint fz-11">{cats.filter(c => !c.bundled).length} user-added · {cats.filter(c => c.bundled).length} bundled</span>
      </div>
    </>
  );
};

const SubtitlesSection = () => {
  const { Toggle, Seg } = window.UI;
  return (
    <>
      <h2>Subtitles & Wordlist</h2>
      <p className="sub">Auto-pick subtitle behavior, and the wordlist used for subtitle-driven snip suggestions.</p>
      <Row label="Auto-pick subtitle track">
        <Seg value="lang" onChange={() => {}} options={[
          { value: "off", label: "Off" }, { value: "auto", label: "Auto" }, { value: "lang", label: "Lang preference" }
        ]}/>
      </Row>
      <Row label="Default sync offset" hint="Static ms offset applied to subtitles if unspecified.">
        <input className="input input--sm mono" defaultValue="0 ms" style={{ width: 120 }}/>
      </Row>
      <Row label="Padding before suggested snips" hint="How much earlier than the subtitle entry to start the snip.">
        <input className="input input--sm mono" defaultValue="200 ms" style={{ width: 120 }}/>
      </Row>
      <Row label="Padding after suggested snips">
        <input className="input input--sm mono" defaultValue="300 ms" style={{ width: 120 }}/>
      </Row>
      <Row label="Default category for subtitle hits">
        <select className="select" defaultValue="language" style={{ width: 200 }}>
          {window.FVPData.CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
        </select>
      </Row>
      <h3 className="h-section" style={{ margin: "24px 0 8px" }}>Wordlist</h3>
      <Row label="Bundled wordlist v2.1" hint="Categorized: language, slurs, blasphemy. Read-only.">
        <Toggle on={true}/>
      </Row>
      <Row label="Your custom wordlist" hint="23 words. Stored in your profile.">
        <window.UI.Btn ghost icon="Edit">Edit…</window.UI.Btn>
      </Row>
    </>
  );
};

const ProfilesSection = () => {
  const { Toggle, Seg, Btn } = window.UI;
  return (
    <>
      <h2>Profiles & Files</h2>
      <p className="sub">How FVP matches profiles to video files and how it handles drafts.</p>
      <Row label="File-to-profile matching threshold" hint="Strict: all fingerprint fields must match. Loose: pHash + duration is enough.">
        <Seg value="moderate" onChange={() => {}} options={[
          { value: "strict",   label: "Strict" },
          { value: "moderate", label: "Moderate" },
          { value: "loose",    label: "Loose" },
        ]}/>
      </Row>
      <Row label="Auto-load all matching profiles" hint="When ON, every .free in the folder that matches is offered for stacking.">
        <Toggle on={true}/>
      </Row>
      <Row label="Draft autosave interval">
        <div style={{ width: 280 }}><Slider value={10} max={60} unit="s"/></div>
      </Row>
      <Row label="Drafts directory" hint="Where .free.draft files live.">
        <input className="input input--sm mono" defaultValue="Next to video files"/>
      </Row>
      <Row label="Show 'needs review' badge" hint="On uncategorized snips. Power users may turn this off.">
        <Toggle on={true}/>
      </Row>
    </>
  );
};

const SharingSection = () => {
  const { Btn } = window.UI;
  return (
    <>
      <h2>Sharing & Uploader Key</h2>
      <p className="sub">Your key is a local file. Without it you can still download profiles — you only need it to upload.</p>
      <div className="card" style={{ padding: 16, marginBottom: 16 }}>
        <div className="row gap-12">
          <div style={{ width: 36, height: 36, borderRadius: 8, background: "var(--blue)", color: "white", display: "grid", placeItems: "center" }}>
            <window.I.Tag size={18}/>
          </div>
          <div className="col" style={{ flex: 1 }}>
            <div className="row gap-6">
              <span className="fw-600 fz-13">@straightedge</span>
              <span className="chip" style={{ background: "var(--green-soft)", color: "var(--green)", padding: "1px 7px", fontSize: 10.5 }}>key loaded</span>
            </div>
            <div className="dim fz-12">Reserved 312 days ago · 12 profiles uploaded · 5,820 total downloads</div>
          </div>
          <Btn icon="Download">Export key file…</Btn>
          <Btn danger ghost icon="Trash">Forget on this device</Btn>
        </div>
      </div>
      <Row label="Generate new uploader key" hint="Single-use. Existing handle remains reserved by your existing key.">
        <Btn primary icon="Plus">Generate…</Btn>
      </Row>
      <Row label="Load existing key file" hint="Use a .key file from another device.">
        <Btn icon="File">Load .key…</Btn>
      </Row>
      <Row label="Hub URL" hint="The server FVP queries. Configurable for self-hosters.">
        <input className="input input--sm mono" defaultValue="https://hub.freedom-video.app"/>
      </Row>
    </>
  );
};

const LibrarySection = () => {
  const { Toggle, Btn } = window.UI;
  return (
    <>
      <h2>Library</h2>
      <p className="sub">Optional library/stats module. Settings only appear when Library Mode is enabled.</p>
      <h3 className="h-section" style={{ margin: "12px 0 8px" }}>Folders watched</h3>
      <div className="card">
        {["D:\\Movies", "D:\\TV Shows\\Halcyon", "E:\\Downloads\\Watch later"].map((f, i) => (
          <div key={i} className="row" style={{ padding: "8px 12px", borderBottom: i < 2 ? "1px solid var(--divider)" : "" }}>
            <window.I.Folder size={14} className="dim"/>
            <span className="mono fz-12" style={{ marginLeft: 8, flex: 1 }}>{f}</span>
            <span className="faint fz-11" style={{ marginRight: 12 }}>342 files</span>
            <Btn ghost>Pause</Btn>
            <window.UI.IconBtn icon="Trash" tooltip="Remove folder" danger/>
          </div>
        ))}
      </div>
      <Btn primary icon="Plus" style={{ marginTop: 12 }}>Add folder…</Btn>

      <h3 className="h-section" style={{ margin: "24px 0 8px" }}>Metadata provider</h3>
      <Row label="TMDB API key" hint="You bring your own. FVP doesn't host a key.">
        <input className="input input--sm mono" defaultValue="••••••••••••a4d2" style={{ width: 220 }}/>
      </Row>
      <Row label="OMDb API key (fallback)">
        <input className="input input--sm mono" placeholder="(not configured)" style={{ width: 220 }}/>
      </Row>
      <Row label="Content-warning sources">
        <div className="col gap-4">
          <label className="row gap-6 fz-12"><input type="checkbox" defaultChecked style={{ accentColor: "var(--blue)" }}/> DoesTheDogDie</label>
          <label className="row gap-6 fz-12"><input type="checkbox" defaultChecked style={{ accentColor: "var(--blue)" }}/> Common Sense Media</label>
        </div>
      </Row>
      <Row label="Whisper-based language detection" hint="Local, deferred. Scans audio for swear words to suggest snips — heavy on CPU/GPU.">
        <Toggle on={false}/>
      </Row>
      <Row label="Posters/images cache cap" hint="Older posters are evicted past this cap.">
        <div style={{ width: 280 }}><Slider value={500} max={5000} unit=" MB"/></div>
      </Row>
      <Row label="Library DB location" hint="WAL mode. Auto-backed-up.">
        <Btn ghost icon="Folder">Reveal in folder</Btn>
      </Row>

      <h3 className="h-section" style={{ margin: "24px 0 8px" }}>Viewers</h3>
      <div className="card">
        {window.FVPData.VIEWERS.map(v => (
          <div key={v.id} className="row" style={{ padding: "8px 12px", borderBottom: "1px solid var(--divider)" }}>
            <span style={{ width: 10, height: 10, borderRadius: 50, background: v.color }}/>
            <span className="fz-13 fw-500" style={{ marginLeft: 8 }}>{v.name}</span>
            <span className="faint fz-12" style={{ marginLeft: 8 }}>· defaults: {v.strict}</span>
            <div className="flex-1"/>
            <window.UI.IconBtn icon="Edit" tooltip="Edit"/>
            <window.UI.IconBtn icon="Trash" tooltip="Remove" danger/>
          </div>
        ))}
      </div>
      <Btn primary icon="Plus" style={{ marginTop: 12 }}>Add viewer…</Btn>

      <div className="card" style={{ padding: 16, marginTop: 32, background: "var(--red-soft)", borderColor: "color-mix(in oklab, var(--red) 30%, white)" }}>
        <div className="row gap-12">
          <window.I.Warn className="text-red"/>
          <div className="col" style={{ flex: 1 }}>
            <div className="fw-600">Reset library</div>
            <div className="dim fz-12">Clears the library database. Doesn't touch video files or .free profiles.</div>
          </div>
          <Btn danger>Reset library</Btn>
        </div>
      </div>
    </>
  );
};

const StorageSection = () => (
  <>
    <h2>Storage & Cache</h2>
    <p className="sub">Local storage budgets.</p>
    <Row label="Pre-decode buffer for seamless skipping" hint="Sized for upcoming cuts. Bigger = more memory, smoother skips.">
      <div style={{ width: 280 }}><Slider value={180} max={600} unit="s"/></div>
    </Row>
    <Row label="Poster/image cache cap">
      <div style={{ width: 280 }}><Slider value={500} max={5000} unit=" MB"/></div>
    </Row>
    <Row label="Cache currently uses" hint="34 MB posters · 12 MB scene markers · 8 MB pre-decode">
      <span className="mono fz-13">54 MB / 500 MB</span>
    </Row>
    <Row label="Library DB location">
      <window.UI.Btn ghost icon="Folder">Reveal in folder</window.UI.Btn>
    </Row>
    <Row label="Portable mode" hint="When ON, all settings, cache, and library DB live next to the FVP executable instead of in %APPDATA%.">
      <window.UI.Toggle on={false}/>
    </Row>
    <div style={{ marginTop: 20 }}>
      <window.UI.Btn ghost icon="Trash">Clear cache…</window.UI.Btn>
    </div>
  </>
);

const UpdatesSection = () => (
  <>
    <h2>Updates</h2>
    <p className="sub">Application + profile updates.</p>
    <Row label="Check for updates on startup">
      <window.UI.Toggle on={true}/>
    </Row>
    <Row label="Update channel">
      <window.UI.Seg value="stable" onChange={() => {}} options={[
        { value: "stable", label: "Stable" },
        { value: "beta",   label: "Beta" },
      ]}/>
    </Row>
    <Row label="Profile-update behavior" hint="When a newer version of a loaded profile is detected on FVP Hub.">
      <window.UI.Seg value="prompt" onChange={() => {}} options={[
        { value: "prompt", label: "Prompt" },
        { value: "auto",   label: "Auto-apply" },
        { value: "never",  label: "Never" },
      ]}/>
    </Row>
    <div className="card" style={{ padding: 14, marginTop: 24 }}>
      <div className="row gap-12">
        <window.I.Check size={18} className="text-green"/>
        <div className="col" style={{ flex: 1 }}>
          <div className="fw-600">You're on the latest version</div>
          <div className="dim fz-12">FVP 1.4.2 — released Sep 12, 2025</div>
        </div>
        <window.UI.Btn icon="Refresh">Check now</window.UI.Btn>
      </div>
    </div>
  </>
);

const AboutSection = () => (
  <>
    <h2>About / TOS / Privacy</h2>
    <div className="row gap-16" style={{ marginTop: 20, alignItems: "flex-start" }}>
      <div style={{ width: 64, height: 64, borderRadius: 12, display: "grid", placeItems: "center", background: "var(--text)", boxShadow: "var(--shadow-2)" }}>
        <window.Brand size={36}/>
      </div>
      <div className="col">
        <div className="fz-20 fw-700" style={{ letterSpacing: "-.01em" }}>Freedom Video Player</div>
        <div className="dim fz-12">v1.4.2 · build 28e9f01 · MIT</div>
        <div className="dim fz-12" style={{ marginTop: 4 }}>A video player that respects your right to cut what you don't want to watch.</div>
      </div>
    </div>
    <div className="row gap-8" style={{ marginTop: 18 }}>
      <window.UI.Btn ghost>TOS</window.UI.Btn>
      <window.UI.Btn ghost>Privacy</window.UI.Btn>
      <window.UI.Btn ghost>How it works</window.UI.Btn>
      <window.UI.Btn ghost>Credits</window.UI.Btn>
    </div>
  </>
);

/* ---------- Dialogs ---------- */

const TOSDialog = ({ onAgree }) => {
  const [agreed, setAgreed] = useState(false);
  const { Btn } = window.UI;
  return (
    <div className="overlay">
      <div className="modal" style={{ minWidth: 520, maxWidth: 580 }}>
        <div className="modal__head" style={{ paddingBottom: 12 }}>
          <div className="row gap-12" style={{ alignItems: "center" }}>
            <window.Brand size={28}/>
            <div className="modal__title">Welcome to Freedom Video Player</div>
          </div>
        </div>
        <div className="modal__body" style={{ paddingTop: 0 }}>
          <p style={{ marginTop: 0 }}>
            FVP lets you create your own viewing experience for the videos <em>you own</em>. You can skip, silence, freeze-frame, or audio-replace any segment of any file on your device.
          </p>
          <p>
            <strong>By continuing, you agree:</strong>
          </p>
          <ul style={{ paddingLeft: 18, color: "var(--text-2)" }}>
            <li>You will only modify videos that you own and have the right to modify.</li>
            <li>FVP is a private viewing tool. It does not redistribute or alter source files.</li>
            <li>Profiles you share are your own work; FVP is not responsible for users' use or misuse of the tool.</li>
          </ul>
          <label className="row gap-8 cursor-pointer" style={{ marginTop: 18, padding: 10, background: "var(--surface-2)", borderRadius: 8 }}>
            <input type="checkbox" checked={agreed} onChange={(e) => setAgreed(e.target.checked)} style={{ accentColor: "var(--blue)" }}/>
            <span className="fz-12">I agree to the terms above.</span>
          </label>
        </div>
        <div className="modal__foot">
          <Btn ghost>Read full TOS</Btn>
          <div className="flex-1"/>
          <Btn primary disabled={!agreed} onClick={onAgree}>Continue</Btn>
        </div>
      </div>
    </div>
  );
};

const ResumeDialog = ({ onClose }) => {
  const { Btn } = window.UI;
  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal__head">
          <div className="modal__title">Resume from <span className="mono">1:24:18</span>?</div>
          <div className="modal__sub">Last watched with profile: <strong>Family v3</strong> + <strong>No Filler v2</strong></div>
        </div>
        <div className="modal__body">
          <div className="row gap-12" style={{ padding: 12, background: "var(--surface-2)", borderRadius: 8 }}>
            <window.I.Clock className="text-blue"/>
            <div className="col" style={{ flex: 1, fontSize: 12 }}>
              <span className="dim">3 days ago · Mom</span>
              <span>The Pinnacle (2024) — windowed playback</span>
            </div>
          </div>
        </div>
        <div className="modal__foot">
          <Btn ghost onClick={onClose}>Always start over</Btn>
          <Btn ghost onClick={onClose}>Always resume</Btn>
          <div className="flex-1"/>
          <Btn ghost onClick={onClose}>Start over</Btn>
          <Btn primary onClick={onClose}>Resume <window.UI.Kbd>Esc</window.UI.Kbd></Btn>
        </div>
      </div>
    </div>
  );
};

const FingerprintDialog = ({ onClose }) => {
  const { Btn } = window.UI;
  const checks = [
    { field: "Filename",         match: false, mine: "Pinnacle.2024.1080p.WEB.mkv", their: "The.Pinnacle.2024.1080p.BluRay.x265.mkv" },
    { field: "File size",        match: false, mine: "8.4 GB",                       their: "11.2 GB" },
    { field: "Duration",         match: true,  mine: "1:47:00.000",                  their: "1:47:00.012" },
    { field: "pHash @ 5/25/50/75/95%", match: true, mine: "5/5 match", their: "" },
  ];
  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" style={{ maxWidth: 580 }} onClick={(e) => e.stopPropagation()}>
        <div className="modal__head">
          <div className="row gap-12">
            <window.I.Warn className="text-amber" size={22}/>
            <div className="col">
              <div className="modal__title">This profile may not be for this video</div>
              <div className="modal__sub">Filename and size differ, but pHash and duration match — likely a re-encode.</div>
            </div>
          </div>
        </div>
        <div className="modal__body">
          <table className="hotkey-table">
            <thead><tr><th>Field</th><th>Yours</th><th>Profile</th><th>Match</th></tr></thead>
            <tbody>
              {checks.map((c, i) => (
                <tr key={i}>
                  <td className="fw-500">{c.field}</td>
                  <td className="mono dim fz-11" style={{ maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis" }}>{c.mine}</td>
                  <td className="mono dim fz-11" style={{ maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis" }}>{c.their}</td>
                  <td>{c.match
                      ? <window.I.Check className="text-green" size={14} strokeWidth={3}/>
                      : <window.I.Close className="text-red" size={14} strokeWidth={3}/>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="modal__foot">
          <Btn ghost onClick={onClose}>Cancel</Btn>
          <Btn ghost onClick={onClose} icon="Edit">Use as template</Btn>
          <Btn primary onClick={onClose}>Load anyway</Btn>
        </div>
      </div>
    </div>
  );
};

const UnknownCategoryDialog = ({ onClose }) => {
  const { Btn } = window.UI;
  const [action, setAction] = useState("skip");
  const [remember, setRemember] = useState(true);
  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal__head">
          <div className="modal__title">Unknown category: "<span className="mono">agenda:moral-relativism</span>"</div>
          <div className="modal__sub">This profile uses a category that's not in your local list. How should FVP handle it by default?</div>
        </div>
        <div className="modal__body">
          <div className="col gap-6">
            {window.FVPData.ACTIONS.map(a => {
              const Ico = window.I[a.icon];
              return (
                <label key={a.id}
                       className="row gap-8 cursor-pointer"
                       style={{ padding: 10, border: "1px solid var(--border)", borderRadius: 8,
                         background: action === a.id ? "var(--blue-soft)" : "var(--surface)",
                         borderColor: action === a.id ? "var(--blue)" : "var(--border)" }}>
                  <input type="radio" checked={action === a.id} onChange={() => setAction(a.id)} style={{ accentColor: "var(--blue)" }}/>
                  <Ico size={14} style={{ color: action === a.id ? "var(--blue)" : "var(--text-2)" }}/>
                  <div className="col">
                    <span className="fz-13 fw-500">{a.label}</span>
                    <span className="faint fz-11">{a.hint}</span>
                  </div>
                </label>
              );
            })}
            <label className="row gap-8 cursor-pointer"
                   style={{ padding: 10, border: "1px solid var(--border)", borderRadius: 8,
                     background: action === "ignore" ? "var(--blue-soft)" : "var(--surface)",
                     borderColor: action === "ignore" ? "var(--blue)" : "var(--border)" }}>
              <input type="radio" checked={action === "ignore"} onChange={() => setAction("ignore")} style={{ accentColor: "var(--blue)" }}/>
              <window.I.EyeOff size={14} style={{ color: action === "ignore" ? "var(--blue)" : "var(--text-2)" }}/>
              <div className="col">
                <span className="fz-13 fw-500">Ignore</span>
                <span className="faint fz-11">Pass through normally as if the snip didn't exist.</span>
              </div>
            </label>
          </div>
          <label className="row gap-8 cursor-pointer" style={{ marginTop: 14 }}>
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} style={{ accentColor: "var(--blue)" }}/>
            <span className="fz-12">Remember this for future profiles</span>
          </label>
        </div>
        <div className="modal__foot">
          <Btn ghost onClick={onClose}>Cancel</Btn>
          <Btn primary onClick={onClose}>Apply</Btn>
        </div>
      </div>
    </div>
  );
};

const ProfileUpdateDialog = ({ onClose }) => {
  const { Btn } = window.UI;
  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal__head">
          <div className="modal__title">"Family Friendly v4" is available</div>
          <div className="modal__sub">You have v3 loaded · 2 added, 1 removed, 4 edited</div>
        </div>
        <div className="modal__body">
          <div className="col gap-4">
            <div className="row gap-8" style={{ padding: 8, background: "color-mix(in oklab, var(--green) 8%, white)", borderRadius: 6, fontSize: 12 }}>
              <span className="chip" style={{ background: "var(--green)", color: "white", padding: "1px 6px", fontSize: 10 }}>+</span>
              <span className="mono">1:32:14 → 1:32:28</span>
              <span className="dim">Language · skip</span>
            </div>
            <div className="row gap-8" style={{ padding: 8, background: "color-mix(in oklab, var(--green) 8%, white)", borderRadius: 6, fontSize: 12 }}>
              <span className="chip" style={{ background: "var(--green)", color: "white", padding: "1px 6px", fontSize: 10 }}>+</span>
              <span className="mono">1:48:02 → 1:48:08</span>
              <span className="dim">Language · silence</span>
            </div>
            <div className="row gap-8" style={{ padding: 8, background: "color-mix(in oklab, var(--red) 6%, white)", borderRadius: 6, fontSize: 12 }}>
              <span className="chip" style={{ background: "var(--red)", color: "white", padding: "1px 6px", fontSize: 10 }}>−</span>
              <span className="mono">0:35:18 → 0:35:24</span>
              <span className="dim">(removed — false positive)</span>
            </div>
            <div className="row gap-8" style={{ padding: 8, background: "color-mix(in oklab, var(--amber) 8%, white)", borderRadius: 6, fontSize: 12 }}>
              <span className="chip" style={{ background: "var(--amber)", color: "white", padding: "1px 6px", fontSize: 10 }}>~</span>
              <span className="mono">1:14:30 → 1:14:58</span>
              <span className="dim">Action changed: silence → skip</span>
            </div>
          </div>
        </div>
        <div className="modal__foot">
          <Btn ghost onClick={onClose}>Never check for this profile</Btn>
          <div className="flex-1"/>
          <Btn ghost onClick={onClose}>Keep current</Btn>
          <Btn ghost onClick={onClose}>Merge…</Btn>
          <Btn primary onClick={onClose}>Upgrade to v4</Btn>
        </div>
      </div>
    </div>
  );
};

window.Settings = Settings;
window.TOSDialog = TOSDialog;
window.ResumeDialog = ResumeDialog;
window.FingerprintDialog = FingerprintDialog;
window.UnknownCategoryDialog = UnknownCategoryDialog;
window.ProfileUpdateDialog = ProfileUpdateDialog;
