Freedom Video Player (aka FVP)

Main idea: A video player by which users can create their own custom viewing experiences for video files that they own. Users create custom "Profiles" for a video file, which skip/modify the video file in realtime - i.e. skipping sex scenes, language, agenda, etc. Two modes: Video Player Mode and Profile Creation Mode. Additionally, there's a simple website for users to share their profiles with each other (see website_specs.md — that's "chapter 2", built after the player).

Vocabulary:
- A **Profile** is the entire collection of edits/decisions for one video file (saved as a `.free` file).
- A **Snip** is a single segment within a profile that's flagged to be skipped, silenced, freeze-framed, or audio-replaced.

# Software / Platform
- Cross-platform: Windows first, then Mac, Android, eventually iOS.
- We are NOT forcing a one-size-fits-all engine. If writing separate per-platform players produces better speed/quality, build separate players. Quality and speed > codebase unification.
- VLC-type format accommodation: lots of formats accommodated.
- LIGHTNING FAST. Speed and stability are PARAMOUNT. Minimal clicks; efficient UI. Minimal features: think Media Player Classic, not VLC.
- Portable mode: settings can live next to the .exe instead of in %APPDATA%.
- Per-monitor DPI awareness; HDR passthrough where supported.
- Crash-safe autosave for any in-progress Profile Creator work every N seconds.

# Player controls (Player Mode)
- Play/Pause, Shuffle, Repeat (all / 1), Skip < >, Seek bar.
- Stop After (only available if more than one file in queue; tooltip: "stops play after the currently-playing file completes playback").
- Tooltip EVERYTHING, with helpful tooltips.
- Configurable hotkeys for all controls (Settings).
- A user-visible hotkey map / cheatsheet overlay, accessible from the Help menu and from a hotkey itself (proposed default: `?`).
- Fullscreen mode. If user hasn't gone fullscreen after 60s: prompt "Would you like to enter fullscreen mode? Defaulting to fullscreen mode in 30s... (countdown)" — toggleable in settings.
- Volume control (default 100; can be adjusted to 125% like VLC).
- Mute.
- Subtitles: selectable / toggleable via right-click menu.
- Drag-and-drop file loading.
- Minimal Now Playing playlist.
- Open DVD-ripped folder.
- Player controls: audio track and subtitle track sync adjust.
- Open multiple files at once, or open a folder.
- Open recent files.
- Save Now Playing as .m3u playlist.
- Frame-step (proposed default `,` and `.`) with millisecond timestamp display — critical for precise scrubbing.

# Menus (top menu AND right-click menu)
- Video Playback: Title, Chapter, Speed, Jump to custom time
- Video settings: Video track, Fullscreen, Deinterlace, Deinterlace mode
- Audio: Audio Track, Audio Device, Stereo mode
- Subtitle: Add Subtitle File, Select Subtitle Track
- View: Now Playing List, Playlist view mode (Simple list / Detailed list / Filename), Always on top
- Tools: A/V & Subtitles Sync, Media Information, Codec Information, Settings, Help, Check for Updates, About/TOS/Privacy Policy

# Profile Creation Mode

Snip authoring:
- Drag edges to adjust start/stop. Hotkeys: ctrl+arrow nudges selected edge 1s; ctrl+shift+arrow nudges 5s. Millisecond precision available via frame-step.
- Audio waveform + scene-change markers rendered on the snip timeline to help find cut points fast.
- Snips can overlap. Snips can have multiple categories.
- Snips can be organized into named groups/labels within a profile (e.g., "Hotel scene", "Battle gore") so a 40-snip profile stays readable.
- Live snip preview: select a snip, hit a hotkey, plays from a few seconds before through after with the action applied. Tight feedback loop.
- A/B toggle: a hotkey that hot-flips the active profile on/off in real time — lets the user instantly compare "with filter / without filter" mid-playback to verify a cut feels seamless.
- Undo/redo stack.

Snip actions:
(a) **Skip** — player seamlessly skips over the segment
(b) **Silence** — plays the segment with audio muted
(c) **Audio-replace** — video plays. User picks a single search direction (before OR after the snip). The system auto-calculates the required length of source audio based on the snip's duration, grabs it from immediately adjacent to the snip in the chosen direction, and auto-crossfades it in/out. The search will never reach into another skipped snip — if the adjacent region in the chosen direction is too short, the user is prompted to flip direction.
(d) **Freeze-frame** — freezes the first frame of the segment, plays the audio

Overlap precedence (restrictiveness hierarchy):
**Skip > Freeze-frame > Silence > Audio-replace.**
When two snips overlap with different actions, the more-restrictive action wins for the overlapping region.

Profile saving / linking:
- Saved as proprietary `.free` file (signed, schema-versioned, JSON or MessagePack — TBD).
- Lives alongside the video file (like an .srt).
- Linked to the video file via the matching scheme below.
- **Profile Stacking:** multiple `.free` files can apply to the same video. Auto-detect all matching profiles in the folder. User picks which to enable; can enable multiple simultaneously (e.g., "Family Friendly" + "Skip Filler"). The restrictiveness hierarchy resolves any conflicts. A quick switcher in Player Mode lets the user toggle individual stacked profiles on/off mid-playback.

# File-to-Profile matching
Goal: better than `.srt`-style filename-only matching, without the cost of a full-file hash. Speed > ironclad accuracy. Needs to disambiguate when a folder contains many similar files.

Lightweight fingerprint stored INSIDE each `.free` file:
- Original filename
- File size
- Container/codec ID
- Duration (ms)
- Perceptual frame hash (pHash) sampled at fixed % marks of duration (e.g., 5%, 25%, 50%, 75%, 95%) — tiny payload, survives re-encoding, very fast to compute (just samples a handful of frames)

On load, score every `.free` in the folder against the open video file:
- All fields match → load silently.
- Filename differs but pHash + duration match (e.g., user re-encoded) → load with a soft notice.
- Major mismatch → warn the user but allow load anyway (existing behavior).

This also lets a folder of many videos + many `.free` files auto-pair correctly.

# Categories
- Canonical category list ships bundled with the app (e.g., sex, violence, language, boring content, agenda: feminism, agenda: LGBTQUIA+, agenda: socialism, agenda: atheism, etc.).
- Each default category has a default handling rule (skip / silence / freeze-frame / audio-replace), set per-user in Settings.
- User can create custom categories — must pick a default action on creation.
- **Per-snip override:** the default handling for a category can be overridden on an individual snip (e.g., this swearword skipped, that one silenced).
- "Sync categories with server" option in Settings: (a) overwrite local with official FVP list, or (b) merge local with official.
- When loading a profile that contains an UNKNOWN category, prompt the user once how to handle it (with "remember this" checkbox).

# Seamless skipping (no stutter, no black frame)
Hard requirement. Strategy:
- On profile load, pre-compute every skip transition: pre-decode a small buffer of frames + audio around each cut point and cache it.
- On approach to a skip, start decoding from the destination keyframe in parallel ahead of time so when the skip fires, frames are already in the buffer.
- For unavoidable codec edge cases, a configurable transition can be used (default: hard cut; options: tiny dip-to-black or crossfade).
- Caching budget Settings-configurable; default sized to keep the next several minutes of upcoming cuts ready.

# "Skip That" — passive profile building in Player Mode
While watching, the user can flag content into a draft profile attached to the file. Hotkey-driven buttons:
- **Start snip 10s ago** — back-anchors a snip starting 10s before the press
- **Start snip now** — anchors start at current playback position
- **Stop snip** — ends the currently open snip at current position
- **Quick 10s snip** — drops a complete 10s snip (5s before + 5s after the press)

These accumulate into a draft profile that auto-saves as a hidden `.free.draft` file alongside the video. No prompt on close — drafts persist silently and are recoverable on next open.

Snips dropped via Skip-That start **uncategorized** and display a visible "needs review" badge in the Profile Creator timeline. Export to a final `.free` requires every snip to have at least one category; this forces a quality pass before sharing.

# Subtitle-driven snip suggestions
- Bundle a default wordlist (categorized: language / slurs / etc.).
- On profile creation, scan loaded `.srt` against the wordlist.
- Auto-suggest snips with category "language" pre-filled at each hit.
- Default suggested snip span: the full subtitle entry's time range + 0.2s before / 0.3s after (subtitle timing is loose; the word can sit anywhere within the entry). User can adjust the default padding globally in Settings.
- User reviews/accepts in a batch.

# Subtitle handling during snip actions
- **Skip snips:** (1) any subtitle entry whose time range falls inside the cut is dropped (it has nowhere to play); (2) every subtitle AFTER the cut has its timestamps shifted earlier by the cut duration so it stays in sync with the still-playing audio/video.
- **Silence / Freeze-frame / Audio-replace snips:** no shift — playback timing is unchanged, so subtitle timing is unchanged.
- Sync is paramount. Shift math runs once when the profile loads; subtitle stream is re-emitted on the fly.

# End-of-playback summary
A toast/summary at end of playback shows what the active profile(s) cut. Framed as "cut the junk":
- "Cut 14m 22s across 23 snips."
- Breakdown by category (e.g., 8 language, 3 sex, 12 boring).

# Resume-with-profile
Opt-in Setting: "Remember playback position per file." When enabled, FVP saves last position per (file × active profile set). On re-open of that file, prompts: "Resume from HH:MM:SS?" with Yes / No / Always-resume / Always-restart options.

When the user enters Profile Creator from active playback in Player Mode, snapshot current position and open the creator at that timestamp (don't restart from 00:00).

# Update prompt
When a newer version of a loaded profile is available (from the sharing site), prompt: "A newer version of this profile is available (v3, 2 new snips). View diff?" Show before/after; let user keep current, upgrade, or merge.

# First-run / legal
On first start: TOS click-through only. User agrees that they will only modify videos to which they have rights and are allowed to modify, etc. FVP is not responsible for users using or misusing the tool.

No category-handling walkthrough (defaults are bundled and editable later in Settings). No uploader-key walkthrough (user can generate one later from Settings if/when they want to upload). No demo video.

# Default hotkey map (all configurable in Settings)

**Player Mode:**
- Space — Play/Pause
- F — Fullscreen toggle
- M — Mute toggle
- Up / Down — Volume +/-
- Left / Right — Seek -5s / +5s
- Ctrl+Left / Ctrl+Right — Seek -10s / +10s
- Shift+Left / Shift+Right — Seek -1m / +1m
- `,` / `.` — Frame-step backward / forward
- N — Next file in queue
- B — Previous file in queue
- R — Cycle Repeat (off / all / 1)
- X — Shuffle toggle
- T — A/B profile toggle (active filter on/off in real time)
- ? — Show hotkey cheatsheet overlay
- Esc — Exit fullscreen / close dialog
- Ctrl+O — Open file(s)
- Ctrl+Shift+O — Open folder
- Ctrl+Alt+O — Open DVD-ripped folder

**Skip-That (available in Player Mode):**
- `[` — Start snip 10s ago (back-anchored)
- `]` — Stop current snip
- `\` — Start snip now
- Q — Quick 10s snip (5s before + 5s after press)

**Profile Creator Mode:**
- I / O — Mark in-point / out-point at current frame
- Ctrl+Arrow Left / Right — Nudge selected edge 1s
- Ctrl+Shift+Arrow Left / Right — Nudge selected edge 5s
- Enter — Preview selected snip (plays a few seconds before/after with the action applied)
- Delete — Delete selected snip
- Tab — Cycle to next snip
- Ctrl+G — Group selected snips (named label)
- Ctrl+E — Edit selected snip's categories / action
- Ctrl+Z / Ctrl+Shift+Z — Undo / redo
- Ctrl+S — Save profile
