Freedom Video Player — Library Component (Optional Module)

Status: Chapter 3 — built AFTER the player (chapter 1) and sharing site (chapter 2) ship.

# Core constraint
The Library is a separate, optional Mode alongside Player Mode and Profile Creator Mode. It is entirely walled off:

- Disable-able with a single toggle. When disabled, FVP boots straight into Player Mode like nothing was ever added.
- NEVER becomes the default front door. Player Mode remains the default boot target unless the user explicitly opts in.
- Library code paths must never block the player. The player is the product; the library is the optional companion.
- Storage is a sidecar SQLite database (WAL mode, periodic backup, portable-mode compatible).
- Mission discipline: FVP is *the filtering tool with a library*, not *a library that also filters*. Any library feature that compromises Player Mode speed is rejected.

# The unique angle: profile-aware library
No other library tool (Plex, Kodi, Jellyfin, Emby) understands content filtering. This is the moat. Features unique to FVP:

- **Profile-state badge per title:** "✓ has profile" / "stacked (N)" / "draft in progress" / "no profile" / "profile available on Hub for your file"
- **Filter by profile state:** "show me everything I own with a Family-safe profile"
- **Hub-aware feed:** "New profiles on FVP Hub for files you already own" — driven by fingerprint matching from `.free` matching scheme (see directives.md)
- **Mood/occasion presets:** one click → "Family movie night" filter shows only titles that have a family-tier profile available; "Date night safe" shows titles with profiles that cut sex/violence above threshold
- **Per-viewer profile defaults:** local-only "viewer" labels (no accounts) — Mom watches with her stack, kids with theirs. Library auto-applies the right stack and credits stats to the right bucket.
- **Profile audit warnings:** "12 of your profiles use a category that's no longer in your bundled list" / "this profile hasn't been previewed since v2"

# Library essentials (table stakes)
- **Folder watch:** point at one or more folders; auto-index; watch for new/changed/removed files
- **Metadata lookup (opt-in):** user-supplied TMDB / OMDb API key (FVP does NOT host a key). Pulls poster, plot, year, genre, MPAA rating, runtime, cast, director
- **Metadata provider abstraction:** swappable backend — never hardcode a single provider
- **Search / sort / filter:** title, year, genre, runtime, MPAA rating, language, date added, last watched, profile state
- **Watched / unwatched / partial state**
- **Collections / shelves:** user-defined (e.g., "Christmas movies", "Pixar", "Westerns")
- **Series detection:** TV show + season + episode parsed from folder structure; per-series episode tracking
- **Watchlist** (queue future plays) and **Continue Watching** shelf (pairs with resume-with-profile)
- **Random pick with active filters:** "pick a comedy under 100 min with a Family profile"

# Auto-tagging
- MPAA rating, genre, year — from metadata provider
- Audio language tracks + subtitle availability + container/codec/resolution/HDR — auto-detected by media inspection
- **Content-warning ingestion (opt-in):** community sources (DoesTheDogDie-style, Common Sense Media-style if licensing permits). Becomes a *suggestion pool* for snip categories — doesn't auto-create snips, just informs the user "this title has flagged content for: gore, language, sex."
- **Whisper-based language detection (opt-in, local, deferred):** scan audio for swear words → suggest snips. Works on titles with no subtitles. Big add for foreign-language content. Must run fully local; never phones home.
- File-health detection: missing files, broken paths, duplicates, fingerprint drift (the underlying file changed but the linked profile didn't)

# Stats / "cut the junk" dashboard
A dedicated Stats view inside Library Mode. Framing is "cut the junk," not "saved time."

- **Cumulative junk cut** across all viewings: "you've cut 47h of language, 18h of sex, 12h of boring filler, 3h of agenda content"
- **Per-title breakdown:** sparkline of category cuts per movie
- **Most-cut titles** leaderboard
- **Profile productivity:** snips authored / profiles created / profiles uploaded per month
- **Hub stats** (if uploader key loaded): your profiles' downloads, upvotes, flag count
- **Local viewing log** (deletable any time, never phones home): when did you last watch X with which profile stack
- **Time-in-player**, time-cut-vs-uncut

Privacy: all stats are local. Wipe-able from Settings. No telemetry. Library never sends viewing data to FVP servers.

# Nice-to-haves
- **Bulk operations:** re-tag many files, batch-refresh fingerprints, batch profile audit
- **Disk-space awareness** per watched folder
- **Subtitle / dub availability badges** at-a-glance on each card
- **"Profiles you haven't shared yet"** gentle nudge
- **Smart shelves:** saved filter combos pinned as one-click shelves
- **Library export:** CSV/JSON dump for power users
- **View modes:** grid (default), list, detailed list, coverflow — one fast default, others optional
- **Multi-user "viewer" labels:** no accounts; "who's watching tonight?" → applies their default stack and credits their stats bucket
- **Library deep-link from website:** clicking a Hub profile lights up "you already own this movie" if it's in your local library
- **Now Playing integration:** Library Mode and Player Mode share a "recently played" rail so the user never loses context

# Privacy / philosophy
- All metadata lookups, content-warning fetches, and Whisper scans are opt-in
- Cache locally; never phone home with viewing data
- Library data lives in user-controlled location (portable mode compatible)
- Library Mode can be entirely disabled — when off, the feature doesn't even appear in the UI

# Tech foundation
- SQLite (WAL mode) sidecar database
- Periodic auto-backup of the DB
- Library indexing and metadata fetching run on background threads — NEVER block the player
- Folder watch via OS file system events (not polling)
- Cache size cap for posters/images (Settings-configurable; defaults small)
- DB schema-versioned with forward-only migrations

# Risks to actively guard against
- **Scope creep:** every Library feature added is one not added to Player. Hold the line.
- **Posters/images bloat:** enforce cache cap; allow user disable.
- **Metadata source lock-in:** abstract the provider; never hardcode TMDB.
- **DB corruption affecting player:** library failures must degrade gracefully — player keeps working with no library at all.
- **Mission drift toward Plex-clone:** stay disciplined.
