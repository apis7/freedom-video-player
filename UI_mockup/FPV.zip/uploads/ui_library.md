FVP — UI Spec: Library Component

Status: chapter 3 UI. Library Mode is OPTIONAL and OFF by default. Never the boot front-door. See library_component.md for functional spec.

Visual ethos: still minimal, but allowed more density and richness than Player Mode (posters, grids, etc.) because the user has explicitly opted in to browse rather than play.

# Mode entry
- Library Mode is reached via a dedicated mode-switcher control accessible in Player Mode and Profile Creator Mode (e.g., top-left mode dropdown or a slim mode tab strip)
- Library Mode is only visible/accessible when "Enable Library Mode" is ON in Settings > Playback
- First entry into Library Mode (no folders configured yet): shows the Library Onboarding state

# Library onboarding (first-time, no folders, no metadata key)
- Single, friendly centered panel inside Library Mode
- Step 1: "Pick folders to index" — folder picker, multi-select, with explainer that FVP will watch these folders and never modify their contents
- Step 2 (optional, skippable): "Connect a metadata source" — paste TMDB / OMDb API key, with link to docs explaining how to get one; explainer: "FVP doesn't host an API key. You bring your own."
- Step 3: "Pick your view modes and content-warning sources" — optional opt-ins for content-warning data fetch and Whisper-based language detection
- "Skip for now" available on every step
- After onboarding, library indexing starts in the background; user lands in main library view (possibly empty until indexing completes)

# Main library view
Three regions:

**Left rail: filters & shelves** (collapsible)
- Search box at top
- Quick filters: Watched / Unwatched / Continue Watching / Watchlist
- Profile-state filters: Has Profile / Stacked / No Profile / Hub Available
- Mood/occasion presets section: "Family movie night", "Date night safe", "Action no gore", etc. — each is a one-click filter
- Custom shelves: user-saved filter combos
- Category-based filters: Genre · Year range · MPAA rating · Language · Runtime
- "+ New shelf" button — saves the current filter combination

**Top bar: view controls**
- View mode toggle: Grid (default) · List · Detailed list · Coverflow (optional, deferred)
- Sort: Title · Year · Date added · Last watched · Runtime · Profile state
- "Random pick" button — surfaces one title matching the active filter set
- "Who's watching?" viewer-label selector (if multi-viewer enabled) — applies that viewer's default profile stack and credits stats to their bucket
- Library health indicator chip (if any issues): "12 items need attention" → opens Health view

**Center: title grid/list**
- Grid: poster + title + year + profile-state badge overlay on each card
- List: row with thumbnail, title, year, runtime, profile-state badge, watched indicator, last-watched date
- Hover on card: subtle elevation; quick-action buttons fade in (Play with default stack · Open detail · Add to watchlist)
- Click a card: opens title detail view
- Right-click: full context menu (play / play with… / edit profile / add to watchlist / mark watched / show in folder / etc.)
- Empty state when filters return nothing: clear message + "Clear filters" link

# Profile-state badge (universal element)
Shown on every card / row. Visually distinct states:
- ✓ Has profile (single)
- Stacked (N) — number indicates how many profiles
- Draft in progress — uses a "draft" icon
- No profile
- Hub available — small "new" indicator if FVP Hub has profiles for this file's fingerprint that the user hasn't downloaded

# Title detail view
Opens when a card is clicked. Modal-like overlay or full panel takeover (designer's call — recommend full panel for breathing room).

Top hero region:
- Large poster, backdrop, title, year, runtime, MPAA rating chip, language chips
- Plot summary, cast (top 5), director
- Primary CTA: "Play" (uses current default stack)
- Secondary CTAs: "Play with…" (opens profile picker), "Edit profile", "Add to watchlist"

Profiles section (the unique angle):
- All linked profiles for this title listed
- Each profile row: name · version · uploader handle (or "your local") · category breakdown · downloads/upvotes (if from Hub) · "Active in current stack" toggle · "Edit" / "Preview" / "Open diff if newer available"
- "Browse Hub for more profiles for this title" CTA

Content warnings section (if data available):
- Aggregated warnings from configured sources, displayed as chips
- For each warning, a "Suggest snips for this" affordance that opens a starter draft in Profile Creator

Stats section (per-title):
- Times watched · last watched · total junk cut for this title · category breakdown sparkline
- Multi-viewer breakdown if applicable

Media info section (collapsible):
- Container, codec, resolution, HDR, audio tracks, subtitle tracks, file path
- "Refresh fingerprint" button (in case the file changed)

# Stats dashboard (Library > Stats)
A dedicated view, NOT a side panel. Sections, top to bottom:

**Headline card:**
- "You've cut [N hours] of junk across [M] viewings."
- Sub: category breakdown — "47h language · 18h sex · 12h boring · 3h agenda"

**Per-category breakdown:**
- Bar chart of cut totals by category
- Click a category → drill-down list of titles where it was cut

**Most-cut titles leaderboard:**
- Top 10 titles by total junk cut, each with sparkline

**Profile productivity (if uploader key loaded):**
- Snips authored this month
- Profiles created
- Profiles uploaded
- Hub stats: total downloads / upvotes / flag count per uploaded profile (list)

**Viewing log:**
- Reverse-chronological list of viewings (deletable any time)
- Per viewer label if applicable
- Filter by date range

**Privacy footer:**
- "All stats live on this device only. FVP never sends viewing data anywhere." + "Wipe all stats…" button (confirms destructive action)

# Mood/occasion preset picker
- Accessible from left rail and as a one-click button in the top bar
- Modal grid of preset chips: "Family movie night" · "Date night safe" · "Action no gore" · etc.
- Each preset: name + short description + count of matching titles
- Click → applies the underlying filter combination to the main library view
- "+ New mood preset" — saves the current filter combination with a name

# Multi-viewer "who's watching" picker
- Subtle dropdown in the top bar showing the current viewer label
- Click → list of configured viewers + "+ Add viewer" affordance
- Adding a viewer: name + default profile-handling preferences (which categories skip vs. silence, etc.) + optional avatar
- No accounts, no passwords — pure local labels

# Library health view
- Surfaces issues: missing files (broken paths), fingerprint drift (file changed since profile was made), duplicate files, profiles using deprecated categories, large unwatched backlog (optional, friendly nudge)
- Each issue: row with the title, problem description, recommended action ("Relink file…", "Refresh fingerprint", "Update profile", "Ignore")
- Bulk-fix where possible

# Continue Watching shelf
- A horizontal scrolling rail at the top of the main library view (above the grid)
- Shows titles with saved playback positions
- Each card: poster + progress bar + "Resume X:XX with [profile stack]" hint
- Click to resume directly with the right stack applied

# Hub feed integration
- A dedicated shelf or panel: "New profiles on FVP Hub for files you own"
- Driven by fingerprint match (the player has the fingerprints; library queries Hub for new profiles)
- One-click "Download and apply"

# Library settings (within Settings > Library, only when Library Mode enabled)
- Watched folders (add / remove / pause-watching)
- Metadata provider config (API key)
- Content-warning sources (enable/disable each)
- Whisper-based language detection (toggle; explainer about local CPU/GPU cost)
- Cache size for posters/images
- Library DB location + "Reveal in folder"
- "Reset library" (destructive; clears DB but doesn't touch video files or profiles)
- Multi-viewer labels (add / edit / remove)

# States to design
- Library disabled (mode hidden entirely)
- Library enabled, first-run (onboarding)
- Library enabled, indexing in progress (progress indicator in top bar)
- Library enabled, fully indexed
- Library with metadata source connected (posters, plot, etc. visible)
- Library without metadata source (filename-only display, with gentle nudge to add a source)
- Empty filter result
- Title detail with rich metadata
- Title detail without metadata
- Stats dashboard with data
- Stats dashboard empty (no viewings yet)
- Library health with issues
- Library health all clear

# Behavior callouts
- Library indexing runs background-only, never blocks any UI
- Switching from Library Mode back to Player Mode is INSTANT — never pre-loads heavy library data into player paths
- Posters lazy-load as scrolled into view
- All Hub queries are async with cached fallback
- Library can be fully closed/disabled from Settings and the mode disappears from the UI
