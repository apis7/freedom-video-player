FVP — UI Spec: Player Mode

This spec describes layout, content, interactions, and states for Player Mode. It does NOT prescribe visual design (colors, fonts, exact spacing) — that's for Claude Design. Visual ethos: Media Player Classic — minimal chrome, no decorative anything, every pixel justified.

# Default boot state (no file loaded)
- Top menu bar across the very top: File · Video Playback · Video · Audio · Subtitle · View · Tools · Help
- Center: large empty-state region with two affordances:
  - "Drop a video file here" prompt
  - "Or press Ctrl+O to open" hint
- Below the empty state: a compact "Recent Files" list (max 8, configurable). Each row: filename, last played, profile-state badge if applicable
- No bottom transport bar visible (nothing to play)
- Window is resizable; minimum size enforces transport bar fitting cleanly when content loads

# File loaded — windowed
Three horizontal regions, top to bottom:

**Top (menu bar)** — unchanged from boot state. Always visible in windowed mode.

**Center (video canvas)** — fills available vertical space. Right-click anywhere on canvas opens the context menu (mirrors top menus + a few context-aware items).

**Bottom (transport bar)** — single thin row containing, left to right:
- Play/Pause toggle
- Stop
- Previous file / Next file (greyed if not applicable)
- Stop After toggle (only visible if more than one file in queue — tooltip explains behavior)
- Seek bar (takes most of the horizontal space)
- Current time / total time readout (right-aligned to seek bar)
- Shuffle toggle, Repeat cycle (off / all / 1), Mute toggle, Volume slider (compact)
- Fullscreen toggle (rightmost)

**Seek bar specifics:**
- Hovering shows a thumbnail preview tooltip with timestamp
- If a profile is loaded, the bar displays slim colored markers along its length showing upcoming snips, color-coded by category. Hover reveals snip category and action.
- Chapter markers (if present in file) shown as small vertical ticks above the bar
- Click to seek; drag to scrub

# File loaded — fullscreen
- Pure video fills entire screen
- All chrome (menu, transport, profile chip) auto-hides after ~2s of mouse idle
- Any mouse movement reveals: top menu strip (slim) + bottom transport (slim), both as auto-fade overlays
- Esc exits fullscreen; F toggles

# Active profile chip (overlay)
Top-right of the video canvas, semi-transparent, auto-fades after a few seconds idle:
- Single profile loaded: "Profile: Family v3"
- Multiple stacked: "Profile: Family + No Filler (2 active)" — clicking opens the profile switcher
- Toggled off (A/B): "Profile OFF (T)" — visually distinct (red/orange accent)
- No profile: chip not shown
- Hovering the chip reveals last-action and "T to toggle" hint

# Profile switcher / stacker (panel, opens from active profile chip)
- Slide-out side panel listing every `.free` file FVP detected for the current video
- Each row: profile name, version, uploader handle (or "your local"), category breakdown summary, toggle on/off, "set primary" star
- Below: "Load .free file…" button (manual override)
- "Stack details" expandable: shows resolved restrictiveness hierarchy when multiple are active
- Closes on Esc or click-outside

# Skip-That tray (overlay, auto-shown on first Skip-That hotkey)
- Slim horizontal overlay positioned just above the transport bar
- Left: status line — "Recording: started 1:23:45" or "Draft: 7 snips logged"
- Center: four labeled hotkey reminders: `[ "[ Start 10s ago" ] [ "\ Start now" ] [ "] Stop snip" ] [ "Q Quick 10s" ]`
- Right: "View draft" button → opens Profile Creator on the current file with the draft loaded
- Auto-fades after 8s of no Skip-That activity; any Skip-That key brings it back

# A/B profile toggle indicator
- When user hits T to flip filter off mid-playback: profile chip flashes "Profile OFF" with a sharp visual cue (color shift), then settles into a persistent dimmed/off state
- When toggled back on: brief "Profile ON" flash, returns to normal chip

# Fullscreen prompt overlay (windowed-mode timer)
Triggered automatically after 60s windowed without entering fullscreen (unless disabled in Settings):
- Bottom-center toast
- Text: "Enter fullscreen mode? Defaulting to fullscreen in 30s..." with visible countdown
- Buttons: "Yes (Enter)" · "No (Esc)" · "Don't ask again"
- Auto-dismissed if user enters fullscreen by any other means before timeout

# End-of-playback summary toast
Triggered when a file finishes naturally OR a Stop After-terminated queue ends:
- Bottom-right corner, animates in
- Headline: "Cut 14m 22s across 23 snips."
- Sub-line: category breakdown as chips — "8 language · 3 sex · 12 boring"
- Auto-dismisses after ~6s; click anywhere on the toast for a fuller breakdown modal
- Clicking outside the toast or pressing Esc dismisses
- Suppressed if no profile was active

# Resume prompt (modal, on file open)
Shown only when Settings opt-in is enabled AND a saved position exists for this file × profile-stack combo:
- Centered modal, dimmed background
- Headline: "Resume from 1:24:18?"
- Sub: "Last watched with profile: Family v3"
- Buttons: "Resume" (primary) · "Start over" · "Always resume this file" · "Always start over"
- Esc = Resume (the friendly default)

# Update / diff prompt (modal)
Shown when player detects a newer version of a loaded profile from Hub:
- Headline: "A newer version of 'Family v3' is available (v4 — 2 new snips, 1 removed)"
- "View diff" expandable: shows added/removed/changed snips, colored
- Buttons: "Keep current" · "Upgrade to v4" · "Merge…" (opens a merge editor — defer detailed design)
- Dismiss to remind later or "never for this profile"

# Hotkey cheatsheet overlay (`?` to open)
- Full-window translucent overlay, dims video behind
- Three columns: **Player Mode** · **Skip-That** · **Profile Creator**
- Each column = scrollable list of rows: hotkey on left, action on right
- Top-right: "Customize hotkeys" button → Settings > Hotkeys
- Esc or `?` again to dismiss

# Right-click context menu (on video canvas)
Top section mirrors the top menus (Video Playback, Video settings, Audio, Subtitle, View, Tools).

Bottom section is context-aware to current playback state:
- "Show snips around current time" — opens an inline list of snips within ±60s of playhead
- "Apply Skip-That to here" — same as Quick 10s snip hotkey
- "Edit profile…" — switches to Profile Creator at the current timestamp (snapshots position)
- "Save Now Playing as .m3u…"

# Top menu structure (always-visible bar)
- **File**: Open Files, Open Folder, Open DVD-ripped Folder, Open Recent ▸, Save Playlist as .m3u, Settings, Exit
- **Video Playback**: Title, Chapter, Speed, Jump to custom time…
- **Video**: Video track, Fullscreen, Deinterlace, Deinterlace mode
- **Audio**: Audio Track, Audio Device, Stereo mode
- **Subtitle**: Add Subtitle File…, Select Subtitle Track
- **View**: Now Playing List, Playlist view mode ▸ (Simple list / Detailed list / Filename), Always on Top
- **Tools**: A/V & Subtitles Sync, Media Information, Codec Information, Settings, Help, Check for Updates, About / TOS / Privacy Policy
- **Help**: Hotkey Cheatsheet, How it works (deep-links to website "How it works" page), About

Every menu item with a hotkey shows the hotkey on the right of its row.

# Now Playing panel
- Slides in from the right (View > Now Playing List or hotkey)
- Header: view-mode toggle (Simple list / Detailed list / Filename)
- Body: each row = filename + runtime + profile-state badge (✓ profile / no profile / draft) + drag handle for reorder
- Footer: "Save as .m3u" · "Clear" · "Shuffle" · "Repeat" toggles
- Close: click X or click outside

# States to design
- Boot / no-file-loaded
- File loaded, playing, windowed
- File loaded, paused, windowed
- File loaded, fullscreen, controls visible
- File loaded, fullscreen, controls hidden (idle)
- Loading a file (brief)
- Buffering / decode hiccup (rare, but design a thin progress line)
- Error loading file (modal with clear retry / cancel / "open another")
- Profile loading
- Skip-That active recording
- A/B toggle OFF
- End-of-playback summary

# Empty states
- No recent files: replace recent-files list with "No recent files yet — drop a video to get started"
- No profile detected for current file: chip not shown; no marker overlays on seek bar

# Animation / behavior callouts
- All overlay fade in/out should be quick (~150ms). Slow fades feel sluggish; this product is "lightning fast."
- Mouse-idle hiding in fullscreen ~2s
- Profile chip auto-fade ~3s after last interaction
- Skip-That tray auto-fade 8s after last Skip-That input
- Transitions between modes (Player → Profile Creator) should NOT animate dramatically — instant swap with current playback position preserved

# Tooltips
EVERY interactive element has a tooltip. Tooltip text must be useful (explain WHY/WHAT, not restate the label). Tooltips for buttons include the current hotkey binding parenthetically.
