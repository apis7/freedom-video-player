FVP — UI Spec: Profile Creator Mode

Visual ethos: dense and editor-like. This is a pro tool. Information density is OK here in a way it isn't in Player Mode — but every control still earns its place.

# Mode entry
- From Player Mode: top menu Tools > Edit Profile, or right-click "Edit profile…", or a dedicated mode-switch button
- When entering from active playback, current timestamp is preserved (the creator opens at that frame)
- Existing `.free` files auto-load. `.free.draft` from Skip-That auto-loads as the working profile.
- If multiple `.free` exist, the user is prompted: edit which one? Or start a new profile?

# Layout (five regions)

**Top toolbar** (slim, always visible)
- Left: Undo · Redo
- Center: Save Profile (Ctrl+S) · Save As… · Export to .free · Auto-suggest from subtitles
- Right: A/B toggle indicator · Upload to Hub (disabled if no uploader key loaded) · Switch back to Player Mode

**Center-top: video canvas**
- Smaller than in Player Mode — shares vertical space with the timeline below
- Playback transport directly under it: Play/Pause · Frame-step `<` `>` · Current time (ms-precise) · Frame counter · Speed
- Right side of transport: zoom controls for the timeline below (zoom in/out, fit-to-window)

**Center-bottom: multi-layer timeline** (the main work surface)
Layered, all sharing the same horizontal time axis, vertically stacked:
- **Ruler row:** time scale with chapter markers (small ticks)
- **Audio waveform row:** rendered audio waveform; collapsible
- **Scene-change row:** vertical tick markers at detected scene boundaries (auto-computed in background)
- **Snip layer:** colored blocks representing snips. Block color = category. Block label = group name if grouped. Edges are draggable. Selected snip is visually emphasized.
- **Stacked-profile context row(s):** if other `.free` files apply to this video, their snips show here as semi-transparent read-only blocks for reference (do not affect the current edit)
- **Subtitle row:** if .srt is loaded, shows subtitle entry blocks for alignment reference

The playhead is a vertical line spanning all layers, draggable. Right-clicking anywhere on the snip layer creates a new snip at that location.

**Left rail: snip list** (full vertical height)
- Header: "X snips · N needs review"
- Snips grouped by group/label, collapsible per group
- Each row: snip start time · duration · category chip(s) · action icon · "needs review" badge if uncategorized
- Click a row → selects snip + jumps playhead to start
- "+ New group" button at the bottom
- Drag-to-reorder snips into groups
- Right-click for context: rename, ungroup, duplicate, delete

**Right rail: snip detail panel** (full vertical height; shows currently selected snip)
- Selected snip's start/end times as editable inputs (ms precision)
- Duration readout (auto-calculated, read-only)
- Category section: chip list of assigned categories with X to remove; "+ Add category" button opens picker (search + canonical list)
- Per-snip action override: radio group — Skip · Silence · Audio-replace · Freeze-frame
- If Audio-replace selected: direction toggle (Before / After), auto-calculated source length readout, warning callout if adjacent region too short to fill ("flip direction?")
- "Preview snip" button (Enter hotkey)
- "Delete snip" button
- Notes field (optional, freeform, useful for sharing context)

**Bottom status bar**
- Left: "Draft mode" indicator if loaded from `.free.draft`
- Center: autosave status — "Saved 14s ago" with green dot when recent
- Right: Export to .free CTA — disabled with tooltip "X snips still need a category" if any uncategorized

# Snip authoring interactions
- **Create snip by dragging on the snip layer:** click-drag horizontally to draw a new snip's time range; releases as a new snip selected automatically
- **Create snip by hotkey:** `I` at current playhead marks in-point; `O` marks out-point (creates if none open)
- **Resize:** drag either edge of an existing snip block
- **Nudge selected edge:** Ctrl+arrow = 1s, Ctrl+Shift+arrow = 5s
- **Move snip wholesale:** drag the middle of the block
- **Multi-select:** Shift-click snips in either the list or the timeline; group operations: delete, group, categorize, change action
- **Overlapping snips:** allowed; visual stacking on the snip layer; restrictiveness hierarchy resolves conflicts (skip > freeze > silence > audio-replace)
- **Preview snip:** select + Enter — plays from a few seconds before through after with the action applied; mini "before/after" toggle visible during preview to A/B in real time
- **A/B toggle (T):** flips active profile preview on/off during playback; visual indicator in toolbar

# Auto-suggest from subtitles flow
Trigger: top toolbar button OR `.srt` loaded prompt
- Modal opens with subtitle-driven scan results
- Wordlist used is shown at top with "Edit wordlist" link → Settings > Subtitles & Wordlist
- Results table: timestamp · matched word · subtitle excerpt · proposed snip span (with default padding +0.2s before / +0.3s after) · checkbox per row · default category preselected ("language")
- Adjust padding globally (slider) — preview re-snaps as you change
- "Accept selected" creates snips in bulk; "Cancel" discards

# Group/label workflow
- Hotkey Ctrl+G with snips selected → name prompt → creates group
- Groups are organizational only; they don't change snip behavior
- Groups can be collapsed in the left rail to keep long profiles readable
- Groups can be renamed inline, deleted (snips revert to ungrouped), or dragged in order

# Undo / redo
- Stack covers: create, edit edges, change category, change action, group, delete, paste
- Visible button + Ctrl+Z / Ctrl+Shift+Z hotkeys
- Stack persists across autosave but not across full app close (no need to over-engineer)

# Export to .free
- Disabled if ANY snip is uncategorized — tooltip names the count and clicking jumps to first uncategorized snip
- Confirmation modal on click: shows summary (snip count, categories used, expected total cut duration) + filename + "Upload to Hub after save" optional checkbox
- On save, .free is written next to the video; .free.draft (if present) is removed
- Schema version stamped automatically

# Loading a profile as a template
- File menu > "Load .free as template…" — opens any .free into the creator regardless of which video is open
- All snips load; user is warned if video duration doesn't match (snips that fall outside video duration are flagged)
- User can save as a new .free for the current video

# States to design
- Empty creator (no profile, no draft) — encouraging blank slate, with shortcut tips
- Profile loaded, no snip selected — left rail and right rail empty selection states
- Profile loaded, one snip selected — full detail panel populated
- Profile loaded, multi-selection — detail panel shows bulk-edit subset of controls
- Auto-suggest running — progress bar
- Preview playing — slight visual emphasis on the snip being previewed
- A/B toggle OFF — chrome reflects that filter is off
- Export blocked (uncategorized snips) — clear inline guidance
- Draft mode — persistent badge in status bar; gentle reminder to export

# Behavior callouts
- Autosave fires every N seconds (Settings-configurable; default 10s) AND on any meaningful edit
- Crash-safe autosave writes to `.free.draft.swap` first, then renames — never corrupts the working file
- Timeline zoom should respond instantly; never let waveform render block interactions (render asynchronously)
- Scene-change detection runs in background after file open; markers fade in as detected — never blocks editing
- All overlay/dialog transitions ~150ms

# Tooltips & hotkey reminders
- Every button shows its hotkey in tooltip
- Hovering the timeline shows hotkey hints inline: "drag to create · I/O for in/out · Ctrl+arrow nudge"
