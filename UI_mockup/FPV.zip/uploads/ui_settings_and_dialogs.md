FVP — UI Spec: Settings, First-Run, and Cross-Cutting Dialogs

Visual ethos: dense, scannable, never modal-spaghetti. Settings should feel like an old-school configuration window — fast to navigate, never gated behind tabs-within-tabs.

# Settings window (Tools > Settings)
Persistent, resizable window. Two regions:

**Left navigation rail** (scrollable, full vertical):
- Playback
- Hotkeys
- Categories
- Subtitles & Wordlist
- Profiles & Files (matching, drafts, autosave)
- Sharing & Uploader Key
- Library (greyed out + tooltip "Enable Library Mode in Playback to access" if Library is disabled)
- Storage & Cache
- Updates
- About / TOS / Privacy

**Right content panel** (scrollable):
- Active section's settings
- Settings are auto-applied on change (no global Save button) — except where validation requires confirmation
- Each setting row: label · current value control · short helper text · optional "Reset to default" link
- Modified-from-default rows have a subtle visual indicator + "Reset" affordance

# Playback section
- Default volume (slider, 0–125%)
- Enable fullscreen prompt at 60s windowed (toggle)
- Default transport behavior when reaching end of queue (stop / repeat all / repeat one)
- Remember playback position per file (toggle) — when ON, the resume prompt appears on re-open
- Frame-step granularity (1 frame / N frames)
- Enable Library Mode (toggle; OFF by default) — explainer text: "Optional library/stats module. Doesn't affect Player Mode performance."

# Hotkeys section
Dense table:
- Each row: action name · current binding · "Change…" button · "Reset" link
- Search/filter at the top
- Grouped by mode: Player Mode · Skip-That · Profile Creator · Library (if enabled)
- "Reset all to defaults" button at the bottom with confirmation
- Conflict detection: assigning a key already in use prompts to reassign / cancel

# Categories section
- List of all current categories (bundled + user-created)
- Each row: category name · default action (Skip / Silence / Audio-replace / Freeze-frame dropdown) · color swatch · "user-added" or "bundled" tag · edit / delete (delete only for user-added)
- "+ Add custom category" button — opens small dialog: name · default action · color
- "Sync categories with server" panel at the top: two buttons "Overwrite local with official list" · "Merge local with official list" + last-sync timestamp + explainer text
- Warning callout if local categories differ from canonical list

# Subtitles & Wordlist section
- Default subtitle track behavior (auto-pick / off / language preference)
- Subtitle sync default offset (ms)
- Subtitle-driven snip wordlist editor:
  - Bundled wordlist (read-only, with toggle to enable/disable per-category)
  - User wordlist (add / edit / remove words)
  - Default padding for auto-suggested snips (before / after, ms inputs with live preview)
  - Default category assigned to subtitle-suggested snips (dropdown, default "language")

# Profiles & Files section
- File-to-profile matching threshold (strict / moderate / loose) — strict requires all fingerprint fields match; loose allows pHash+duration only
- Auto-load all matching profiles for stacking (toggle)
- Draft autosave interval (slider, seconds)
- Drafts directory (file picker; default = next to video files)
- Show "needs review" badge on uncategorized snips (toggle — on by default; only off for power users)

# Sharing & Uploader Key section
- Uploader handle (read-only if key loaded; "no key loaded" if not)
- "Generate new uploader key" button — opens key-generation flow (see dialog below)
- "Load existing key file…" button — file picker for an existing key
- "Export current key file…" button (only enabled when key is loaded) — for backup
- "Forget key on this device" button — with confirmation warning ("you cannot recover this key without your backup file")
- Hub URL (read-only; configurable for self-hosting / future)

# Storage & Cache section
- Cache size limit for posters/images (slider; defaults small)
- Pre-decode buffer for seamless skipping (slider; default sized for "a few minutes of upcoming cuts")
- "Clear cache" button with breakdown of what gets cleared
- Library DB location (read-only path, "Reveal in folder")
- Portable mode toggle — explains: "When ON, all settings, cache, and library DB live next to the FVP executable instead of in %APPDATA%"

# Updates section
- Check for updates on startup (toggle)
- Update channel (stable / beta)
- "Check now" button
- Profile-update behavior: prompt on detection / auto-apply / never check (radio)

# About / TOS / Privacy section
- App version, build, license
- Link to TOS (opens external)
- Link to Privacy Policy
- Link to "How it works" page on the website
- Credits

# First-run TOS modal (only screen shown on first launch)
- Single centered modal, no chrome behind
- Headline: "Welcome to Freedom Video Player"
- Body: brief plain-language TOS text — user agrees they will only modify videos they own and have the right to modify; FVP is not responsible for misuse
- Required: "I agree" checkbox
- Buttons: "Continue" (disabled until checkbox ticked) · "Read full TOS" (opens external)
- After this modal, app boots directly into Player Mode — no walkthroughs, no setup wizard, no demo

# Uploader-key generation dialog
Triggered from Settings > Sharing & Uploader Key > "Generate new uploader key":
- Step 1: pick a handle (text input, validated against server for uniqueness on submit; case-sensitive, character allowlist)
- Step 2: confirm handle is final (cannot be changed without generating a new key)
- Step 3: generate keypair locally, prompt user to save the key file ("freedom-uploader-key-{handle}.key") — explainer: "If you lose this file, you lose access to this handle forever. Back it up."
- Step 4: confirmation — key loaded, handle reserved on server, ready to upload

# Resume prompt (cross-cutting, also referenced in ui_player.md)
- Centered modal on file open if conditions met
- Headline: "Resume from 1:24:18?"
- Sub: "Last watched with profile: Family v3"
- Buttons: Resume (primary) · Start over · Always resume this file · Always start over
- Esc = Resume

# Profile update / diff modal
- Triggered when an updated version of a loaded profile is detected
- Headline: "A newer version of 'Family v3' is available (v4)"
- Body: bulleted diff — added snips (green), removed snips (red), modified snips (yellow)
- Buttons: Keep current · Upgrade · Merge… (defer detailed merge UI design) · Never check for this profile

# Unknown-category prompt
- Triggered when loading a profile that contains a category not in the user's local list
- Headline: "This profile uses an unknown category: '[category name]'"
- Sub: "How would you like to handle this category by default?"
- Radio group: Skip · Silence · Audio-replace · Freeze-frame · Ignore
- Checkbox: "Remember this for future profiles" (default ON)
- Buttons: Apply · Cancel

# Error / fingerprint-mismatch warning
- Triggered when loading a .free whose fingerprint doesn't match the open video
- Headline: "This profile may not be for this video"
- Body: which fingerprint fields matched / didn't match (filename, size, duration, pHash). Plain language, not jargony.
- Buttons: Load anyway · Cancel · "Use as template" (opens in Profile Creator instead of applying)

# General dialog principles
- Esc closes / cancels (or maps to the friendly default)
- Enter activates primary action
- Modals dim the background but never trap focus indefinitely — user can always Esc out
- No "Are you sure?" for non-destructive actions
- Destructive actions (delete profile, forget key) DO confirm, with the destructive button visually deprioritized
- Toasts (non-modal) for: autosave, save success, copy-to-clipboard, etc. — bottom-right, auto-dismiss
