Freedom Video Player (aka FVP): User Flow

I. Profile Creation

On first start: User agrees that they will only modify videos to which they have a right and they own and are alloewd to modify, and that blah blah blah. FVP is not responsible for users using or misusing it's tool.

1. User opens Freedom Video Player. The player defaults to Player Mode.
2. User enters "Profile Creator" mode
3. User selects a video file, and loads it for Profile creation.
4. User scrubs/seeks through that video file:
(a) User creates "snips" as needed
(i) Creats a start/stop timestamp for the snip (drag the edge, or ctrl-> or ctrl-< button nudges the selected edge 1s over; ctrl-shift-> or ctrl-shift-< nudges the selected edge over 5s). 
(ii) Categorizes the snip using either pre-available categories (e.g. sex, violence, lagnuage, boring content, agenda: feminism, agenda: LGBTQUIA+, agenda: socialism, agenda: atheism, etc.). Users can assign multiple categories to a snip. Snips can also overlap. Users can also make their own custom snips.
(iii) Designates the snip as: (a) skip (the player seamless skips over that snip), (b) silence (plays the snip, but silences the audio), (c) audio-replace (video plays, but user selects an audio-offset before or after the snip to "clone" the audio, that auto-crossfades in/out with the replaced audio section), (d) freeze-frame (freezes the first frame of that video, but plays the audio)
(b) User saves the collection of snips as that video file's "Profile."
(c) User can auto-upload the video's Profile - they fill out the File's metadata (as much as possible, it's filled out automatically) and hit "upload".
5. User heads back to Player Mode, and watches the Movie with their customized viewing experience that they've just built.

Now, that file is saved in a proprietary format (e.g. ".free" or something) alongside the video file, much like a .srt or whatnot. The Profile is linked to that specific video file (looks for that file's hash or something like that, not really sure). Thereafter, Freedom Video player will auto-detect the presence of that .free file, check to make sure it corrosponds to the correct video file, and utilizes that to customize the watch experience of the User.
On load, Freedom Video player will (a) load the default preferences for how to handle snip categories for the user, or, (b) if it encounters an unknown category, will ask the user how they want to handle that category.
(Note: FVP will WARN the user if the .free file doesn't corrospond to the video file, but the user can still attempt to load it nonetheless. Additionally, users can load .free files into the FVP Profile Creator and use that as a starting template for a file - it'll open all the snippets, etc.)


II. Profile Sharing

This is a relatively simple website that is heavily promoted within the player, that users can visit to share Profiles with each other.

1. No login required. Bot detection and captcha etc only. Users pass the "authentication" that verifies they are a human. 
2. Users upload their Profiles, and fill out metadata for said Profiles. (Note: as noted above, Users can also upload straight from the FVP workflow). 
3. Uploading:
  -is IP limited to 3 profiles/hr and 10 profiles/day
  -is limited overall (website-wide) to 250 Profiles/day, regardless of IP etc.
  -is heavily validated to ensure that the uploaded file is ONLY a .free, (a) it's a valid .free, and (b) nothing else, (c) no tampering
4. Users can then search and download Profiles as desired, without login or limit.
